import { Router } from "express";
import { db, marketplaceListingsTable } from "@workspace/db";
import { eq, and, desc, ilike, sql } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth";
import { requireFeature } from "../lib/feature-gate";
import { generateId } from "../lib/id";
import { logger } from "../lib/logger";

const router = Router();

const gate = requireFeature("marketplace");

function formatListing(l: typeof marketplaceListingsTable.$inferSelect) {
  return {
    id: l.id,
    tenantId: l.tenantId,
    title: l.title,
    description: l.description,
    price: Number(l.price),
    currency: l.currency,
    category: l.category,
    imageUrl: l.imageUrl ?? null,
    imageUrls: (l.imageUrls as string[] | null) ?? [],
    whatsappNumber: l.whatsappNumber ?? null,
    location: l.location ?? null,
    status: l.status,
    views: l.views,
    featured: l.featured,
    createdAt: l.createdAt.toISOString(),
  };
}

router.get("/marketplace", async (req, res) => {
  try {
    const { category, search, tenantId: filterTenant } = req.query as Record<string, string>;

    const conditions = [eq(marketplaceListingsTable.status, "active")];
    if (filterTenant) conditions.push(eq(marketplaceListingsTable.tenantId, filterTenant));
    if (category) conditions.push(eq(marketplaceListingsTable.category, category as typeof marketplaceListingsTable.$inferSelect.category));
    if (search) conditions.push(ilike(marketplaceListingsTable.title, `%${search}%`));

    const items = await db
      .select()
      .from(marketplaceListingsTable)
      .where(and(...conditions))
      .orderBy(desc(marketplaceListingsTable.featured), desc(marketplaceListingsTable.createdAt))
      .limit(100);

    res.json(items.map(formatListing));
  } catch (err) {
    logger.error({ err }, "GET /marketplace error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/marketplace/my-listings", requireAuth, gate, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const items = await db
      .select()
      .from(marketplaceListingsTable)
      .where(eq(marketplaceListingsTable.tenantId, tenantId))
      .orderBy(desc(marketplaceListingsTable.createdAt));
    res.json(items.map(formatListing));
  } catch (err) {
    logger.error({ err }, "GET /marketplace/my-listings error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/marketplace", requireAuth, gate, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const userId = req.userId as string;
    const body = req.body as {
      title: string;
      description: string;
      price: number;
      currency?: string;
      category?: string;
      imageUrl?: string;
      imageUrls?: string[];
      whatsappNumber?: string;
      location?: string;
    };

    const imageUrls = Array.isArray(body.imageUrls) ? body.imageUrls : (body.imageUrl ? [body.imageUrl] : []);
    const [listing] = await db
      .insert(marketplaceListingsTable)
      .values({
        id: generateId(),
        tenantId,
        userId,
        title: body.title,
        description: body.description,
        price: String(body.price),
        currency: body.currency ?? "NGN",
        category: (body.category ?? "other") as typeof marketplaceListingsTable.$inferSelect.category,
        imageUrl: imageUrls[0] ?? body.imageUrl ?? null,
        imageUrls: imageUrls.length > 0 ? imageUrls : null,
        whatsappNumber: body.whatsappNumber,
        location: body.location,
      })
      .returning();

    res.status(201).json(formatListing(listing));
  } catch (err) {
    logger.error({ err }, "POST /marketplace error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/marketplace/:id", requireAuth, gate, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const body = req.body as Partial<{
      title: string;
      description: string;
      price: number;
      status: string;
      imageUrl: string;
      whatsappNumber: string;
      location: string;
    }>;

    const updates: Partial<typeof marketplaceListingsTable.$inferInsert> = { updatedAt: new Date() };
    if (body.title) updates.title = body.title;
    if (body.description) updates.description = body.description;
    if (body.price !== undefined) updates.price = String(body.price);
    if (body.status) updates.status = body.status as typeof marketplaceListingsTable.$inferSelect.status;
    if (body.imageUrl !== undefined) updates.imageUrl = body.imageUrl;
    if (body.whatsappNumber !== undefined) updates.whatsappNumber = body.whatsappNumber;
    if (body.location !== undefined) updates.location = body.location;

    const [listing] = await db
      .update(marketplaceListingsTable)
      .set(updates)
      .where(and(eq(marketplaceListingsTable.id, req.params.id as string), eq(marketplaceListingsTable.tenantId, tenantId)))
      .returning();

    if (!listing) { res.status(404).json({ error: "Listing not found" }); return; }
    res.json(formatListing(listing));
  } catch (err) {
    logger.error({ err }, "PATCH /marketplace/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/marketplace/:id", requireAuth, gate, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    await db
      .delete(marketplaceListingsTable)
      .where(and(eq(marketplaceListingsTable.id, req.params.id as string), eq(marketplaceListingsTable.tenantId, tenantId)));
    res.status(204).send();
  } catch (err) {
    logger.error({ err }, "DELETE /marketplace/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/marketplace/:id/view", async (req, res) => {
  try {
    await db
      .update(marketplaceListingsTable)
      .set({ views: sql`views + 1` })
      .where(eq(marketplaceListingsTable.id, req.params.id as string));
    res.json({ ok: true });
  } catch {
    res.json({ ok: true });
  }
});

export default router;
