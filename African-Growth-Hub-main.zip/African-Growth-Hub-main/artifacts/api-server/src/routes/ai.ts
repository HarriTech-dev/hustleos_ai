import { Router } from "express";
import { db, aiConversationsTable, inventoryTable, invoicesTable, customersTable } from "@workspace/db";
import { eq, and, sql } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth";
import { generateId } from "../lib/id";
import { logger } from "../lib/logger";

const router = Router();

interface AiMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt: string;
}

async function callOpenAI(messages: Array<{ role: string; content: string }>, systemPrompt: string): Promise<string> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) throw new Error("OPENAI_API_KEY not configured");

  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "gpt-4o-mini",
      messages: [{ role: "system", content: systemPrompt }, ...messages],
      max_tokens: 1024,
      temperature: 0.7,
    }),
  });

  if (!response.ok) {
    const err = await response.text();
    throw new Error(`OpenAI error: ${err}`);
  }

  const data = (await response.json()) as {
    choices: Array<{ message: { content: string } }>;
  };
  return data.choices[0]?.message?.content ?? "I could not generate a response.";
}

async function getBusinessContext(tenantId: string): Promise<string> {
  try {
    const [invStats] = await db
      .select({
        totalRevenue: sql<number>`coalesce(sum(total) filter (where status = 'paid'), 0)`,
        totalInvoices: sql<number>`count(*)`,
        overdueInvoices: sql<number>`count(*) filter (where status = 'overdue')`,
      })
      .from(invoicesTable)
      .where(eq(invoicesTable.tenantId, tenantId));

    const [custCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(customersTable)
      .where(eq(customersTable.tenantId, tenantId));

    const [invCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(inventoryTable)
      .where(eq(inventoryTable.tenantId, tenantId));

    return `Business context: Revenue=${invStats?.totalRevenue ?? 0}, Invoices=${invStats?.totalInvoices ?? 0}, Overdue=${invStats?.overdueInvoices ?? 0}, Customers=${custCount?.count ?? 0}, Products=${invCount?.count ?? 0}`;
  } catch {
    return "";
  }
}

const SYSTEM_PROMPT = `You are an expert AI business advisor for African entrepreneurs and SMEs. You provide actionable, practical advice tailored to African markets (Nigeria, Ghana, Kenya, South Africa, Uganda, Tanzania and more). You understand local market dynamics, payment ecosystems (Paystack, Flutterwave, M-Pesa), currency challenges, informal economy, and growth patterns unique to African businesses.

Be concise, warm, and direct. Use simple language. Provide specific, actionable advice. When discussing money, acknowledge multi-currency realities. Always be encouraging while being realistic. Draw from the user's business data when available.`;

const MAX_MESSAGE_LENGTH = 4000;
const MAX_CONVERSATION_MESSAGES = 20;

router.post("/ai/chat", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const { message, conversationId, context } = req.body as {
      message: string;
      conversationId?: string | null;
      context?: string | null;
    };

    if (!message || typeof message !== "string") {
      res.status(400).json({ error: "message is required" });
      return;
    }
    if (message.length > MAX_MESSAGE_LENGTH) {
      res.status(400).json({ error: `Message must be ${MAX_MESSAGE_LENGTH} characters or fewer` });
      return;
    }

    const tenantId = req.tenantId as string;
    const userId = req.userId as string;
    const businessContext = await getBusinessContext(tenantId);

    let conversation: typeof aiConversationsTable.$inferSelect | null = null;

    if (conversationId) {
      const [existing] = await db
        .select()
        .from(aiConversationsTable)
        .where(and(eq(aiConversationsTable.id, conversationId), eq(aiConversationsTable.tenantId, tenantId as string)))
        .limit(1);
      if (existing) conversation = existing;
    }

    const existingMessages = (conversation?.messages as AiMessage[]) ?? [];
    const userMessage: AiMessage = {
      id: generateId(),
      role: "user",
      content: message,
      createdAt: new Date().toISOString(),
    };

    // Truncate history to a rolling window before forwarding to OpenAI to
    // prevent conversation bloat from draining quota on each follow-up request.
    const historyWindow = existingMessages.slice(-MAX_CONVERSATION_MESSAGES);

    const openAiMessages = [
      ...historyWindow.map((m) => ({ role: m.role, content: m.content })),
      { role: "user", content: `${businessContext ? `[${businessContext}] ` : ""}${message}` },
    ];

    const reply = await callOpenAI(openAiMessages, SYSTEM_PROMPT);

    const assistantMessage: AiMessage = {
      id: generateId(),
      role: "assistant",
      content: reply,
      createdAt: new Date().toISOString(),
    };

    const updatedMessages = [...existingMessages, userMessage, assistantMessage];

    let convId = conversationId;
    if (!conversation) {
      const title = message.slice(0, 60) + (message.length > 60 ? "..." : "");
      const [newConv] = await db
        .insert(aiConversationsTable)
        .values({
          id: generateId(),
          tenantId,
          userId,
          title,
          messages: updatedMessages,
        })
        .returning();
      convId = newConv.id;
    } else {
      await db
        .update(aiConversationsTable)
        .set({ messages: updatedMessages, updatedAt: new Date() })
        .where(eq(aiConversationsTable.id, conversation.id));
    }

    const suggestedActions = [
      "Show my revenue trend",
      "How to reduce overdue invoices",
      "Tips for growing in Africa",
    ].slice(0, 3);

    res.json({ reply, conversationId: convId, suggestedActions });
  } catch (err) {
    logger.error({ err }, "POST /ai/chat error");
    res.status(500).json({ error: "Failed to get AI response" });
  }
});

router.get("/ai/conversations", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const conversations = await db
      .select()
      .from(aiConversationsTable)
      .where(eq(aiConversationsTable.tenantId, req.tenantId as string))
      .orderBy(sql`updated_at desc`)
      .limit(20);

    res.json(
      conversations.map((c) => ({
        id: c.id,
        title: c.title,
        messages: (c.messages as AiMessage[]) ?? [],
        createdAt: c.createdAt.toISOString(),
      }))
    );
  } catch (err) {
    logger.error({ err }, "GET /ai/conversations error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/ai/conversations/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const [conv] = await db
      .select()
      .from(aiConversationsTable)
      .where(and(eq(aiConversationsTable.id, req.params.id as string), eq(aiConversationsTable.tenantId, req.tenantId as string)))
      .limit(1);

    if (!conv) {
      res.status(404).json({ error: "Conversation not found" });
      return;
    }

    res.json({
      id: conv.id,
      title: conv.title,
      messages: (conv.messages as AiMessage[]) ?? [],
      createdAt: conv.createdAt.toISOString(),
    });
  } catch (err) {
    logger.error({ err }, "GET /ai/conversations/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/ai/insights", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;

    const [invStats] = await db
      .select({
        overdueCount: sql<number>`count(*) filter (where status = 'overdue')`,
        totalRevenue: sql<number>`coalesce(sum(total) filter (where status = 'paid'), 0)`,
      })
      .from(invoicesTable)
      .where(eq(invoicesTable.tenantId, tenantId));

    const [invItemStats] = await db
      .select({
        lowStock: sql<number>`count(*) filter (where quantity <= low_stock_threshold and quantity > 0)`,
        outOfStock: sql<number>`count(*) filter (where quantity = 0)`,
      })
      .from(inventoryTable)
      .where(eq(inventoryTable.tenantId, tenantId));

    const insights: Array<{
      id: string;
      type: "warning" | "opportunity" | "tip" | "alert";
      title: string;
      description: string;
      priority: "high" | "medium" | "low";
      actionLabel: string | null;
      actionRoute: string | null;
    }> = [];

    if (Number(invStats?.overdueCount ?? 0) > 0) {
      insights.push({
        id: "overdue-invoices",
        type: "alert",
        title: `${invStats?.overdueCount} overdue invoice(s)`,
        description: "Follow up on overdue invoices to improve cash flow.",
        priority: "high",
        actionLabel: "View Invoices",
        actionRoute: "/invoices?status=overdue",
      });
    }

    if (Number(invItemStats?.lowStock ?? 0) > 0) {
      insights.push({
        id: "low-stock",
        type: "warning",
        title: `${invItemStats?.lowStock} item(s) running low`,
        description: "Restock soon to avoid stockouts and lost sales.",
        priority: "medium",
        actionLabel: "View Inventory",
        actionRoute: "/inventory?lowStock=true",
      });
    }

    insights.push({
      id: "africa-tip",
      type: "tip",
      title: "Tip: Accept mobile money payments",
      description: "Enable M-Pesa, MTN Mobile Money and Airtel Money to reach more customers across Africa.",
      priority: "low",
      actionLabel: null,
      actionRoute: null,
    });

    insights.push({
      id: "invoice-tip",
      type: "opportunity",
      title: "Send invoices faster",
      description: "Businesses that send invoices within 24 hours of delivery get paid 2x faster.",
      priority: "medium",
      actionLabel: "Create Invoice",
      actionRoute: "/invoices/new",
    });

    res.json(insights);
  } catch (err) {
    logger.error({ err }, "GET /ai/insights error");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
