import { Router } from "express";
import { db, purchaseOrdersTable } from "@workspace/db";
import { eq, and, ilike, sql } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth";
import { generateId } from "../lib/id";
import { logger } from "../lib/logger";
import { writeAuditLog } from "./audit-logs";
import { dispatchStockReceived } from "../lib/transaction-engine";

const router = Router();

function formatPO(po: typeof purchaseOrdersTable.$inferSelect) {
  return {
    id: po.id,
    poNumber: po.poNumber,
    supplierName: po.supplierName,
    supplierEmail: po.supplierEmail ?? null,
    supplierPhone: po.supplierPhone ?? null,
    status: po.status,
    items: (po.items as unknown[]) ?? [],
    subtotal: Number(po.subtotal),
    tax: Number(po.tax),
    total: Number(po.total),
    currency: po.currency,
    notes: po.notes ?? null,
    expectedDate: po.expectedDate ?? null,
    createdAt: po.createdAt.toISOString(),
  };
}

async function nextPONumber(tenantId: string): Promise<string> {
  const [row] = await db
    .select({ count: sql<number>`count(*)` })
    .from(purchaseOrdersTable)
    .where(eq(purchaseOrdersTable.tenantId, tenantId));
  const n = Number(row?.count ?? 0) + 1;
  return `PO-${String(n).padStart(4, "0")}`;
}

router.get("/purchase-orders", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const { status, search } = req.query as Record<string, string>;
    const conditions = [
      eq(purchaseOrdersTable.tenantId, tenantId),
      status ? eq(purchaseOrdersTable.status, status as typeof purchaseOrdersTable.$inferSelect.status) : undefined,
      search ? ilike(purchaseOrdersTable.supplierName, `%${search}%`) : undefined,
    ].filter(Boolean) as Parameters<typeof and>;
    const items = await db.select().from(purchaseOrdersTable).where(and(...conditions)).orderBy(sql`created_at desc`);
    res.json(items.map(formatPO));
  } catch (err) {
    logger.error({ err }, "GET /purchase-orders error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/purchase-orders", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const body = req.body as {
      supplierName: string;
      supplierEmail?: string;
      supplierPhone?: string;
      items: Array<{ description: string; quantity: number; unitPrice: number; total: number }>;
      tax?: number;
      notes?: string;
      expectedDate?: string;
      currency: string;
    };
    const subtotal = body.items.reduce((s, i) => s + i.total, 0);
    const tax = body.tax ?? 0;
    const total = subtotal + tax;
    const poNumber = await nextPONumber(tenantId);
    const [po] = await db.insert(purchaseOrdersTable).values({
      id: generateId(),
      tenantId,
      poNumber,
      supplierName: body.supplierName,
      supplierEmail: body.supplierEmail,
      supplierPhone: body.supplierPhone,
      status: "draft",
      items: body.items,
      subtotal: String(subtotal),
      tax: String(tax),
      total: String(total),
      currency: body.currency,
      notes: body.notes,
      expectedDate: body.expectedDate,
    }).returning();
    await writeAuditLog({
      tenantId, userId: req.userId as string, action: "create", resource: "purchase_order", resourceId: po.id,
      changes: { poNumber, supplier: body.supplierName, total },
    });
    res.status(201).json(formatPO(po));
  } catch (err) {
    logger.error({ err }, "POST /purchase-orders error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/purchase-orders/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const [po] = await db.select().from(purchaseOrdersTable).where(and(eq(purchaseOrdersTable.id, req.params.id as string), eq(purchaseOrdersTable.tenantId, tenantId))).limit(1);
    if (!po) { res.status(404).json({ error: "Purchase order not found" }); return; }
    res.json(formatPO(po));
  } catch (err) {
    logger.error({ err }, "GET /purchase-orders/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/purchase-orders/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const body = req.body as Partial<{ status: string; notes: string; items: any[]; tax: number }>;
    const updates: Partial<typeof purchaseOrdersTable.$inferInsert> = { updatedAt: new Date() };
    if (body.status !== undefined) updates.status = body.status as typeof purchaseOrdersTable.$inferSelect.status;
    if (body.notes !== undefined) updates.notes = body.notes;
    if (body.items !== undefined) {
      updates.items = body.items;
      const subtotal = body.items.reduce((s, i) => s + i.total, 0);
      const tax = body.tax ?? 0;
      updates.subtotal = String(subtotal);
      updates.tax = String(tax);
      updates.total = String(subtotal + tax);
    }
    const [po] = await db.update(purchaseOrdersTable).set(updates).where(and(eq(purchaseOrdersTable.id, req.params.id as string), eq(purchaseOrdersTable.tenantId, tenantId))).returning();
    if (!po) { res.status(404).json({ error: "Purchase order not found" }); return; }
    await writeAuditLog({ tenantId, userId: req.userId as string, action: "update", resource: "purchase_order", resourceId: po.id, changes: { status: updates.status } });
    res.json(formatPO(po));
  } catch (err) {
    logger.error({ err }, "PATCH /purchase-orders/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

// Receive stock — marks PO as received, updates inventory via transaction engine
router.post("/purchase-orders/:id/receive", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const userId = req.userId as string;
    const poId = req.params.id as string;

    const [po] = await db
      .select()
      .from(purchaseOrdersTable)
      .where(and(eq(purchaseOrdersTable.id, poId), eq(purchaseOrdersTable.tenantId, tenantId)))
      .limit(1);

    if (!po) {
      res.status(404).json({ error: "Purchase order not found" });
      return;
    }
    if (po.status === "received") {
      res.status(400).json({ error: "Purchase order already received" });
      return;
    }
    if (po.status === "cancelled") {
      res.status(400).json({ error: "Cannot receive a cancelled purchase order" });
      return;
    }

    // Mark as received
    const [updated] = await db
      .update(purchaseOrdersTable)
      .set({ status: "received", updatedAt: new Date() })
      .where(and(eq(purchaseOrdersTable.id, poId), eq(purchaseOrdersTable.tenantId, tenantId)))
      .returning();

    // Dispatch stock received event — creates expense transaction + increases inventory
    const items = (po.items as Array<{ description: string; quantity: number; unitPrice: number; total: number }>) ?? [];
    dispatchStockReceived({
      tenantId,
      userId,
      purchaseOrderId: po.id,
      poNumber: po.poNumber,
      supplierName: po.supplierName,
      totalAmount: Number(po.total),
      currency: po.currency,
      items,
    }).catch((err) => logger.error({ err }, "dispatchStockReceived failed"));

    res.json(formatPO(updated));
  } catch (err) {
    logger.error({ err }, "POST /purchase-orders/:id/receive error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/purchase-orders/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const poId = req.params.id as string;
    await db.delete(purchaseOrdersTable).where(and(eq(purchaseOrdersTable.id, poId), eq(purchaseOrdersTable.tenantId, tenantId)));
    await writeAuditLog({ tenantId, userId: req.userId as string, action: "delete", resource: "purchase_order", resourceId: poId, changes: { deleted: true } });
    res.status(204).send();
  } catch (err) {
    logger.error({ err }, "DELETE /purchase-orders/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
