import { Router } from "express";
import { db, leadsTable, ordersTable, customersTable } from "@workspace/db";
import { eq, and, sql } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth";
import { requireFeature } from "../lib/feature-gate";
import { generateId } from "../lib/id";
import { logger } from "../lib/logger";
import { writeAuditLog } from "./audit-logs";
import { createNotification } from "./notifications";

const router = Router();

const gate = requireFeature("crm");

// ---- Leads ----

router.get("/crm/leads", requireAuth, gate, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const { status } = req.query as Record<string, string>;

    const conditions = [
      eq(leadsTable.tenantId, tenantId),
      status ? eq(leadsTable.status, status as any) : undefined,
    ].filter(Boolean) as Parameters<typeof and>;

    const leads = await db
      .select()
      .from(leadsTable)
      .where(and(...conditions))
      .orderBy(sql`created_at desc`);

    res.json(leads.map((l) => ({
      id: l.id,
      name: l.name,
      phone: l.phone,
      email: l.email ?? null,
      source: l.source,
      status: l.status,
      notes: l.notes ?? null,
      createdAt: l.createdAt.toISOString(),
      updatedAt: l.updatedAt.toISOString(),
    })));
  } catch (err) {
    logger.error({ err }, "GET /crm/leads error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/crm/leads", requireAuth, gate, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const body = req.body as {
      name: string;
      phone: string;
      email?: string;
      source?: string;
      status?: string;
      notes?: string;
    };

    const [lead] = await db
      .insert(leadsTable)
      .values({
        id: generateId(),
        tenantId,
        name: body.name,
        phone: body.phone,
        email: body.email,
        source: body.source ?? "whatsapp",
        status: (body.status as any) ?? "new",
        notes: body.notes,
      })
      .returning();

    // Audit log
    await writeAuditLog({
      tenantId,
      userId: req.userId as string,
      action: "create",
      resource: "lead",
      resourceId: lead.id,
      changes: { name: lead.name, phone: lead.phone, source: lead.source },
    });

    // Notify
    await createNotification({
      tenantId,
      userId: req.userId as string,
      type: "new_customer",
      title: "New lead added",
      message: `${lead.name} (${lead.phone}) from ${lead.source} has been added as a new lead.`,
      link: `/crm`,
    });

    res.status(201).json({
      id: lead.id,
      name: lead.name,
      phone: lead.phone,
      email: lead.email ?? null,
      source: lead.source,
      status: lead.status,
      notes: lead.notes ?? null,
      createdAt: lead.createdAt.toISOString(),
      updatedAt: lead.updatedAt.toISOString(),
    });
  } catch (err) {
    logger.error({ err }, "POST /crm/leads error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/crm/leads/:id", requireAuth, gate, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const body = req.body as Partial<{
      name: string;
      phone: string;
      email: string;
      status: string;
      notes: string;
    }>;

    const updates: Partial<typeof leadsTable.$inferInsert> = { updatedAt: new Date() };
    if (body.name !== undefined) updates.name = body.name;
    if (body.phone !== undefined) updates.phone = body.phone;
    if (body.email !== undefined) updates.email = body.email;
    if (body.status !== undefined) updates.status = body.status as any;
    if (body.notes !== undefined) updates.notes = body.notes;

    const [lead] = await db
      .update(leadsTable)
      .set(updates)
      .where(and(eq(leadsTable.id, req.params.id as string), eq(leadsTable.tenantId, tenantId)))
      .returning();

    if (!lead) {
      res.status(404).json({ error: "Lead not found" });
      return;
    }

    // Audit log
    await writeAuditLog({
      tenantId,
      userId: req.userId as string,
      action: "update",
      resource: "lead",
      resourceId: lead.id,
      changes: { name: lead.name, status: lead.status },
    });

    res.json({
      id: lead.id,
      name: lead.name,
      phone: lead.phone,
      email: lead.email ?? null,
      source: lead.source,
      status: lead.status,
      notes: lead.notes ?? null,
      createdAt: lead.createdAt.toISOString(),
      updatedAt: lead.updatedAt.toISOString(),
    });
  } catch (err) {
    logger.error({ err }, "PATCH /crm/leads/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/crm/leads/:id", requireAuth, gate, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const id = req.params.id as string;
    await db
      .delete(leadsTable)
      .where(and(eq(leadsTable.id, id), eq(leadsTable.tenantId, tenantId)));
    // Audit log
    await writeAuditLog({
      tenantId,
      userId: req.userId as string,
      action: "delete",
      resource: "lead",
      resourceId: id,
    });
    res.status(204).send();
  } catch (err) {
    logger.error({ err }, "DELETE /crm/leads/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

// ---- Orders ----

router.get("/crm/orders", requireAuth, gate, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const { status } = req.query as Record<string, string>;

    const conditions = [
      eq(ordersTable.tenantId, tenantId),
      status ? eq(ordersTable.status, status as any) : undefined,
    ].filter(Boolean) as Parameters<typeof and>;

    const orders = await db
      .select()
      .from(ordersTable)
      .where(and(...conditions))
      .orderBy(sql`created_at desc`);

    res.json(orders.map((o) => ({
      id: o.id,
      customerId: o.customerId ?? null,
      leadId: o.leadId ?? null,
      customerName: o.customerName,
      customerPhone: o.customerPhone,
      items: (o.items as unknown[]) ?? [],
      total: Number(o.total),
      currency: o.currency,
      status: o.status,
      notes: o.notes ?? null,
      whatsappNumber: o.whatsappNumber ?? null,
      createdAt: o.createdAt.toISOString(),
      updatedAt: o.updatedAt.toISOString(),
    })));
  } catch (err) {
    logger.error({ err }, "GET /crm/orders error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/crm/orders", requireAuth, gate, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const body = req.body as {
      customerId?: string;
      leadId?: string;
      customerName: string;
      customerPhone: string;
      items: Array<{ name: string; quantity: number; price: number }>;
      total: number;
      currency?: string;
      status?: string;
      notes?: string;
      whatsappNumber?: string;
    };

    const [order] = await db
      .insert(ordersTable)
      .values({
        id: generateId(),
        tenantId,
        customerId: body.customerId,
        leadId: body.leadId,
        customerName: body.customerName,
        customerPhone: body.customerPhone,
        items: body.items as any,
        total: String(body.total),
        currency: body.currency ?? "NGN",
        status: (body.status as any) ?? "pending",
        notes: body.notes,
        whatsappNumber: body.whatsappNumber ?? body.customerPhone,
      })
      .returning();

    // Audit log
    await writeAuditLog({
      tenantId,
      userId: req.userId as string,
      action: "create",
      resource: "crm_order",
      resourceId: order.id,
      changes: { customerName: order.customerName, total: Number(order.total), status: order.status },
    });

    res.status(201).json({
      id: order.id,
      customerId: order.customerId ?? null,
      leadId: order.leadId ?? null,
      customerName: order.customerName,
      customerPhone: order.customerPhone,
      items: (order.items as unknown[]) ?? [],
      total: Number(order.total),
      currency: order.currency,
      status: order.status,
      notes: order.notes ?? null,
      whatsappNumber: order.whatsappNumber ?? null,
      createdAt: order.createdAt.toISOString(),
      updatedAt: order.updatedAt.toISOString(),
    });
  } catch (err) {
    logger.error({ err }, "POST /crm/orders error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/crm/orders/:id", requireAuth, gate, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const body = req.body as Partial<{
      status: string;
      notes: string;
    }>;

    const updates: Partial<typeof ordersTable.$inferInsert> = { updatedAt: new Date() };
    if (body.status !== undefined) updates.status = body.status as any;
    if (body.notes !== undefined) updates.notes = body.notes;

    const [order] = await db
      .update(ordersTable)
      .set(updates)
      .where(and(eq(ordersTable.id, req.params.id as string), eq(ordersTable.tenantId, tenantId)))
      .returning();

    if (!order) {
      res.status(404).json({ error: "Order not found" });
      return;
    }

    // Audit log
    await writeAuditLog({
      tenantId,
      userId: req.userId as string,
      action: "update",
      resource: "crm_order",
      resourceId: order.id,
      changes: { status: order.status, customerName: order.customerName },
    });

    res.json({
      id: order.id,
      customerId: order.customerId ?? null,
      leadId: order.leadId ?? null,
      customerName: order.customerName,
      customerPhone: order.customerPhone,
      items: (order.items as unknown[]) ?? [],
      total: Number(order.total),
      currency: order.currency,
      status: order.status,
      notes: order.notes ?? null,
      whatsappNumber: order.whatsappNumber ?? null,
      createdAt: order.createdAt.toISOString(),
      updatedAt: order.updatedAt.toISOString(),
    });
  } catch (err) {
    logger.error({ err }, "PATCH /crm/orders/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

// ---- WhatsApp Status ----

router.get("/crm/whatsapp/status", requireAuth, gate, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const [leadCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(leadsTable)
      .where(eq(leadsTable.tenantId, tenantId));

    const [orderCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(ordersTable)
      .where(eq(ordersTable.tenantId, tenantId));

    res.json({
      connected: true,
      source: "whatsapp_web",
      leadsCount: leadCount?.count ?? 0,
      ordersCount: orderCount?.count ?? 0,
    });
  } catch (err) {
    logger.error({ err }, "GET /crm/whatsapp/status error");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
