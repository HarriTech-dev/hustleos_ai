import { Router } from "express";
import { db, quotesTable, customersTable, invoicesTable } from "@workspace/db";
import { eq, and, ilike, sql } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth";
import { generateId } from "../lib/id";
import { logger } from "../lib/logger";
import { writeAuditLog } from "./audit-logs";
import { createNotification } from "./notifications";

const router = Router();

function formatQuote(q: typeof quotesTable.$inferSelect) {
  return {
    id: q.id,
    quoteNumber: q.quoteNumber,
    customerId: q.customerId,
    customerName: q.customerName,
    customerEmail: q.customerEmail ?? null,
    status: q.status,
    items: (q.items as unknown[]) ?? [],
    subtotal: Number(q.subtotal),
    discount: Number(q.discount),
    tax: Number(q.tax),
    total: Number(q.total),
    currency: q.currency,
    notes: q.notes ?? null,
    validUntil: q.validUntil,
    invoiceId: q.invoiceId ?? null,
    createdAt: q.createdAt.toISOString(),
  };
}

async function nextQuoteNumber(tenantId: string): Promise<string> {
  const [row] = await db
    .select({ count: sql<number>`count(*)` })
    .from(quotesTable)
    .where(eq(quotesTable.tenantId, tenantId));
  const n = Number(row?.count ?? 0) + 1;
  return `Q-${String(n).padStart(4, "0")}`;
}

router.get("/quotes", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const { status, search } = req.query as Record<string, string>;
    const conditions = [
      eq(quotesTable.tenantId, tenantId),
      status ? eq(quotesTable.status, status as typeof quotesTable.$inferSelect.status) : undefined,
      search ? ilike(quotesTable.customerName, `%${search}%`) : undefined,
    ].filter(Boolean) as Parameters<typeof and>;
    const items = await db.select().from(quotesTable).where(and(...conditions)).orderBy(sql`created_at desc`);
    res.json(items.map(formatQuote));
  } catch (err) {
    logger.error({ err }, "GET /quotes error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/quotes", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const body = req.body as {
      customerId: string;
      items: Array<{ description: string; quantity: number; unitPrice: number; total: number }>;
      tax?: number;
      discount?: number;
      notes?: string;
      validUntil: string;
      currency: string;
    };
    const [customer] = await db.select().from(customersTable).where(eq(customersTable.id, body.customerId)).limit(1);
    const subtotal = body.items.reduce((s, i) => s + i.total, 0);
    const discount = body.discount ?? 0;
    const tax = body.tax ?? 0;
    const total = Math.max(0, subtotal - discount + tax);
    const quoteNumber = await nextQuoteNumber(tenantId);
    const [q] = await db.insert(quotesTable).values({
      id: generateId(),
      tenantId,
      quoteNumber,
      customerId: body.customerId,
      customerName: customer?.name ?? "Unknown Customer",
      customerEmail: customer?.email ?? null,
      status: "draft",
      items: body.items,
      subtotal: String(subtotal),
      discount: String(discount),
      tax: String(tax),
      total: String(total),
      currency: body.currency,
      notes: body.notes,
      validUntil: body.validUntil,
    }).returning();
    await writeAuditLog({
      tenantId, userId: req.userId as string, action: "create", resource: "quote", resourceId: q.id,
      changes: { quoteNumber, customer: customer?.name, total },
    });
    res.status(201).json(formatQuote(q));
  } catch (err) {
    logger.error({ err }, "POST /quotes error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/quotes/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const [q] = await db.select().from(quotesTable).where(and(eq(quotesTable.id, req.params.id as string), eq(quotesTable.tenantId, tenantId))).limit(1);
    if (!q) { res.status(404).json({ error: "Quote not found" }); return; }
    res.json(formatQuote(q));
  } catch (err) {
    logger.error({ err }, "GET /quotes/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/quotes/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const body = req.body as Partial<{ status: string; notes: string; validUntil: string; items: any[]; tax: number; discount: number }>;
    const updates: Partial<typeof quotesTable.$inferInsert> = { updatedAt: new Date() };
    if (body.status !== undefined) updates.status = body.status as typeof quotesTable.$inferSelect.status;
    if (body.notes !== undefined) updates.notes = body.notes;
    if (body.validUntil !== undefined) updates.validUntil = body.validUntil;
    if (body.items !== undefined) {
      updates.items = body.items;
      const subtotal = body.items.reduce((s, i) => s + i.total, 0);
      const discount = body.discount ?? 0;
      const tax = body.tax ?? 0;
      updates.subtotal = String(subtotal);
      updates.discount = String(discount);
      updates.tax = String(tax);
      updates.total = String(Math.max(0, subtotal - discount + tax));
    }
    const [q] = await db.update(quotesTable).set(updates).where(and(eq(quotesTable.id, req.params.id as string), eq(quotesTable.tenantId, tenantId))).returning();
    if (!q) { res.status(404).json({ error: "Quote not found" }); return; }
    await writeAuditLog({ tenantId, userId: req.userId as string, action: "update", resource: "quote", resourceId: q.id, changes: { status: updates.status } });
    res.json(formatQuote(q));
  } catch (err) {
    logger.error({ err }, "PATCH /quotes/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/quotes/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const qId = req.params.id as string;
    await db.delete(quotesTable).where(and(eq(quotesTable.id, qId), eq(quotesTable.tenantId, tenantId)));
    await writeAuditLog({ tenantId, userId: req.userId as string, action: "delete", resource: "quote", resourceId: qId, changes: { deleted: true } });
    res.status(204).send();
  } catch (err) {
    logger.error({ err }, "DELETE /quotes/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

// Convert quote to invoice
router.post("/quotes/:id/convert", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const [q] = await db.select().from(quotesTable).where(and(eq(quotesTable.id, req.params.id as string), eq(quotesTable.tenantId, tenantId))).limit(1);
    if (!q) { res.status(404).json({ error: "Quote not found" }); return; }

    const [count] = await db.select({ count: sql<number>`count(*)` }).from(invoicesTable).where(eq(invoicesTable.tenantId, tenantId));
    const n = Number(count?.count ?? 0) + 1;
    const invoiceNumber = `INV-${String(n).padStart(4, "0")}`;

    const [inv] = await db.insert(invoicesTable).values({
      id: generateId(),
      tenantId,
      invoiceNumber,
      customerId: q.customerId,
      customerName: q.customerName,
      customerEmail: q.customerEmail,
      status: "draft",
      items: q.items,
      subtotal: q.subtotal,
      discount: q.discount,
      tax: q.tax,
      total: q.total,
      amountDue: q.total,
      currency: q.currency,
      notes: q.notes,
      dueDate: new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 10),
    }).returning();

    await db.update(quotesTable).set({ status: "converted", invoiceId: inv.id, updatedAt: new Date() }).where(eq(quotesTable.id, q.id));

    await writeAuditLog({
      tenantId, userId: req.userId as string, action: "convert", resource: "quote", resourceId: q.id,
      changes: { invoiceNumber: inv.invoiceNumber, invoiceId: inv.id },
    });
    await createNotification({
      tenantId, userId: req.userId as string, type: "invoice_paid",
      title: "Quote converted",
      message: `Quote ${q.quoteNumber} converted to invoice ${inv.invoiceNumber}.`,
      link: `/invoices/${inv.id}`,
    });

    res.json({ quote: formatQuote({ ...q, status: "converted", invoiceId: inv.id }), invoice: { id: inv.id, invoiceNumber: inv.invoiceNumber } });
  } catch (err) {
    logger.error({ err }, "POST /quotes/:id/convert error");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
