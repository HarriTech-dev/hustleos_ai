import { Router } from "express";
import { v2 as cloudinary } from "cloudinary";
import { requireAuth } from "../lib/auth";
import { logger } from "../lib/logger";

const uploadRouter = Router();

// Extract base64 data from a data URI
function parseDataUri(uri: string) {
  const match = uri.match(/^data:([\w.+-]+\/[\w.+-]+);base64,(.+)$/);
  if (!match) return null;
  return { mime: match[1], data: match[2] };
}

// Lazy-configure the Cloudinary SDK with whatever keys are available.
// Accepts both uppercase and lowercase env key names.
function getConfig() {
  const cloudName = (process.env.CLOUDINARY_CLOUD_NAME ?? process.env.cloudinary_cloud_name ?? "").trim();
  const apiKey = process.env.CLOUDINARY_API_KEY?.trim();
  const apiSecret = process.env.CLOUDINARY_API_SECRET?.trim();
  return { cloudName, apiKey, apiSecret };
}

function configureCloudinary() {
  const { cloudName, apiKey, apiSecret } = getConfig();
  if (cloudName && apiKey && apiSecret) {
    cloudinary.config({ cloud_name: cloudName, api_key: apiKey, api_secret: apiSecret });
  }
  return { cloudName, apiKey, apiSecret };
}

function extractPublicId(url: string) {
  const match = url.match(/\/v\d+\/(.*?)\.[\w]+$/);
  return match ? match[1] : null;
}

// Upload endpoint
uploadRouter.post("/upload", requireAuth, async (req, res) => {
  const { data: uri, folder = "uploads" } = req.body as { data: string; folder?: string };

  if (!uri || !uri.startsWith("data:")) {
    res.status(400).json({ error: "Missing or invalid file data (must be a base64 data URI)" });
    return;
  }

  const parsed = parseDataUri(uri);
  if (!parsed) {
    res.status(400).json({ error: "Invalid data URI format. Expected: data:<type>;base64,<data>" });
    return;
  }

  const { cloudName, apiKey, apiSecret } = configureCloudinary();
  if (!cloudName || !apiKey || !apiSecret) {
    logger.error({ cloudName: !!cloudName, apiKey: !!apiKey, apiSecret: !!apiSecret }, "Cloudinary env vars missing");
    res.status(500).json({ error: "Cloudinary not configured on server" });
    return;
  }

  const resourceType = parsed.mime.startsWith("video") ? "video" : "image";

  // Validate file size (max 50 MB for video, 5 MB for images)
  const maxSize = resourceType === "video" ? 50 * 1024 * 1024 : 5 * 1024 * 1024;
  const decodedSize = Buffer.from(parsed.data, "base64").length;
  if (decodedSize > maxSize) {
    res.status(413).json({ error: `File too large. Max ${resourceType === "video" ? "50 MB" : "5 MB"}.` });
    return;
  }

  try {
    const result = await cloudinary.uploader.upload(
      `data:${parsed.mime};base64,${parsed.data}`,
      {
        folder,
        resource_type: resourceType,
        // Auto-optimize images
        ...(resourceType === "image" && {
          transformation: [
            { quality: "auto", fetch_format: "auto" },
          ],
        }),
        // Generate video thumbnail
        ...(resourceType === "video" && {
          eager: [{ width: 400, crop: "thumb", gravity: "auto" }],
          eager_async: true,
        }),
      },
    );

    logger.info({ publicId: result.public_id, folder, resourceType }, "Cloudinary upload succeeded");
    res.json({
      url: result.secure_url,
      thumbnailUrl: resourceType === "video" ? result.eager?.[0]?.secure_url : undefined,
      publicId: result.public_id,
      resourceType: result.resource_type,
    });
  } catch (err: any) {
    logger.error({ err: err?.message || err }, "Cloudinary upload failed");
    res.status(502).json({ error: err?.message || "Upload failed" });
  }
});

// Delete endpoint
uploadRouter.delete("/upload/:publicId", requireAuth, async (req, res) => {
  const publicId = req.params.publicId as string;
  if (!publicId) {
    res.status(400).json({ error: "Missing publicId" });
    return;
  }

  const { cloudName, apiKey, apiSecret } = configureCloudinary();
  if (!cloudName || !apiKey || !apiSecret) {
    res.status(500).json({ error: "Cloudinary not configured" });
    return;
  }

  try {
    const result = await cloudinary.uploader.destroy(publicId);
    if (result.result === "ok") {
      res.json({ success: true });
    } else {
      res.status(400).json({ success: false, error: result.result });
    }
  } catch (err: any) {
    logger.error({ err: err?.message || err }, "Cloudinary delete failed");
    res.status(500).json({ error: err?.message || "Delete failed" });
  }
});

export default uploadRouter;
