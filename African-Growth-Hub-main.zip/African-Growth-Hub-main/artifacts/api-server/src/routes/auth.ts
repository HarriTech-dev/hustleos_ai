import { Router } from "express";
import { db, usersTable, teamMembersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth";
import { logger } from "../lib/logger";
import { supabase } from "../lib/supabase";
import { sendEmail, buildWelcomeEmail, buildPasswordResetEmail, isResendConfigured } from "../lib/resend";

const router = Router();

// Public: server-side register using the admin API so email confirmation is skipped
router.post("/auth/register", async (req, res) => {
  try {
    const { email, password, name, businessName, country, currency } = req.body as Record<string, string>;

    if (!email || !password) {
      res.status(400).json({ error: "Email and password are required" });
      return;
    }
    if (password.length < 6) {
      res.status(400).json({ error: "Password must be at least 6 characters" });
      return;
    }

    // Create user via Supabase admin API — email_confirm:true skips the confirmation email
    const { data: supabaseUser, error: createError } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { name, business_name: businessName, country, currency },
    });

    if (createError || !supabaseUser.user) {
      logger.warn({ error: createError?.message }, "POST /auth/register Supabase create failed");
      res.status(400).json({ error: "Registration failed. Please check your details and try again." });
      return;
    }

    const userId = supabaseUser.user.id;
    const userEmail = supabaseUser.user.email ?? email;

    // Pre-create the user row in our public schema so the first API call is instant
    const existing = await db.select().from(usersTable).where(eq(usersTable.id, userId)).limit(1);
    if (existing.length === 0) {
      await db.insert(usersTable).values({
        id: userId,
        email: userEmail,
        name: name || email.split("@")[0],
        tenantId: userId,
        role: "owner",
        businessName: businessName || "",
        currency: (currency as any) || "NGN",
        country: country || null,
      });
    }

    // Send welcome email
    if (isResendConfigured()) {
      const { html, text } = buildWelcomeEmail({ name: name || email.split("@")[0], businessName });
      const emailResult = await sendEmail({ to: userEmail, subject: "Welcome to HustleOS AI!", html, text });
      if (emailResult.error) {
        logger.warn({ error: emailResult.error }, "Welcome email send failed");
      }
    }

    res.status(201).json({ message: "Account created successfully" });
  } catch (err) {
    logger.error({ err }, "POST /auth/register error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/auth/me", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const users = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, req.userId!))
      .limit(1);

    if (!users[0]) {
      res.status(404).json({ error: "User not found" });
      return;
    }

    const u = users[0];

    // Check team membership for role override
    const [teamMember] = await db
      .select()
      .from(teamMembersTable)
      .where(eq(teamMembersTable.userId, req.userId!))
      .limit(1);

    const role = teamMember ? teamMember.role : u.role;

    res.json({
      id: u.id,
      email: u.email,
      name: u.name,
      role,
      avatarUrl: u.avatarUrl ?? null,
      businessName: u.businessName,
      businessLogo: u.businessLogo ?? null,
      currency: u.currency,
      country: u.country ?? null,
      phone: u.phone ?? null,
      createdAt: u.createdAt.toISOString(),
    });
  } catch (err) {
    logger.error({ err }, "GET /auth/me error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/auth/profile", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const { name, businessName, currency, country, phone, avatarUrl, businessLogo } = req.body as Record<string, string>;

    const updates: Partial<typeof usersTable.$inferInsert> = {};
    if (name !== undefined) updates.name = name;
    if (businessName !== undefined) updates.businessName = businessName;
    if (currency !== undefined) updates.currency = currency as typeof updates.currency;
    if (country !== undefined) updates.country = country;
    if (phone !== undefined) updates.phone = phone;
    if (avatarUrl !== undefined) updates.avatarUrl = avatarUrl;
    if (businessLogo !== undefined) updates.businessLogo = businessLogo;

    const updated = await db
      .update(usersTable)
      .set(updates)
      .where(eq(usersTable.id, req.userId!))
      .returning();

    const u = updated[0];
    res.json({
      id: u.id,
      email: u.email,
      name: u.name,
      role: u.role,
      avatarUrl: u.avatarUrl ?? null,
      businessName: u.businessName,
      businessLogo: u.businessLogo ?? null,
      currency: u.currency,
      country: u.country ?? null,
      phone: u.phone ?? null,
      createdAt: u.createdAt.toISOString(),
    });
  } catch (err) {
    logger.error({ err }, "PATCH /auth/profile error");
    res.status(500).json({ error: "Internal server error" });
  }
});

// Password reset - sends email via Supabase auth reset
router.post("/auth/forgot-password", async (req, res) => {
  try {
    const { email } = req.body as { email: string };
    if (!email) {
      res.status(400).json({ error: "Email is required" });
      return;
    }

    const { data, error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${process.env.APP_URL || "https://hustleos.replit.app"}/auth/reset-password`,
    });

    if (error) {
      logger.warn({ error: error.message }, "Supabase password reset failed");
      res.status(400).json({ error: error.message });
      return;
    }

    // Also send our branded email if Resend is configured
    if (isResendConfigured()) {
      const [user] = await db.select().from(usersTable).where(eq(usersTable.email, email)).limit(1);
      const { html, text } = buildPasswordResetEmail({
        name: user?.name || email.split("@")[0],
        resetUrl: `${process.env.APP_URL || "https://hustleos.replit.app"}/auth/reset-password`,
      });
      const emailResult = await sendEmail({ to: email, subject: "Reset your HustleOS AI password", html, text });
      if (emailResult.error) {
        logger.warn({ error: emailResult.error }, "Password reset branded email failed");
      }
    }

    res.json({ message: "If this account exists, a password reset link has been sent." });
  } catch (err) {
    logger.error({ err }, "POST /auth/forgot-password error");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
