import { Router } from "express";
import { db, invoicesTable, customersTable, inventoryTable, transactionsTable, usersTable } from "@workspace/db";
import { eq, and, sql } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth";
import { logger } from "../lib/logger";

const router = Router();

router.get("/reports/monthly", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const { month, year } = req.query as Record<string, string>;

    const m = Number(month) || new Date().getMonth() + 1;
    const y = Number(year) || new Date().getFullYear();

    const periodStart = `${y}-${String(m).padStart(2, "0")}-01`;
    const periodEnd = new Date(y, m, 0).toISOString().slice(0, 10);

    const MONTH_NAMES = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    const period = `${MONTH_NAMES[m - 1]} ${y}`;

    const [user] = await db
      .select({ currency: usersTable.currency })
      .from(usersTable)
      .where(eq(usersTable.id, tenantId))
      .limit(1)
      .catch(() => [{ currency: "NGN" as const }]);
    const currency = user?.currency || "NGN";

    const [invoiceStats] = await db
      .select({
        total: sql<number>`count(*)`,
        paid: sql<number>`count(*) filter (where status = 'paid')`,
        outstanding: sql<number>`count(*) filter (where status = 'sent')`,
        overdue: sql<number>`count(*) filter (where status = 'overdue')`,
        revenue: sql<number>`coalesce(sum(total) filter (where status = 'paid'), 0)`,
      })
      .from(invoicesTable)
      .where(
        and(
          eq(invoicesTable.tenantId, tenantId),
          sql`created_at >= ${periodStart}::date`,
          sql`created_at <= ${periodEnd}::date + interval '1 day'`
        )
      );

    const [txStats] = await db
      .select({
        expenses: sql<number>`coalesce(sum(amount) filter (where type = 'expense'), 0)`,
        income: sql<number>`coalesce(sum(amount) filter (where type = 'income'), 0)`,
      })
      .from(transactionsTable)
      .where(
        and(
          eq(transactionsTable.tenantId, tenantId),
          sql`date >= ${periodStart}`,
          sql`date <= ${periodEnd}`
        )
      );

    const [custCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(customersTable)
      .where(eq(customersTable.tenantId, tenantId));

    const topCustomers = await db
      .select({
        name: invoicesTable.customerName,
        spent: sql<number>`sum(total)`,
      })
      .from(invoicesTable)
      .where(
        and(
          eq(invoicesTable.tenantId, tenantId),
          sql`status = 'paid'`,
          sql`created_at >= ${periodStart}::date`,
          sql`created_at <= ${periodEnd}::date + interval '1 day'`
        )
      )
      .groupBy(invoicesTable.customerName)
      .orderBy(sql`sum(total) desc`)
      .limit(5);

    const [invStats] = await db
      .select({
        totalValue: sql<number>`coalesce(sum(price * quantity), 0)`,
        lowStock: sql<number>`count(*) filter (where quantity <= low_stock_threshold and quantity > 0)`,
      })
      .from(inventoryTable)
      .where(eq(inventoryTable.tenantId, tenantId));

    const revenue = Number(invoiceStats?.revenue || 0);
    const expenses = Number(txStats?.expenses || 0);

    res.json({
      period,
      revenue,
      expenses,
      profit: revenue - expenses,
      currency,
      invoiceStats: {
        total: Number(invoiceStats?.total || 0),
        paid: Number(invoiceStats?.paid || 0),
        outstanding: Number(invoiceStats?.outstanding || 0),
        overdue: Number(invoiceStats?.overdue || 0),
      },
      customerCount: Number(custCount?.count || 0),
      topCustomers: topCustomers.map((c) => ({ name: c.name, spent: Number(c.spent) })),
      inventoryValue: Number(invStats?.totalValue || 0),
      lowStockCount: Number(invStats?.lowStock || 0),
    });
  } catch (err) {
    logger.error({ err }, "GET /reports/monthly error");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
