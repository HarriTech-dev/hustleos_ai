import { Router } from "express";
import { db, invoicesTable, transactionsTable, usersTable } from "@workspace/db";
import { eq, and, gte, sql } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth";
import { requireFeature } from "../lib/feature-gate";
import { logger } from "../lib/logger";

const router = Router();

router.get("/forecasting/revenue", requireAuth, requireFeature("forecasting"), async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const userId = req.userId as string;

    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    const [userRecord] = await db
      .select({ currency: usersTable.currency })
      .from(usersTable)
      .where(eq(usersTable.id, tenantId))
      .limit(1);

    const paidInvoices = await db
      .select({
        month: sql<string>`to_char(paid_at, 'YYYY-MM')`,
        revenue: sql<number>`coalesce(sum(total), 0)`,
      })
      .from(invoicesTable)
      .where(
        and(
          eq(invoicesTable.tenantId, tenantId),
          eq(invoicesTable.status, "paid"),
          gte(invoicesTable.paidAt, sixMonthsAgo),
        ),
      )
      .groupBy(sql`to_char(paid_at, 'YYYY-MM')`)
      .orderBy(sql`to_char(paid_at, 'YYYY-MM')`);

    const incomeByMonth = await db
      .select({
        month: sql<string>`to_char(created_at, 'YYYY-MM')`,
        amount: sql<number>`coalesce(sum(amount), 0)`,
      })
      .from(transactionsTable)
      .where(
        and(
          eq(transactionsTable.tenantId, tenantId),
          eq(transactionsTable.type, "income"),
          gte(transactionsTable.createdAt, sixMonthsAgo),
        ),
      )
      .groupBy(sql`to_char(created_at, 'YYYY-MM')`)
      .orderBy(sql`to_char(created_at, 'YYYY-MM')`);

    const expenseByMonth = await db
      .select({
        month: sql<string>`to_char(created_at, 'YYYY-MM')`,
        amount: sql<number>`coalesce(sum(amount), 0)`,
      })
      .from(transactionsTable)
      .where(
        and(
          eq(transactionsTable.tenantId, tenantId),
          eq(transactionsTable.type, "expense"),
          gte(transactionsTable.createdAt, sixMonthsAgo),
        ),
      )
      .groupBy(sql`to_char(created_at, 'YYYY-MM')`)
      .orderBy(sql`to_char(created_at, 'YYYY-MM')`);

    const months = generateMonths(6);
    const revenueMap = Object.fromEntries(paidInvoices.map((r) => [r.month, Number(r.revenue)]));
    const incomeMap = Object.fromEntries(incomeByMonth.map((r) => [r.month, Number(r.amount)]));
    const expenseMap = Object.fromEntries(expenseByMonth.map((r) => [r.month, Number(r.amount)]));

    const historical = months.map((m) => ({
      month: m.label,
      key: m.key,
      revenue: revenueMap[m.key] ?? 0,
      income: incomeMap[m.key] ?? 0,
      expenses: expenseMap[m.key] ?? 0,
      profit: (incomeMap[m.key] ?? 0) - (expenseMap[m.key] ?? 0),
    }));

    const revenues = historical.map((h) => h.revenue + h.income);
    const forecast = forecastNextMonths(revenues, 3);

    const forecastMonths = generateMonths(3, 1);
    const forecastData = forecastMonths.map((m, i) => ({
      month: m.label,
      key: m.key,
      forecast: Math.max(0, forecast[i] ?? 0),
    }));

    const totalRevenueLast6 = revenues.reduce((a, b) => a + b, 0);
    const avgMonthlyRevenue = revenues.length > 0 ? totalRevenueLast6 / revenues.length : 0;
    const growthRate =
      revenues.length >= 2 && revenues[revenues.length - 2] > 0
        ? ((revenues[revenues.length - 1] - revenues[revenues.length - 2]) / revenues[revenues.length - 2]) * 100
        : 0;

    res.json({
      historical,
      forecast: forecastData,
      summary: {
        avgMonthlyRevenue,
        totalRevenueLast6Months: totalRevenueLast6,
        growthRate: Number(growthRate.toFixed(1)),
        projectedNextMonth: Math.max(0, forecast[0] ?? 0),
        currency: userRecord?.currency ?? "NGN",
      },
    });
  } catch (err) {
    logger.error({ err }, "GET /forecasting/revenue error");
    res.status(500).json({ error: "Internal server error" });
  }
});

function generateMonths(count: number, offsetFromNow = 0): { key: string; label: string }[] {
  const months = [];
  const now = new Date();
  for (let i = count - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() + offsetFromNow + (count - 1 - i) - (count - 1), 1);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    const label = d.toLocaleString("default", { month: "short", year: "2-digit" });
    months.push({ key, label });
  }
  return months;
}

function forecastNextMonths(values: number[], n: number): number[] {
  if (values.length < 2) return Array(n).fill(values[0] ?? 0);
  const last = values[values.length - 1];
  const prev = values[values.length - 2];
  const growthRate = prev > 0 ? (last - prev) / prev : 0;
  const clampedGrowth = Math.max(-0.3, Math.min(0.5, growthRate));
  return Array.from({ length: n }, (_, i) => last * Math.pow(1 + clampedGrowth, i + 1));
}

export default router;
