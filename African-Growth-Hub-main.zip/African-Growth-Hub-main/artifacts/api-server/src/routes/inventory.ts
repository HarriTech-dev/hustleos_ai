import { Router } from "express";
import { db, inventoryTable, stockAdjustmentsTable, usersTable } from "@workspace/db";
import { eq, and, ilike, sql } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth";
import { generateId } from "../lib/id";
import { logger } from "../lib/logger";
import { writeAuditLog } from "./audit-logs";
import { createNotification } from "./notifications";

const router = Router();

function formatItem(item: typeof inventoryTable.$inferSelect) {
  return {
    id: item.id,
    name: item.name,
    sku: item.sku,
    description: item.description ?? null,
    quantity: item.quantity,
    lowStockThreshold: item.lowStockThreshold,
    price: Number(item.price),
    costPrice: Number(item.costPrice),
    category: item.category,
    unit: item.unit,
    imageUrl: item.imageUrl ?? null,
    currency: item.currency,
    createdAt: item.createdAt.toISOString(),
    updatedAt: item.updatedAt.toISOString(),
  };
}

router.get("/inventory", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const { category, search, lowStock } = req.query as Record<string, string>;

    const conditions = [
      eq(inventoryTable.tenantId, tenantId),
      category ? eq(inventoryTable.category, category) : undefined,
      search ? ilike(inventoryTable.name, `%${search}%`) : undefined,
      lowStock === "true" ? sql`quantity <= low_stock_threshold` : undefined,
    ].filter(Boolean) as Parameters<typeof and>;

    const items = await db
      .select()
      .from(inventoryTable)
      .where(and(...conditions))
      .orderBy(sql`created_at desc`);

    res.json(items.map(formatItem));
  } catch (err) {
    logger.error({ err }, "GET /inventory error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/inventory", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const body = req.body as {
      name: string;
      sku: string;
      description?: string;
      quantity: number;
      lowStockThreshold?: number;
      price: number;
      costPrice: number;
      category: string;
      unit: string;
      imageUrl?: string;
      currency?: string;
    };

    const [item] = await db
      .insert(inventoryTable)
      .values({
        id: generateId(),
        tenantId,
        name: body.name,
        sku: body.sku,
        description: body.description,
        quantity: body.quantity,
        lowStockThreshold: body.lowStockThreshold ?? 5,
        price: String(body.price),
        costPrice: String(body.costPrice),
        category: body.category,
        unit: body.unit,
        imageUrl: body.imageUrl,
        currency: body.currency ?? "NGN",
      })
      .returning();

    // Audit log
    await writeAuditLog({
      tenantId,
      userId: req.userId as string,
      action: "create",
      resource: "inventory",
      resourceId: item.id,
      changes: { name: item.name, sku: item.sku, quantity: item.quantity },
    });
    res.status(201).json(formatItem(item));
  } catch (err) {
    logger.error({ err }, "POST /inventory error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/inventory/stats/summary", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const userId = req.userId as string;

    const [stats] = await db
      .select({
        totalItems: sql<number>`count(*)`,
        totalValue: sql<number>`coalesce(sum(price * quantity), 0)`,
        lowStockItems: sql<number>`count(*) filter (where quantity <= low_stock_threshold and quantity > 0)`,
        outOfStockItems: sql<number>`count(*) filter (where quantity = 0)`,
      })
      .from(inventoryTable)
      .where(eq(inventoryTable.tenantId, tenantId));

    const [userRecord] = await db
      .select({ currency: usersTable.currency })
      .from(usersTable)
      .where(eq(usersTable.id, userId))
      .limit(1);

    res.json({
      totalItems: Number(stats?.totalItems ?? 0),
      totalValue: Number(stats?.totalValue ?? 0),
      lowStockItems: Number(stats?.lowStockItems ?? 0),
      outOfStockItems: Number(stats?.outOfStockItems ?? 0),
      currency: userRecord?.currency ?? "NGN",
    });
  } catch (err) {
    logger.error({ err }, "GET /inventory/stats/summary error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/inventory/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const id = req.params.id as string;
    const [item] = await db
      .select()
      .from(inventoryTable)
      .where(and(eq(inventoryTable.id, id), eq(inventoryTable.tenantId, tenantId)))
      .limit(1);

    if (!item) {
      res.status(404).json({ error: "Item not found" });
      return;
    }

    res.json(formatItem(item));
  } catch (err) {
    logger.error({ err }, "GET /inventory/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/inventory/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const id = req.params.id as string;
    const body = req.body as Partial<{
      name: string;
      description: string;
      quantity: number;
      lowStockThreshold: number;
      price: number;
      costPrice: number;
      category: string;
      unit: string;
      imageUrl: string;
    }>;

    const updates: Partial<typeof inventoryTable.$inferInsert> = { updatedAt: new Date() };
    if (body.name !== undefined) updates.name = body.name;
    if (body.description !== undefined) updates.description = body.description;
    if (body.quantity !== undefined) updates.quantity = body.quantity;
    if (body.lowStockThreshold !== undefined) updates.lowStockThreshold = body.lowStockThreshold;
    if (body.price !== undefined) updates.price = String(body.price);
    if (body.costPrice !== undefined) updates.costPrice = String(body.costPrice);
    if (body.category !== undefined) updates.category = body.category;
    if (body.unit !== undefined) updates.unit = body.unit;
    if (body.imageUrl !== undefined) updates.imageUrl = body.imageUrl;

    const [item] = await db
      .update(inventoryTable)
      .set(updates)
      .where(and(eq(inventoryTable.id, id), eq(inventoryTable.tenantId, tenantId)))
      .returning();

    if (!item) {
      res.status(404).json({ error: "Item not found" });
      return;
    }
    // Audit log
    await writeAuditLog({
      tenantId,
      userId: req.userId as string,
      action: "update",
      resource: "inventory",
      resourceId: item.id,
      changes: { name: item.name, quantity: item.quantity, price: item.price },
    });
    res.json(formatItem(item));
  } catch (err) {
    logger.error({ err }, "PATCH /inventory/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/inventory/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const id = req.params.id as string;
    await db
      .delete(inventoryTable)
      .where(and(eq(inventoryTable.id, id), eq(inventoryTable.tenantId, tenantId)));
    // Audit log
    await writeAuditLog({
      tenantId,
      userId: req.userId as string,
      action: "delete",
      resource: "inventory",
      resourceId: id,
    });
    res.status(204).send();
  } catch (err) {
    logger.error({ err }, "DELETE /inventory/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/inventory/:id/adjustments", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const id = req.params.id as string;
    const items = await db
      .select()
      .from(stockAdjustmentsTable)
      .where(and(eq(stockAdjustmentsTable.inventoryId, id), eq(stockAdjustmentsTable.tenantId, tenantId)))
      .orderBy(sql`created_at desc`)
      .limit(50);
    res.json(items.map((a) => ({ ...a, createdAt: a.createdAt.toISOString() })));
  } catch (err) {
    logger.error({ err }, "GET /inventory/:id/adjustments error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/inventory/:id/adjust", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const id = req.params.id as string;
    const { adjustment, reason, notes } = req.body as {
      adjustment: number;
      reason: string;
      notes?: string;
    };

    const [existing] = await db
      .select()
      .from(inventoryTable)
      .where(and(eq(inventoryTable.id, id), eq(inventoryTable.tenantId, tenantId)))
      .limit(1);

    if (!existing) {
      res.status(404).json({ error: "Item not found" });
      return;
    }

    const newQty = Math.max(0, existing.quantity + adjustment);
    const actualAdjustment = newQty - existing.quantity; // actual change after floor clamp

    const [item] = await db
      .update(inventoryTable)
      .set({ quantity: newQty, updatedAt: new Date() })
      .where(eq(inventoryTable.id, id))
      .returning();

    await db.insert(stockAdjustmentsTable).values({
      id: generateId(),
      inventoryId: id,
      tenantId,
      adjustment: actualAdjustment,
      reason,
      notes,
    });

    // Audit log
    await writeAuditLog({
      tenantId,
      userId: req.userId as string,
      action: "adjust",
      resource: "inventory",
      resourceId: id,
      changes: { name: existing.name, previousQty: existing.quantity, newQty, adjustment, reason },
    });

    res.json(formatItem(item));
  } catch (err) {
    logger.error({ err }, "POST /inventory/:id/adjust error");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
