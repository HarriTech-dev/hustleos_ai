import { Router } from "express";
import { db, trainingVideosTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth";
import { generateId } from "../lib/id";
import { logger } from "../lib/logger";

const router = Router();

router.get("/training-videos", requireAuth, async (req: AuthenticatedRequest, res) => {
  const tenantId = req.tenantId as string;
  try {
    const videos = await db.select().from(trainingVideosTable).where(eq(trainingVideosTable.tenantId, tenantId)).orderBy(trainingVideosTable.createdAt);
    res.json(videos);
  } catch (err) {
    logger.error({ err }, "Failed to list training videos");
    res.status(500).json({ error: "Failed to list videos" });
  }
});

router.post("/training-videos", requireAuth, async (req: AuthenticatedRequest, res) => {
  const tenantId = req.tenantId as string;
  const { title, description, videoUrl, thumbnailUrl, category } = req.body;

  if (!title || !videoUrl) {
    res.status(400).json({ error: "Title and video URL are required" });
    return;
  }

  try {
    const [video] = await db.insert(trainingVideosTable).values({
      id: generateId(),
      tenantId,
      title,
      description: description || null,
      videoUrl,
      thumbnailUrl: thumbnailUrl || null,
      category: category || "general",
    }).returning();
    res.status(201).json(video);
  } catch (err) {
    logger.error({ err }, "Failed to create training video");
    res.status(500).json({ error: "Failed to create video" });
  }
});

router.get("/training-videos/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  const tenantId = req.tenantId as string;
  const id = req.params.id as string;
  try {
    const [video] = await db.select().from(trainingVideosTable).where(
      and(eq(trainingVideosTable.id, id), eq(trainingVideosTable.tenantId, tenantId))
    ).limit(1);
    if (!video) {
      res.status(404).json({ error: "Video not found" });
      return;
    }
    res.json(video);
  } catch (err) {
    logger.error({ err }, "Failed to get training video");
    res.status(500).json({ error: "Failed to get video" });
  }
});

router.delete("/training-videos/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  const tenantId = req.tenantId as string;
  const id = req.params.id as string;
  try {
    const [video] = await db.select().from(trainingVideosTable).where(
      and(eq(trainingVideosTable.id, id), eq(trainingVideosTable.tenantId, tenantId))
    ).limit(1);
    if (!video) {
      res.status(404).json({ error: "Video not found" });
      return;
    }
    await db.delete(trainingVideosTable).where(
      and(eq(trainingVideosTable.id, id), eq(trainingVideosTable.tenantId, tenantId))
    );
    res.json({ success: true });
  } catch (err) {
    logger.error({ err }, "Failed to delete training video");
    res.status(500).json({ error: "Failed to delete video" });
  }
});

export default router;
