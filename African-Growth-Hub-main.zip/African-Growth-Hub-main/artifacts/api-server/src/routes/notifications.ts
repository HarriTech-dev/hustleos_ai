import { Router } from "express";
import { db, notificationsTable } from "@workspace/db";
import { eq, and, desc } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth";
import { requireFeature } from "../lib/feature-gate";
import { generateId } from "../lib/id";
import { logger } from "../lib/logger";

const router = Router();

const gate = requireFeature("notifications");

router.get("/notifications", requireAuth, gate, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.userId as string;
    const tenantId = req.tenantId as string;
    const { unread } = req.query as Record<string, string>;

    const conditions = [eq(notificationsTable.tenantId, tenantId)];
    if (unread === "true") conditions.push(eq(notificationsTable.read, false));

    const items = await db
      .select()
      .from(notificationsTable)
      .where(and(...conditions))
      .orderBy(desc(notificationsTable.createdAt))
      .limit(50);

    const unreadCount = items.filter((n) => !n.read).length;
    res.json({ items, unreadCount });
  } catch (err) {
    logger.error({ err }, "GET /notifications error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/notifications/:id/read", requireAuth, gate, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const [n] = await db
      .update(notificationsTable)
      .set({ read: true })
      .where(and(eq(notificationsTable.id, req.params.id as string), eq(notificationsTable.tenantId, tenantId)))
      .returning();

    if (!n) { res.status(404).json({ error: "Not found" }); return; }
    res.json(n);
  } catch (err) {
    logger.error({ err }, "POST /notifications/:id/read error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/notifications/read-all", requireAuth, gate, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    await db
      .update(notificationsTable)
      .set({ read: true })
      .where(eq(notificationsTable.tenantId, tenantId));
    res.json({ ok: true });
  } catch (err) {
    logger.error({ err }, "POST /notifications/read-all error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/notifications/:id", requireAuth, gate, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    await db
      .delete(notificationsTable)
      .where(and(eq(notificationsTable.id, req.params.id as string), eq(notificationsTable.tenantId, tenantId)));
    res.status(204).send();
  } catch (err) {
    logger.error({ err }, "DELETE /notifications/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

export { router as notificationsRouter };

export async function createNotification(params: {
  tenantId: string;
  userId: string;
  type: typeof notificationsTable.$inferInsert["type"];
  title: string;
  message: string;
  link?: string;
}) {
  try {
    await db.insert(notificationsTable).values({
      id: generateId(),
      ...params,
    });
  } catch (err) {
    logger.error({ err }, "createNotification error");
  }
}

export default router;
