import { Router } from "express";
import { db, teamMembersTable, usersTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth";
import { requireFeature } from "../lib/feature-gate";
import { generateId } from "../lib/id";
import { logger } from "../lib/logger";
import { writeAuditLog } from "./audit-logs";
import { createNotification } from "./notifications";
import { sendEmail, buildTeamInviteEmail, isResendConfigured } from "../lib/resend";
import { randomBytes } from "crypto";

const router = Router();

const gate = requireFeature("team_full");

function generateInviteToken(): string {
  return randomBytes(16).toString("hex");
}

function formatMember(m: typeof teamMembersTable.$inferSelect) {
  return {
    id: m.id,
    name: m.name,
    email: m.email,
    role: m.role,
    status: m.status,
    avatarUrl: m.avatarUrl ?? null,
    inviteToken: m.inviteToken ?? undefined,
    joinedAt: m.joinedAt.toISOString(),
  };
}

router.get("/team/members", requireAuth, gate, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const members = await db
      .select()
      .from(teamMembersTable)
      .where(eq(teamMembersTable.tenantId, tenantId));

    res.json(members.map(formatMember));
  } catch (err) {
    logger.error({ err }, "GET /team/members error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/team/members", requireAuth, gate, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const { email, role, name } = req.body as { email: string; role: string; name?: string };

    const inviteToken = generateInviteToken();
    const inviteExpiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days

    const [member] = await db
      .insert(teamMembersTable)
      .values({
        id: generateId(),
        tenantId,
        name: name ?? email.split("@")[0],
        email,
        role: role as typeof teamMembersTable.$inferSelect.role,
        status: "invited",
        inviteToken,
        inviteExpiresAt,
      })
      .returning();

    // Audit log
    await writeAuditLog({
      tenantId,
      userId: req.userId as string,
      action: "create",
      resource: "team_member",
      resourceId: member.id,
      changes: { name: member.name, email: member.email, role: member.role },
    });

    // Notify
    await createNotification({
      tenantId,
      userId: req.userId as string,
      type: "team_invite",
      title: "Team member invited",
      message: `${member.name} (${member.email}) has been invited as ${member.role}.`,
      link: `/team`,
    });

    // Send email invite if Resend is configured
    if (isResendConfigured()) {
      const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.userId as string)).limit(1);
      const joinUrl = `${process.env.APP_URL || "https://hustleos.replit.app"}/join/${inviteToken}`;
      const { html, text } = buildTeamInviteEmail({
        inviteeName: member.name,
        inviterName: user?.name || "Your team",
        businessName: user?.businessName || "HustleOS AI",
        role: member.role,
        joinUrl,
      });
      const emailResult = await sendEmail({ to: member.email, subject: `You've been invited to ${user?.businessName || "HustleOS AI"}`, html, text });
      if (emailResult.error) {
        logger.warn({ error: emailResult.error }, "Team invite email send failed");
      }
    }

    res.status(201).json(formatMember(member));
  } catch (err) {
    logger.error({ err }, "POST /team/members error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/team/members/:id", requireAuth, gate, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const { role, status } = req.body as Partial<{ role: string; status: string }>;

    const updates: Partial<typeof teamMembersTable.$inferInsert> = {};
    if (role !== undefined) updates.role = role as typeof teamMembersTable.$inferSelect.role;
    if (status !== undefined) updates.status = status as typeof teamMembersTable.$inferSelect.status;

    const [member] = await db
      .update(teamMembersTable)
      .set(updates)
      .where(and(eq(teamMembersTable.id, req.params.id as string), eq(teamMembersTable.tenantId, tenantId)))
      .returning();

    if (!member) {
      res.status(404).json({ error: "Team member not found" });
      return;
    }
    // Audit log
    await writeAuditLog({
      tenantId,
      userId: req.userId as string,
      action: "update",
      resource: "team_member",
      resourceId: member.id,
      changes: { role: member.role, status: member.status },
    });
    res.json(formatMember(member));
  } catch (err) {
    logger.error({ err }, "PATCH /team/members/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/team/members/:id", requireAuth, gate, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const id = req.params.id as string;
    await db
      .delete(teamMembersTable)
      .where(and(eq(teamMembersTable.id, id), eq(teamMembersTable.tenantId, tenantId)));
    // Audit log
    await writeAuditLog({
      tenantId,
      userId: req.userId as string,
      action: "delete",
      resource: "team_member",
      resourceId: id,
    });
    res.status(204).send();
  } catch (err) {
    logger.error({ err }, "DELETE /team/members/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

// Public endpoint — lookup invite by token (no auth required)
router.get("/team/invite/:token", async (req, res) => {
  try {
    const token = req.params.token as string;
    const [member] = await db
      .select()
      .from(teamMembersTable)
      .where(eq(teamMembersTable.inviteToken, token))
      .limit(1);

    if (!member) {
      res.status(404).json({ error: "Invitation not found" });
      return;
    }

    if (member.inviteExpiresAt && new Date(member.inviteExpiresAt) < new Date()) {
      res.status(410).json({ error: "Invitation has expired" });
      return;
    }

    if (member.status !== "invited") {
      res.status(409).json({ error: "Invitation already used" });
      return;
    }

    // Look up inviter name
    const [inviter] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, member.tenantId))
      .limit(1);

    res.json({
      id: member.id,
      name: member.name,
      email: member.email,
      role: member.role,
      businessName: inviter?.businessName || "HustleOS AI",
      inviterName: inviter?.name || "Your team",
    });
  } catch (err) {
    logger.error({ err }, "GET /team/invite/:token error");
    res.status(500).json({ error: "Internal server error" });
  }
});

// Accept invite — requires authentication (user must be logged in)
router.post("/team/invite/:token/accept", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const token = req.params.token as string;
    const userId = req.userId as string;

    const [member] = await db
      .select()
      .from(teamMembersTable)
      .where(eq(teamMembersTable.inviteToken, token))
      .limit(1);

    if (!member) {
      res.status(404).json({ error: "Invitation not found" });
      return;
    }

    if (member.inviteExpiresAt && new Date(member.inviteExpiresAt) < new Date()) {
      res.status(410).json({ error: "Invitation has expired" });
      return;
    }

    if (member.status !== "invited") {
      res.status(409).json({ error: "Invitation already used" });
      return;
    }

    const [updated] = await db
      .update(teamMembersTable)
      .set({
        userId,
        status: "active",
        inviteToken: null,
        inviteExpiresAt: null,
      })
      .where(eq(teamMembersTable.id, member.id))
      .returning();

    // Audit log
    await writeAuditLog({
      tenantId: member.tenantId,
      userId,
      action: "update",
      resource: "team_member",
      resourceId: member.id,
      changes: { status: "active", userId },
    });

    // Notify owner
    await createNotification({
      tenantId: member.tenantId,
      userId: member.tenantId,
      type: "team_invite",
      title: "Invitation accepted",
      message: `${updated.name} has joined your team as ${updated.role}.`,
      link: `/team`,
    });

    res.json(formatMember(updated));
  } catch (err) {
    logger.error({ err }, "POST /team/invite/:token/accept error");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
