import { Router } from "express";
import { db, invoicesTable, customersTable, inventoryTable, usersTable } from "@workspace/db";
import { eq, and, gte, lte, sql, count } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth";
import { logger } from "../lib/logger";

const router = Router();

router.get("/dashboard/summary", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;

    const [invoiceStats] = await db
      .select({
        total: count(),
        paid: sql<number>`count(*) filter (where status = 'paid')`,
        overdue: sql<number>`count(*) filter (where status = 'overdue')`,
        totalRevenue: sql<number>`coalesce(sum(total) filter (where status = 'paid'), 0)`,
      })
      .from(invoicesTable)
      .where(eq(invoicesTable.tenantId, tenantId));

    const [customerStats] = await db
      .select({ total: count() })
      .from(customersTable)
      .where(eq(customersTable.tenantId, tenantId));

    const [inventoryStats] = await db
      .select({
        total: count(),
        lowStock: sql<number>`count(*) filter (where quantity <= low_stock_threshold and quantity > 0)`,
      })
      .from(inventoryTable)
      .where(eq(inventoryTable.tenantId, tenantId));

    // Growth: compare this month vs last month revenue
    const now = new Date();
    const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const lastMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1);

    const [thisMonth] = await db
      .select({ rev: sql<number>`coalesce(sum(total), 0)` })
      .from(invoicesTable)
      .where(
        and(
          eq(invoicesTable.tenantId, tenantId),
          eq(invoicesTable.status, "paid"),
          gte(invoicesTable.createdAt, thisMonthStart)
        )
      );

    const [lastMonth] = await db
      .select({ rev: sql<number>`coalesce(sum(total), 0)` })
      .from(invoicesTable)
      .where(
        and(
          eq(invoicesTable.tenantId, tenantId),
          eq(invoicesTable.status, "paid"),
          gte(invoicesTable.createdAt, lastMonthStart),
          lte(invoicesTable.createdAt, thisMonthStart)
        )
      );

    const lastRev = Number(lastMonth?.rev ?? 0);
    const thisRev = Number(thisMonth?.rev ?? 0);
    const revenueGrowth = lastRev === 0 ? 0 : ((thisRev - lastRev) / lastRev) * 100;

    const [userRecord] = await db
      .select({ currency: usersTable.currency })
      .from(usersTable)
      .where(eq(usersTable.id, req.userId as string))
      .limit(1);

    res.json({
      totalRevenue: Number(invoiceStats?.totalRevenue ?? 0),
      totalInvoices: Number(invoiceStats?.total ?? 0),
      paidInvoices: Number(invoiceStats?.paid ?? 0),
      overdueInvoices: Number(invoiceStats?.overdue ?? 0),
      totalCustomers: Number(customerStats?.total ?? 0),
      totalProducts: Number(inventoryStats?.total ?? 0),
      lowStockCount: Number(inventoryStats?.lowStock ?? 0),
      revenueGrowth: Math.round(revenueGrowth * 10) / 10,
      currency: userRecord?.currency ?? "NGN",
    });
  } catch (err) {
    logger.error({ err }, "GET /dashboard/summary error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/dashboard/revenue-chart", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const period = (req.query.period as string) ?? "30d";

    let months = 6;
    if (period === "7d") months = 1;
    else if (period === "30d") months = 1;
    else if (period === "90d") months = 3;
    else if (period === "12m") months = 12;

    const now = new Date();
    const startDate = new Date(now.getFullYear(), now.getMonth() - (months - 1), 1);

    // Single query with GROUP BY — no loop, no N+1
    const revenueRows = await db
      .select({
        yearMonth: sql<string>`to_char(date_trunc('month', created_at), 'YYYY-MM')`,
        label: sql<string>`to_char(date_trunc('month', created_at), 'Mon')`,
        rev: sql<number>`coalesce(sum(total), 0)`,
      })
      .from(invoicesTable)
      .where(
        and(
          eq(invoicesTable.tenantId, tenantId),
          eq(invoicesTable.status, "paid"),
          gte(invoicesTable.createdAt, startDate),
        )
      )
      .groupBy(sql`date_trunc('month', created_at)`)
      .orderBy(sql`date_trunc('month', created_at)`);

    const revenueByMonth = new Map(
      revenueRows.map((r) => [r.yearMonth, Number(r.rev)])
    );

    // Fill in zeros for months with no paid invoices
    const points: { label: string; value: number }[] = [];
    for (let i = months - 1; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const ym = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      const label = d.toLocaleString("default", { month: "short" });
      points.push({ label, value: revenueByMonth.get(ym) ?? 0 });
    }

    res.json(points.map((p) => ({ label: p.label, value: p.value, secondary: null })));
  } catch (err) {
    logger.error({ err }, "GET /dashboard/revenue-chart error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/dashboard/recent-activity", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;

    const recentInvoices = await db
      .select()
      .from(invoicesTable)
      .where(eq(invoicesTable.tenantId, tenantId))
      .orderBy(sql`created_at desc`)
      .limit(10);

    const activities = recentInvoices.map((inv) => ({
      id: inv.id,
      type: inv.status === "paid" ? "invoice_paid" : "invoice_created",
      title: inv.status === "paid" ? `Invoice paid: ${inv.invoiceNumber}` : `Invoice created: ${inv.invoiceNumber}`,
      description: `${inv.customerName} — ${inv.currency} ${Number(inv.total).toLocaleString()}`,
      amount: Number(inv.total),
      currency: inv.currency,
      createdAt: inv.createdAt.toISOString(),
    }));

    res.json(activities);
  } catch (err) {
    logger.error({ err }, "GET /dashboard/recent-activity error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/dashboard/top-products", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;

    const items = await db
      .select()
      .from(inventoryTable)
      .where(eq(inventoryTable.tenantId, tenantId))
      .orderBy(sql`price desc`)
      .limit(5);

    const top = items.map((item) => ({
      id: item.id,
      name: item.name,
      revenue: Number(item.price) * Number(item.quantity),
      unitsSold: Number(item.quantity),
      category: item.category ?? null,
    }));

    res.json(top);
  } catch (err) {
    logger.error({ err }, "GET /dashboard/top-products error");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
