import { Router } from "express";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth";
import { requireFeature } from "../lib/feature-gate";
import { logger } from "../lib/logger";

const router = Router();

const gate = requireFeature("ai_marketing");

const MARKETING_SYSTEM_PROMPT = `You are an elite marketing copywriter specializing in African businesses. You craft high-converting, emotionally resonant marketing content for African entrepreneurs across Nigeria, Ghana, Kenya, South Africa, Uganda, Tanzania, and beyond.

Your copy:
- Uses culturally relevant language, references, and context
- Acknowledges local payment methods (Paystack, Flutterwave, M-Pesa, mobile money)
- Speaks to real African consumer motivations (family, hustle, ambition, value)
- Balances aspiration with affordability
- Uses natural, conversational English with local flavor where appropriate
- Drives action with clear, compelling CTAs

Always output ONLY the finished marketing copy — no explanations, no labels, no meta-commentary.`;

const TEMPLATE_PROMPTS: Record<string, { instruction: string; format: string; charLimit: string }> = {
  "facebook-ad": {
    instruction: "Write a Facebook ad that stops the scroll. Start with a powerful hook question or bold statement. Follow with 2-3 punchy benefit lines. End with a strong CTA.",
    format: "Hook (1 line) + Benefits (2-3 lines) + CTA (1 line)",
    charLimit: "Under 150 words",
  },
  "whatsapp-broadcast": {
    instruction: "Write a WhatsApp broadcast message. Make it feel like a personal message from a friend, not a corporate ad. Use emojis naturally. Include a clear next step.",
    format: "Greeting + Offer + Details + Call to action",
    charLimit: "Under 80 words",
  },
  "instagram-caption": {
    instruction: "Write an Instagram caption with a strong visual hook, storytelling middle, and CTA. End with 5-8 highly relevant hashtags including African and niche-specific ones.",
    format: "Hook + Story/Value + CTA + Hashtags",
    charLimit: "Under 200 words",
  },
  "product-description": {
    instruction: "Write a product description that sells. Lead with the transformation/benefit, not the features. Address a pain point, present the product as the solution. Include price anchoring if given.",
    format: "Problem → Solution → Benefits → CTA",
    charLimit: "Under 120 words",
  },
  "flyer-copy": {
    instruction: "Write flyer copy with a bold headline, an irresistible offer, key details, and contact prompt. Make it punchy — someone should be able to read it in 5 seconds.",
    format: "BIG HEADLINE + Offer + Details + Contact/CTA",
    charLimit: "Under 60 words",
  },
  "sms-blast": {
    instruction: "Write a crisp SMS marketing message. Every word must earn its place. Include offer, urgency, and a link/number placeholder. SMS is intimate — keep it real.",
    format: "Offer + Urgency + Action",
    charLimit: "Under 30 words (160 chars)",
  },
  "email-newsletter": {
    instruction: "Write a marketing email with a compelling subject line, warm opener, value-packed body, and clear CTA button text. Make the subject line irresistible.",
    format: "Subject: [Line]\n\nBody with opener + value + CTA",
    charLimit: "Under 250 words",
  },
  "holiday-campaign": {
    instruction: "Write a festive campaign message tied to the season (Eid, Christmas, Detty December, New Year, etc.). Make it celebratory, warm, and generous-feeling while including an offer.",
    format: "Festive greeting + Offer + CTA",
    charLimit: "Under 100 words",
  },
  "sales-campaign": {
    instruction: "Write a high-urgency sales campaign with genuine scarcity or time pressure. Use power words. Make people feel they will miss out. Be honest but compelling.",
    format: "Urgency hook + Offer + Scarcity + CTA",
    charLimit: "Under 100 words",
  },
  "customer-win-back": {
    instruction: "Write a win-back message for customers who haven't purchased recently. Acknowledge the gap, offer something valuable, make it easy to return. Warm and genuine — no guilt.",
    format: "Reconnect + Value offer + Easy CTA",
    charLimit: "Under 80 words",
  },
  "referral-program": {
    instruction: "Write a referral program announcement. Explain the reward clearly, make sharing feel easy and exciting, and highlight the mutual benefit.",
    format: "Announcement + How it works + Reward + CTA",
    charLimit: "Under 100 words",
  },
  "grand-opening": {
    instruction: "Write a grand opening announcement that creates excitement and FOMO. Make it feel like an event people cannot miss. Include date, location (placeholder), and opening offer.",
    format: "Excitement hook + What + When/Where + Opening offer + CTA",
    charLimit: "Under 120 words",
  },
};

async function callOpenAI(prompt: string): Promise<string> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) throw new Error("OPENAI_API_KEY not configured");
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: MARKETING_SYSTEM_PROMPT },
        { role: "user", content: prompt },
      ],
      max_tokens: 700,
      temperature: 0.85,
    }),
  });
  if (!res.ok) throw new Error(`OpenAI error: ${await res.text()}`);
  const data = (await res.json()) as { choices: Array<{ message: { content: string } }> };
  return (data.choices[0]?.message?.content ?? "").trim();
}

const FIELD_MAX = 200;
const EXTRA_INFO_MAX = 500;

router.post("/ai/marketing", requireAuth, gate, async (req: AuthenticatedRequest, res) => {
  try {
    const { type, businessType, product, audience, tone, extraInfo, variations = 1 } = req.body as {
      type: string;
      businessType?: string;
      product?: string;
      audience?: string;
      tone?: string;
      extraInfo?: string;
      variations?: number;
    };

    if (!type || !TEMPLATE_PROMPTS[type]) {
      res.status(400).json({ error: "Invalid template type. Supported: " + Object.keys(TEMPLATE_PROMPTS).join(", ") });
      return;
    }

    if (businessType && businessType.length > FIELD_MAX) {
      res.status(400).json({ error: `businessType must be ${FIELD_MAX} characters or fewer` });
      return;
    }
    if (product && product.length > FIELD_MAX) {
      res.status(400).json({ error: `product must be ${FIELD_MAX} characters or fewer` });
      return;
    }
    if (audience && audience.length > FIELD_MAX) {
      res.status(400).json({ error: `audience must be ${FIELD_MAX} characters or fewer` });
      return;
    }
    if (tone && tone.length > FIELD_MAX) {
      res.status(400).json({ error: `tone must be ${FIELD_MAX} characters or fewer` });
      return;
    }
    if (extraInfo && extraInfo.length > EXTRA_INFO_MAX) {
      res.status(400).json({ error: `extraInfo must be ${EXTRA_INFO_MAX} characters or fewer` });
      return;
    }

    const tpl = TEMPLATE_PROMPTS[type];
    const numVariations = Math.min(Math.max(Number(variations) || 1, 1), 3);

    const context = [
      `Business type: ${businessType || "African SME"}`,
      `Product/Service: ${product || "Not specified"}`,
      `Target audience: ${audience || "General African market"}`,
      `Tone/Voice: ${tone || "Friendly and professional"}`,
      extraInfo ? `Additional details: ${extraInfo}` : null,
      `Format: ${tpl.format}`,
      `Length: ${tpl.charLimit}`,
      numVariations > 1 ? `Generate ${numVariations} distinct variations, separated by "---"` : null,
    ].filter(Boolean).join("\n");

    const prompt = `${tpl.instruction}\n\n${context}`;
    const raw = await callOpenAI(prompt);

    const contents = numVariations > 1
      ? raw.split(/\n?---\n?/).map((s) => s.trim()).filter(Boolean)
      : [raw];

    res.json({
      type,
      content: contents[0] ?? raw,
      variations: contents,
      templateName: type.replace(/-/g, " ").replace(/\b\w/g, (l) => l.toUpperCase()),
      createdAt: new Date().toISOString(),
    });
  } catch (err) {
    logger.error({ err }, "POST /ai/marketing error");
    res.status(500).json({ error: "Failed to generate marketing content" });
  }
});

router.get("/ai/marketing/templates", requireAuth, gate, async (_req, res) => {
  res.json(
    Object.entries(TEMPLATE_PROMPTS).map(([id, tpl]) => ({
      id,
      name: id.replace(/-/g, " ").replace(/\b\w/g, (l) => l.toUpperCase()),
      charLimit: tpl.charLimit,
      format: tpl.format,
    }))
  );
});

export default router;
