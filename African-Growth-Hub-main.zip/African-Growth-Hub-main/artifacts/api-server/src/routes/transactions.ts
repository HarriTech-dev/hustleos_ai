import { Router } from "express";
import { db, transactionsTable, transactionItemsTable, inventoryTable, stockAdjustmentsTable, invoicesTable, customersTable } from "@workspace/db";
import { eq, and, gte, lte, ilike, sql, inArray } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth";
import { generateId } from "../lib/id";
import { logger } from "../lib/logger";
import { writeAuditLog } from "./audit-logs";
import { createNotification } from "./notifications";

const router = Router();

function fmt(t: typeof transactionsTable.$inferSelect) {
  return {
    id: t.id,
    type: t.type,
    amount: Number(t.amount),
    description: t.description,
    category: t.category,
    date: t.date,
    notes: t.notes ?? null,
    parsedFrom: t.parsedFrom ?? null,
    paymentMethod: t.paymentMethod ?? null,
    customerId: t.customerId ?? null,
    invoiceId: t.invoiceId ?? null,
    createdAt: t.createdAt.toISOString(),
  };
}

function fmtItem(i: typeof transactionItemsTable.$inferSelect) {
  return {
    id: i.id,
    transactionId: i.transactionId,
    inventoryId: i.inventoryId ?? null,
    productName: i.productName,
    quantity: i.quantity,
    unitPrice: Number(i.unitPrice),
    subtotal: Number(i.subtotal),
  };
}

async function callOpenAI(prompt: string): Promise<string> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) throw new Error("OPENAI_API_KEY not configured");
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `You are a financial data extractor for African businesses. Parse natural language transaction descriptions and return ONLY valid JSON with these fields:
- type: "income" or "expense"
- amount: number (extract the numeric value, handle k=thousands e.g. "5k"=5000)
- description: string (clean description)
- category: one of: sales, services, inventory, rent, utilities, salaries, marketing, transport, food, equipment, transfer, refund, other
- date: today's date in YYYY-MM-DD format

Examples:
"bought 10 bags of rice for 50000 naira" → {"type":"expense","amount":50000,"description":"10 bags of rice","category":"inventory","date":"2024-01-15"}
"received 150k from Emeka for website design" → {"type":"income","amount":150000,"description":"Website design payment from Emeka","category":"services","date":"2024-01-15"}
"paid office rent 80,000" → {"type":"expense","amount":80000,"description":"Office rent payment","category":"rent","date":"2024-01-15"}

Return ONLY the JSON object, no markdown, no explanation.`,
        },
        { role: "user", content: prompt },
      ],
      max_tokens: 200,
      temperature: 0.1,
    }),
  });
  if (!res.ok) throw new Error(`OpenAI error: ${await res.text()}`);
  const data = (await res.json()) as { choices: Array<{ message: { content: string } }> };
  return data.choices[0]?.message?.content ?? "{}";
}

// ─── GET /transactions ───────────────────────────────────────────────────────

router.get("/transactions", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const { type, category, search, from, to } = req.query as Record<string, string>;
    const conditions = [
      eq(transactionsTable.tenantId, tenantId),
      type ? eq(transactionsTable.type, type as "income" | "expense" | "sale" | "transfer" | "refund") : undefined,
      category ? eq(transactionsTable.category, category) : undefined,
      search ? ilike(transactionsTable.description, `%${search}%`) : undefined,
      from ? gte(transactionsTable.date, from) : undefined,
      to ? lte(transactionsTable.date, to) : undefined,
    ].filter(Boolean) as Parameters<typeof and>;

    const rows = await db
      .select()
      .from(transactionsTable)
      .where(and(...conditions))
      .orderBy(sql`date desc, created_at desc`);

    // Batch-fetch items for all sale/refund transactions in a single query (avoids N+1)
    const itemTxIds = rows
      .filter((t) => t.type === "sale" || t.type === "refund")
      .map((t) => t.id);
    const allItems =
      itemTxIds.length > 0
        ? await db
            .select()
            .from(transactionItemsTable)
            .where(inArray(transactionItemsTable.transactionId, itemTxIds))
        : [];
    const itemsByTxId = new Map<string, (typeof allItems)[number][]>();
    for (const item of allItems) {
      const list = itemsByTxId.get(item.transactionId) ?? [];
      list.push(item);
      itemsByTxId.set(item.transactionId, list);
    }

    const enriched = rows.map((t) => ({
      ...fmt(t),
      items: (itemsByTxId.get(t.id) ?? []).map(fmtItem),
    }));

    res.json(enriched);
  } catch (err) {
    logger.error({ err }, "GET /transactions error");
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── GET /transactions/summary ───────────────────────────────────────────────

router.get("/transactions/summary", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const { month } = req.query as Record<string, string>;
    const [stats] = await db
      .select({
        totalIncome: sql<number>`coalesce(sum(amount) filter (where type = 'income' or type = 'sale'), 0)`,
        totalExpenses: sql<number>`coalesce(sum(amount) filter (where type = 'expense'), 0)`,
        totalRefunds: sql<number>`coalesce(sum(amount) filter (where type = 'refund'), 0)`,
        count: sql<number>`count(*)`,
      })
      .from(transactionsTable)
      .where(
        and(
          eq(transactionsTable.tenantId, tenantId),
          month ? sql`date_trunc('month', date::date) = date_trunc('month', ${month}::date)` : undefined
        ) as ReturnType<typeof and>
      );
    const income = Number(stats?.totalIncome ?? 0);
    const expenses = Number(stats?.totalExpenses ?? 0);
    const refunds = Number(stats?.totalRefunds ?? 0);
    res.json({
      totalIncome: income,
      totalExpenses: expenses,
      totalRefunds: refunds,
      netRevenue: income - refunds,
      profit: income - expenses - refunds,
      count: Number(stats?.count ?? 0),
    });
  } catch (err) {
    logger.error({ err }, "GET /transactions/summary error");
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── POST /transactions/parse ──────────────────────────────────────────────────

const PARSE_TEXT_MAX = 500;

router.post("/transactions/parse", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const { text } = req.body as { text: string };
    if (!text || typeof text !== "string") {
      res.status(400).json({ error: "text is required" });
      return;
    }
    if (text.length > PARSE_TEXT_MAX) {
      res.status(400).json({ error: `text must be ${PARSE_TEXT_MAX} characters or fewer` });
      return;
    }
    const raw = await callOpenAI(text);
    let parsed: { type: string; amount: number; description: string; category: string; date: string };
    try {
      parsed = JSON.parse(raw);
    } catch {
      res.status(422).json({ error: "Could not parse transaction from text" });
      return;
    }
    res.json({
      type: parsed.type,
      amount: parsed.amount,
      description: parsed.description,
      category: parsed.category,
      date: parsed.date || new Date().toISOString().slice(0, 10),
      parsedFrom: text,
    });
  } catch (err) {
    logger.error({ err }, "POST /transactions/parse error");
    res.status(500).json({ error: "Failed to parse transaction" });
  }
});

// ─── POST /transactions ──────────────────────────────────────────────────────

router.post("/transactions", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const userId = req.userId as string;
    const body = req.body as {
      type: "income" | "expense" | "sale" | "transfer" | "refund";
      amount: number;
      description: string;
      category?: string;
      date: string;
      notes?: string;
      parsedFrom?: string;
      paymentMethod?: string;
      customerId?: string;
      items?: Array<{ inventoryId?: string; productName: string; quantity: number; unitPrice: number }>;
    };

    const numericAmount = Number(body.amount);
    if (!body.type || Number.isNaN(numericAmount) || !body.description || !body.date) {
      res.status(400).json({ error: "type, amount, description, date are required" });
      return;
    }

    const txId = generateId();

    // ─── SALE: pre-validate items before opening DB transaction ───────────────
    if (body.type === "sale" && (!body.items || body.items.length === 0)) {
      res.status(400).json({ error: "Sale transactions require items" });
      return;
    }

    // ─── All DB mutations wrapped in a transaction ────────────────────────────
    // Ensures inventory, invoice, and transaction record succeed or all roll back.
    let row!: typeof transactionsTable.$inferSelect;
    let invoiceId: string | null = null;
    const lowStockAlerts: { name: string; qty: number; id: string }[] = [];

    await db.transaction(async (tx) => {
      // ─── SALE ──────────────────────────────────────────────────────────────
      if (body.type === "sale") {
        // Find or create customer
        let customerId = body.customerId;
        if (!customerId) {
          const [newCust] = await tx.insert(customersTable).values({
            id: generateId(),
            tenantId,
            name: body.description,
            email: "",
            currency: "NGN",
          }).returning();
          customerId = newCust.id;
        }

        const [cust] = await tx.select().from(customersTable).where(eq(customersTable.id, customerId!)).limit(1);
        invoiceId = generateId();
        const invoiceNumber = `TX-${Date.now().toString().slice(-6)}`;
        await tx.insert(invoicesTable).values({
          id: invoiceId,
          tenantId,
          invoiceNumber,
          customerId: customerId!,
          customerName: cust?.name || body.description,
          customerEmail: cust?.email || null,
          total: String(numericAmount),
          amountPaid: String(numericAmount),
          currency: "NGN",
          status: "paid",
          dueDate: body.date,
          notes: body.notes || `Sale transaction ${body.description}`,
          items: body.items!.map((item) => ({
            description: item.productName,
            quantity: item.quantity,
            unitPrice: item.unitPrice,
            total: item.unitPrice * item.quantity,
          })),
        });

        // Deduct inventory
        for (const item of body.items!) {
          if (item.inventoryId) {
            const [prod] = await tx.select().from(inventoryTable).where(eq(inventoryTable.id, item.inventoryId)).limit(1);
            if (prod) {
              const newQty = Math.max(0, prod.quantity - item.quantity);
              await tx.update(inventoryTable).set({ quantity: newQty, updatedAt: new Date() }).where(eq(inventoryTable.id, prod.id));
              await tx.insert(stockAdjustmentsTable).values({
                id: generateId(),
                inventoryId: prod.id,
                tenantId,
                adjustment: -item.quantity,
                reason: "sale",
                notes: `Sold via transaction ${body.description}`,
              });
              if (newQty <= prod.lowStockThreshold) {
                lowStockAlerts.push({ name: prod.name, qty: newQty, id: prod.id });
              }
            }
          }
        }
      }

      // ─── REFUND ────────────────────────────────────────────────────────────
      if (body.type === "refund" && body.items) {
        for (const item of body.items) {
          if (item.inventoryId) {
            const [prod] = await tx.select().from(inventoryTable).where(eq(inventoryTable.id, item.inventoryId)).limit(1);
            if (prod) {
              const newQty = prod.quantity + item.quantity;
              await tx.update(inventoryTable).set({ quantity: newQty, updatedAt: new Date() }).where(eq(inventoryTable.id, prod.id));
              await tx.insert(stockAdjustmentsTable).values({
                id: generateId(),
                inventoryId: prod.id,
                tenantId,
                adjustment: item.quantity,
                reason: "refund",
                notes: `Returned from refund: ${body.description}`,
              });
            }
          }
        }
      }

      // ─── Create transaction record ─────────────────────────────────────────
      const [inserted] = await tx
        .insert(transactionsTable)
        .values({
          id: txId,
          tenantId,
          type: body.type,
          amount: String(numericAmount),
          description: body.description,
          category: body.category || (body.type === "sale" ? "sales" : "other"),
          date: body.date,
          notes: body.notes || null,
          parsedFrom: body.parsedFrom || null,
          paymentMethod: body.paymentMethod || null,
          customerId: body.customerId || null,
          invoiceId: invoiceId || null,
        })
        .returning();
      row = inserted;

      // ─── Create transaction items ──────────────────────────────────────────
      if (body.items && body.items.length > 0) {
        await tx.insert(transactionItemsTable).values(
          body.items.map((item) => ({
            id: generateId(),
            transactionId: txId,
            inventoryId: item.inventoryId || null,
            productName: item.productName,
            quantity: item.quantity,
            unitPrice: String(item.unitPrice),
            subtotal: String(item.unitPrice * item.quantity),
          }))
        );
      }
    });

    // ─── Side-effects outside the transaction (fire-and-forget) ──────────────
    for (const alert of lowStockAlerts) {
      createNotification({
        tenantId, userId, type: "low_stock",
        title: "Low Stock Alert",
        message: `${alert.name} is now low on stock (${alert.qty} remaining).`,
        link: `/inventory/${alert.id}`,
      }).catch(() => {});
    }
    if (body.type === "sale") {
      createNotification({
        tenantId, userId, type: "payment_received",
        title: "Sale Recorded",
        message: `Sale of ${formatCurrency(numericAmount, "NGN")} for ${body.description}.`,
        link: `/transactions`,
      }).catch(() => {});
    }

    // Audit log
    await writeAuditLog({
      tenantId,
      userId,
      action: "create",
      resource: "transaction",
      resourceId: row.id,
      changes: { type: body.type, amount: numericAmount, description: body.description, category: body.category },
    });

    res.status(201).json({
      ...fmt(row),
      items: body.items?.map((item) => ({
        inventoryId: item.inventoryId || null,
        productName: item.productName,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        subtotal: item.unitPrice * item.quantity,
      })) ?? [],
    });
  } catch (err) {
    logger.error({ err }, "POST /transactions error");
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── PUT /transactions/:id ─────────────────────────────────────────────────────

router.put("/transactions/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const id = req.params.id as string;
    const { type, amount, description, category, date, notes, paymentMethod } = req.body as Partial<{
      type: "income" | "expense" | "sale" | "transfer" | "refund";
      amount: number;
      description: string;
      category: string;
      date: string;
      notes: string;
      paymentMethod: string;
    }>;
    const [row] = await db
      .update(transactionsTable)
      .set({
        ...(type && { type }),
        ...(amount !== undefined && { amount: String(amount) }),
        ...(description && { description }),
        ...(category && { category }),
        ...(date && { date }),
        ...(notes !== undefined && { notes }),
        ...(paymentMethod !== undefined && { paymentMethod }),
        updatedAt: new Date(),
      })
      .where(and(eq(transactionsTable.id, id), eq(transactionsTable.tenantId, tenantId)))
      .returning();
    if (!row) { res.status(404).json({ error: "Not found" }); return; }
    await writeAuditLog({
      tenantId,
      userId: req.userId as string,
      action: "update",
      resource: "transaction",
      resourceId: row.id,
      changes: { type: row.type, amount: Number(row.amount), description: row.description },
    });
    res.json(fmt(row));
  } catch (err) {
    logger.error({ err }, "PUT /transactions/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── DELETE /transactions/:id ────────────────────────────────────────────────

router.delete("/transactions/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const id = req.params.id as string;
    await db.delete(transactionItemsTable).where(eq(transactionItemsTable.transactionId, id));
    await db.delete(transactionsTable).where(and(eq(transactionsTable.id, id), eq(transactionsTable.tenantId, tenantId)));
    await writeAuditLog({
      tenantId,
      userId: req.userId as string,
      action: "delete",
      resource: "transaction",
      resourceId: id,
    });
    res.status(204).send();
  } catch (err) {
    logger.error({ err }, "DELETE /transactions/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

function formatCurrency(amount: number, currency: string) {
  try {
    return new Intl.NumberFormat("en-NG", { style: "currency", currency, minimumFractionDigits: 0 }).format(amount);
  } catch {
    return `${currency} ${amount.toLocaleString()}`;
  }
}

export default router;
