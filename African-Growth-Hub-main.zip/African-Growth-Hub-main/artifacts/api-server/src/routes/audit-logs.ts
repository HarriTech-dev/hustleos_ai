import { Router } from "express";
import { db, auditLogsTable } from "@workspace/db";
import { eq, desc, and, gte, lte } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth";
import { requireFeature } from "../lib/feature-gate";
import { generateId } from "../lib/id";
import { logger } from "../lib/logger";

const router = Router();

const gate = requireFeature("audit_logs");

router.get("/audit-logs", requireAuth, gate, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const { resource, from, to, limit = "50" } = req.query as Record<string, string>;

    const conditions = [eq(auditLogsTable.tenantId, tenantId)];
    if (resource) conditions.push(eq(auditLogsTable.resource, resource));
    if (from) conditions.push(gte(auditLogsTable.createdAt, new Date(from)));
    if (to) conditions.push(lte(auditLogsTable.createdAt, new Date(to)));

    const items = await db
      .select()
      .from(auditLogsTable)
      .where(and(...conditions))
      .orderBy(desc(auditLogsTable.createdAt))
      .limit(Math.min(Number(limit), 200));

    res.json(items.map((l) => ({
      ...l,
      changes: l.changes ?? null,
      createdAt: l.createdAt.toISOString(),
    })));
  } catch (err) {
    logger.error({ err }, "GET /audit-logs error");
    res.status(500).json({ error: "Internal server error" });
  }
});

export { router as auditLogsRouter };

export async function writeAuditLog(params: {
  tenantId: string;
  userId: string;
  action: string;
  resource: string;
  resourceId?: string;
  changes?: Record<string, unknown>;
  ipAddress?: string;
  userAgent?: string;
}) {
  try {
    await db.insert(auditLogsTable).values({
      id: generateId(),
      ...params,
    });
  } catch (err) {
    logger.error({ err }, "writeAuditLog error");
  }
}

export default router;
