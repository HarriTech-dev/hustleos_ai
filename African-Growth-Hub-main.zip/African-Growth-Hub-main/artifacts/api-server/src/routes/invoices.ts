import { Router } from "express";
import { db, invoicesTable, customersTable, usersTable, transactionsTable, paymentsTable, receiptsTable } from "@workspace/db";
import { eq, and, ilike, sql } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth";
import { generateId } from "../lib/id";
import { logger } from "../lib/logger";
import { writeAuditLog } from "./audit-logs";
import { createNotification } from "./notifications";
import { sendEmail, buildInvoiceEmail, buildReceiptEmail, isResendConfigured } from "../lib/resend";
import { dispatchInvoiceSale, dispatchPaymentReceived } from "../lib/transaction-engine";

const router = Router();

function formatInvoice(inv: typeof invoicesTable.$inferSelect) {
  return {
    id: inv.id,
    invoiceNumber: inv.invoiceNumber,
    customerId: inv.customerId,
    customerName: inv.customerName,
    customerEmail: inv.customerEmail ?? null,
    status: inv.status,
    items: (inv.items as unknown[]) ?? [],
    subtotal: Number(inv.subtotal),
    discount: Number(inv.discount),
    tax: Number(inv.tax),
    total: Number(inv.total),
    amountPaid: Number(inv.amountPaid),
    amountDue: Number(inv.amountDue),
    currency: inv.currency,
    notes: inv.notes ?? null,
    dueDate: inv.dueDate,
    paidAt: inv.paidAt?.toISOString() ?? null,
    viewedAt: inv.viewedAt?.toISOString() ?? null,
    createdAt: inv.createdAt.toISOString(),
  };
}

async function nextInvoiceNumber(tenantId: string): Promise<string> {
  const [row] = await db
    .select({ count: sql<number>`count(*)` })
    .from(invoicesTable)
    .where(eq(invoicesTable.tenantId, tenantId));
  const n = Number(row?.count ?? 0) + 1;
  return `INV-${String(n).padStart(4, "0")}`;
}

async function nextReceiptNumber(tenantId: string): Promise<string> {
  const [row] = await db
    .select({ count: sql<number>`count(*)` })
    .from(receiptsTable)
    .where(eq(receiptsTable.tenantId, tenantId));
  const n = Number(row?.count ?? 0) + 1;
  return `RCP-${String(n).padStart(4, "0")}`;
}

router.get("/invoices", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const { status, search } = req.query as Record<string, string>;

    const conditions = [
      eq(invoicesTable.tenantId, tenantId),
      status ? eq(invoicesTable.status, status as typeof invoicesTable.$inferSelect.status) : undefined,
      search ? ilike(invoicesTable.customerName, `%${search}%`) : undefined,
    ].filter(Boolean) as Parameters<typeof and>;

    const items = await db
      .select()
      .from(invoicesTable)
      .where(and(...conditions))
      .orderBy(sql`created_at desc`);

    res.json(items.map(formatInvoice));
  } catch (err) {
    logger.error({ err }, "GET /invoices error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/invoices", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const body = req.body as {
      customerId: string;
      items: Array<{ description: string; quantity: number; unitPrice: number; total: number }>;
      tax?: number;
      discount?: number;
      notes?: string;
      dueDate: string;
      currency: string;
    };

    const [customer] = await db
      .select()
      .from(customersTable)
      .where(eq(customersTable.id, body.customerId))
      .limit(1);

    const subtotal = body.items.reduce((sum, i) => sum + i.total, 0);
    const discount = body.discount ?? 0;
    const tax = body.tax ?? 0;
    const total = Math.max(0, subtotal - discount + tax);
    const invoiceNumber = await nextInvoiceNumber(tenantId);

    const [inv] = await db
      .insert(invoicesTable)
      .values({
        id: generateId(),
        tenantId,
        invoiceNumber,
        customerId: body.customerId,
        customerName: customer?.name ?? "Unknown Customer",
        customerEmail: customer?.email ?? null,
        status: "draft",
        items: body.items,
        subtotal: String(subtotal),
        discount: String(discount),
        tax: String(tax),
        total: String(total),
        amountDue: String(total),
        currency: body.currency,
        notes: body.notes,
        dueDate: body.dueDate,
      })
      .returning();

    // Audit log
    await writeAuditLog({
      tenantId,
      userId: req.userId as string,
      action: "create",
      resource: "invoice",
      resourceId: inv.id,
      changes: { invoiceNumber: inv.invoiceNumber, customer: customer?.name, total, status: "draft" },
    });

    // Dispatch sale event — creates transaction, deducts inventory, creates CRM entry (fire-and-forget)
    dispatchInvoiceSale({
      tenantId,
      userId: req.userId as string,
      customerId: body.customerId,
      customerName: customer?.name ?? inv.customerName,
      customerPhone: customer?.phone ?? null,
      invoiceId: inv.id,
      invoiceNumber: inv.invoiceNumber,
      amount: total,
      currency: body.currency,
      items: body.items,
      date: new Date().toISOString().slice(0, 10),
    }).catch((err) => logger.error({ err }, "dispatchInvoiceSale failed"));

    res.status(201).json(formatInvoice(inv));
  } catch (err) {
    logger.error({ err }, "POST /invoices error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/invoices/stats/summary", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const userId = req.userId as string;

    const [stats] = await db
      .select({
        totalPaid: sql<number>`coalesce(sum(amount_paid) filter (where status = 'paid'), 0)`,
        totalOverdue: sql<number>`coalesce(sum(total) filter (where status = 'overdue'), 0)`,
        totalOutstanding: sql<number>`coalesce(sum(total) filter (where status in ('sent', 'draft', 'viewed', 'partial')), 0)`,
        countDraft: sql<number>`count(*) filter (where status = 'draft')`,
        countSent: sql<number>`count(*) filter (where status in ('sent', 'viewed'))`,
        countPaid: sql<number>`count(*) filter (where status = 'paid')`,
        countOverdue: sql<number>`count(*) filter (where status = 'overdue')`,
        countPartial: sql<number>`count(*) filter (where status = 'partial')`,
      })
      .from(invoicesTable)
      .where(eq(invoicesTable.tenantId, tenantId));

    const [userRecord] = await db
      .select({ currency: usersTable.currency, businessName: usersTable.businessName, businessLogo: usersTable.businessLogo })
      .from(usersTable)
      .where(eq(usersTable.id, userId))
      .limit(1);

    res.json({
      totalOutstanding: Number(stats?.totalOutstanding ?? 0),
      totalPaid: Number(stats?.totalPaid ?? 0),
      totalOverdue: Number(stats?.totalOverdue ?? 0),
      countDraft: Number(stats?.countDraft ?? 0),
      countSent: Number(stats?.countSent ?? 0),
      countPaid: Number(stats?.countPaid ?? 0),
      countOverdue: Number(stats?.countOverdue ?? 0),
      countPartial: Number(stats?.countPartial ?? 0),
      currency: userRecord?.currency ?? "NGN",
    });
  } catch (err) {
    logger.error({ err }, "GET /invoices/stats/summary error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/invoices/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const [inv] = await db
      .select()
      .from(invoicesTable)
      .where(and(eq(invoicesTable.id, req.params.id as string), eq(invoicesTable.tenantId, tenantId)))
      .limit(1);

    if (!inv) {
      res.status(404).json({ error: "Invoice not found" });
      return;
    }
    // Fetch payments
    const payments = await db
      .select()
      .from(paymentsTable)
      .where(and(eq(paymentsTable.invoiceId, inv.id), eq(paymentsTable.tenantId, tenantId)))
      .orderBy(sql`created_at desc`);

    res.json({
      ...formatInvoice(inv),
      payments: payments.map(p => ({ id: p.id, amount: Number(p.amount), method: p.method, notes: p.notes, createdAt: p.createdAt.toISOString() })),
    });
  } catch (err) {
    logger.error({ err }, "GET /invoices/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/invoices/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const body = req.body as Partial<{
      status: string;
      items: Array<{ description: string; quantity: number; unitPrice: number; total: number }>;
      tax: number;
      discount: number;
      notes: string;
      dueDate: string;
    }>;

    const updates: Partial<typeof invoicesTable.$inferInsert> = { updatedAt: new Date() };
    if (body.status !== undefined) updates.status = body.status as typeof invoicesTable.$inferSelect.status;
    if (body.items !== undefined) {
      updates.items = body.items;
      const subtotal = body.items.reduce((s, i) => s + i.total, 0);
      const discount = body.discount ?? 0;
      const tax = body.tax ?? 0;
      const total = Math.max(0, subtotal - discount + tax);
      updates.subtotal = String(subtotal);
      updates.discount = String(discount);
      updates.tax = String(tax);
      updates.total = String(total);
      updates.amountDue = String(total - Number(updates.amountPaid ?? 0));
    }
    if (body.notes !== undefined) updates.notes = body.notes;
    if (body.dueDate !== undefined) updates.dueDate = body.dueDate;

    const [inv] = await db
      .update(invoicesTable)
      .set(updates)
      .where(and(eq(invoicesTable.id, req.params.id as string), eq(invoicesTable.tenantId, tenantId)))
      .returning();

    if (!inv) {
      res.status(404).json({ error: "Invoice not found" });
      return;
    }
    await writeAuditLog({
      tenantId,
      userId: req.userId as string,
      action: "update",
      resource: "invoice",
      resourceId: inv.id,
      changes: { status: updates.status, total: updates.total },
    });

    res.json(formatInvoice(inv));
  } catch (err) {
    logger.error({ err }, "PATCH /invoices/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/invoices/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const invId = req.params.id as string;
    await db
      .delete(invoicesTable)
      .where(and(eq(invoicesTable.id, invId), eq(invoicesTable.tenantId, tenantId)));
    await writeAuditLog({
      tenantId,
      userId: req.userId as string,
      action: "delete",
      resource: "invoice",
      resourceId: invId,
      changes: { deleted: true },
    });
    res.status(204).send();
  } catch (err) {
    logger.error({ err }, "DELETE /invoices/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/invoices/:id/send", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const [inv] = await db
      .update(invoicesTable)
      .set({ status: "sent", updatedAt: new Date() })
      .where(and(eq(invoicesTable.id, req.params.id as string), eq(invoicesTable.tenantId, tenantId)))
      .returning();

    if (!inv) {
      res.status(404).json({ error: "Invoice not found" });
      return;
    }

    if (isResendConfigured() && inv.customerEmail) {
      const [user] = await db.select().from(usersTable).where(eq(usersTable.id, tenantId)).limit(1);
      const items = (inv.items as Array<{ description: string; quantity: number; unitPrice: number; total: number }>) ?? [];
      const { html, text } = buildInvoiceEmail({
        invoiceNumber: inv.invoiceNumber,
        customerName: inv.customerName,
        items,
        subtotal: Number(inv.subtotal),
        discount: Number(inv.discount),
        tax: Number(inv.tax),
        total: Number(inv.total),
        currency: inv.currency,
        dueDate: inv.dueDate,
        businessName: user?.businessName || "HustleOS AI",
        notes: inv.notes,
        businessLogo: user?.businessLogo || undefined,
      });
      const emailResult = await sendEmail({ to: inv.customerEmail, subject: `Invoice ${inv.invoiceNumber} from ${user?.businessName || "HustleOS AI"}`, html, text });
      if (emailResult.error) {
        logger.warn({ error: emailResult.error }, "Invoice email send failed");
      }
    }

    res.json(formatInvoice(inv));
  } catch (err) {
    logger.error({ err }, "POST /invoices/:id/send error");
    res.status(500).json({ error: "Internal server error" });
  }
});

// Record a partial payment
router.post("/invoices/:id/payments", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const invId = req.params.id as string;
    const body = req.body as { amount: number; method: string; notes?: string };

    const [inv] = await db
      .select()
      .from(invoicesTable)
      .where(and(eq(invoicesTable.id, invId), eq(invoicesTable.tenantId, tenantId)))
      .limit(1);

    if (!inv) {
      res.status(404).json({ error: "Invoice not found" });
      return;
    }

    const total = Number(inv.total);
    const amountPaid = Number(inv.amountPaid) + body.amount;
    const amountDue = Math.max(0, total - amountPaid);
    const newStatus = amountDue <= 0 ? "paid" : "partial";

    // Update invoice
    const [updated] = await db
      .update(invoicesTable)
      .set({
        amountPaid: String(amountPaid),
        amountDue: String(amountDue),
        status: newStatus,
        paidAt: newStatus === "paid" ? new Date() : inv.paidAt,
        updatedAt: new Date(),
      })
      .where(and(eq(invoicesTable.id, invId), eq(invoicesTable.tenantId, tenantId)))
      .returning();

    // Record payment
    const [payment] = await db
      .insert(paymentsTable)
      .values({
        id: generateId(),
        tenantId,
        invoiceId: invId,
        amount: String(body.amount),
        method: body.method as typeof paymentsTable.$inferSelect.method,
        notes: body.notes,
      })
      .returning();

    // Create transaction record
    await db.insert(transactionsTable).values({
      id: generateId(),
      tenantId,
      type: "income",
      amount: String(body.amount),
      description: `Payment for invoice ${inv.invoiceNumber}`,
      category: "invoice_payment",
      date: new Date().toISOString().slice(0, 10),
      notes: body.notes || undefined,
    });

    // Audit log
    await writeAuditLog({
      tenantId,
      userId: req.userId as string,
      action: "payment",
      resource: "invoice",
      resourceId: inv.id,
      changes: { amount: body.amount, method: body.method, amountPaid, amountDue, status: newStatus },
    });

    // If fully paid, send receipt + dispatch payment event
    if (newStatus === "paid") {
      await createNotification({
        tenantId,
        userId: req.userId as string,
        type: "invoice_paid",
        title: "Invoice fully paid",
        message: `Invoice ${inv.invoiceNumber} from ${inv.customerName} is now fully paid.`,
        link: `/invoices/${inv.id}`,
      });

      // Generate receipt
      await generateReceipt(tenantId, inv, body.amount, body.method as string);

      // Dispatch payment event — updates CRM order status
      dispatchPaymentReceived({
        tenantId,
        userId: req.userId as string,
        customerId: inv.customerId ?? "",
        customerName: inv.customerName,
        invoiceId: inv.id,
        invoiceNumber: inv.invoiceNumber,
        amount: body.amount,
        currency: inv.currency,
        isFullyPaid: true,
      }).catch((err) => logger.error({ err }, "dispatchPaymentReceived failed"));
    }

    res.json({
      ...formatInvoice(updated),
      payment: { id: payment.id, amount: Number(payment.amount), method: payment.method, notes: payment.notes, createdAt: payment.createdAt.toISOString() },
    });
  } catch (err) {
    logger.error({ err }, "POST /invoices/:id/payments error");
    res.status(500).json({ error: "Internal server error" });
  }
});

// Mark as paid (legacy: full payment)
router.post("/invoices/:id/mark-paid", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const [inv] = await db
      .update(invoicesTable)
      .set({ status: "paid", paidAt: new Date(), amountPaid: sql`total`, amountDue: "0", updatedAt: new Date() })
      .where(and(eq(invoicesTable.id, req.params.id as string), eq(invoicesTable.tenantId, tenantId)))
      .returning();

    if (!inv) {
      res.status(404).json({ error: "Invoice not found" });
      return;
    }

    // Create transaction record
    await db.insert(transactionsTable).values({
      id: generateId(),
      tenantId,
      type: "income",
      amount: inv.total,
      description: `Payment for invoice ${inv.invoiceNumber}`,
      category: "invoice_payment",
      date: new Date().toISOString().slice(0, 10),
      notes: "Full payment",
    });

    // Record payment
    await db.insert(paymentsTable).values({
      id: generateId(),
      tenantId,
      invoiceId: inv.id,
      amount: inv.total,
      method: "other",
      notes: "Marked as paid manually",
    });

    // Generate receipt
    await generateReceipt(tenantId, inv, Number(inv.total), "other");

    // Audit log
    await writeAuditLog({
      tenantId,
      userId: req.userId as string,
      action: "mark_paid",
      resource: "invoice",
      resourceId: inv.id,
      changes: { invoiceNumber: inv.invoiceNumber, amount: Number(inv.total), customer: inv.customerName },
    });

    await createNotification({
      tenantId,
      userId: req.userId as string,
      type: "invoice_paid",
      title: "Invoice paid",
      message: `Invoice ${inv.invoiceNumber} for ${inv.currency} ${Number(inv.total).toLocaleString()} from ${inv.customerName} has been paid.`,
      link: `/invoices/${inv.id}`,
    });

    // Dispatch payment received event — updates CRM order status
    dispatchPaymentReceived({
      tenantId,
      userId: req.userId as string,
      customerId: inv.customerId ?? "",
      customerName: inv.customerName,
      invoiceId: inv.id,
      invoiceNumber: inv.invoiceNumber,
      amount: Number(inv.total),
      currency: inv.currency,
      isFullyPaid: true,
    }).catch((err) => logger.error({ err }, "dispatchPaymentReceived (mark-paid) failed"));

    res.json(formatInvoice(inv));
  } catch (err) {
    logger.error({ err }, "POST /invoices/:id/mark-paid error");
    res.status(500).json({ error: "Internal server error" });
  }
});

// Track invoice opened
router.post("/invoices/:id/viewed", async (req, res) => {
  try {
    const invId = req.params.id as string;
    await db
      .update(invoicesTable)
      .set({ status: "viewed", viewedAt: new Date(), updatedAt: new Date() })
      .where(eq(invoicesTable.id, invId));
    res.json({ viewed: true });
  } catch (err) {
    logger.error({ err }, "POST /invoices/:id/viewed error");
    res.status(500).json({ error: "Internal server error" });
  }
});

// WhatsApp share link
router.get("/invoices/:id/whatsapp", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const [inv] = await db
      .select()
      .from(invoicesTable)
      .where(and(eq(invoicesTable.id, req.params.id as string), eq(invoicesTable.tenantId, tenantId)))
      .limit(1);

    if (!inv) {
      res.status(404).json({ error: "Invoice not found" });
      return;
    }

    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, tenantId)).limit(1);
    const message = `Hello ${inv.customerName}, here is your invoice *${inv.invoiceNumber}* from ${user?.businessName || "HustleOS AI"}.\n\nTotal: ${inv.currency} ${Number(inv.total).toLocaleString()}\nDue: ${inv.dueDate}\n\nView: ${process.env.REPLIT_DEV_DOMAIN || ""}/invoices/${inv.id}`;
    const encoded = encodeURIComponent(message);
    res.json({
      link: `https://wa.me/?text=${encoded}`,
      message,
    });
  } catch (err) {
    logger.error({ err }, "GET /invoices/:id/whatsapp error");
    res.status(500).json({ error: "Internal server error" });
  }
});

// Invoice history from audit logs
router.get("/invoices/:id/history", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const { auditLogsTable } = await import("@workspace/db");
    const { eq, and, desc } = await import("drizzle-orm");
    const logs = await db
      .select()
      .from(auditLogsTable)
      .where(and(
        eq(auditLogsTable.tenantId, tenantId),
        eq(auditLogsTable.resource, "invoice"),
        eq(auditLogsTable.resourceId, req.params.id as string)
      ))
      .orderBy(desc(auditLogsTable.createdAt));

    res.json(logs.map(l => ({
      ...l,
      changes: l.changes ?? null,
      createdAt: l.createdAt.toISOString(),
    })));
  } catch (err) {
    logger.error({ err }, "GET /invoices/:id/history error");
    res.status(500).json({ error: "Internal server error" });
  }
});

// PDF export via HTML
router.get("/invoices/:id/pdf", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const [inv] = await db
      .select()
      .from(invoicesTable)
      .where(and(eq(invoicesTable.id, req.params.id as string), eq(invoicesTable.tenantId, tenantId)))
      .limit(1);

    if (!inv) {
      res.status(404).json({ error: "Invoice not found" });
      return;
    }

    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, tenantId)).limit(1);
    const items = (inv.items as Array<{ description: string; quantity: number; unitPrice: number; total: number }>) ?? [];

    const itemsHtml = items.map(i => `
      <tr>
        <td>${i.description}</td>
        <td style="text-align:center">${i.quantity}</td>
        <td style="text-align:right">${inv.currency} ${i.unitPrice.toLocaleString()}</td>
        <td style="text-align:right">${inv.currency} ${i.total.toLocaleString()}</td>
      </tr>
    `).join("");

    const html = `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Invoice ${inv.invoiceNumber}</title>
<style>
  body { font-family: 'Segoe UI', system-ui, sans-serif; margin: 0; padding: 40px; color: #111; }
  .header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 40px; }
  .brand { display: flex; align-items: center; gap: 12px; }
  .logo { width: 40px; height: 40px; background: #111; color: #fff; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight: bold; }
  .invoice-number { font-size: 28px; font-weight: 700; }
  .status { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; text-transform: uppercase; }
  .status-paid { background: #d1fae5; color: #065f46; }
  .status-draft { background: #f3f4f6; color: #374151; }
  .status-sent { background: #dbeafe; color: #1e40af; }
  .status-overdue { background: #fee2e2; color: #991b1b; }
  .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; margin-bottom: 40px; }
  .info-block h3 { font-size: 12px; text-transform: uppercase; letter-spacing: 0.05em; color: #6b7280; margin-bottom: 8px; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 32px; }
  th { text-align: left; padding: 12px; background: #f9fafb; font-size: 12px; text-transform: uppercase; letter-spacing: 0.05em; color: #6b7280; border-bottom: 2px solid #e5e7eb; }
  td { padding: 12px; border-bottom: 1px solid #e5e7eb; }
  .totals { width: 300px; margin-left: auto; }
  .totals-row { display: flex; justify-content: space-between; padding: 8px 0; }
  .total-row { font-size: 18px; font-weight: 700; border-top: 2px solid #e5e7eb; padding-top: 12px; margin-top: 8px; }
  .footer { margin-top: 60px; text-align: center; font-size: 12px; color: #9ca3af; }
</style>
</head>
<body>
  <div class="header">
    <div class="brand">
      ${user?.businessLogo ? `<img src="${user.businessLogo}" style="width:40px;height:40px;object-fit:cover;border-radius:8px">` : `<div class="logo">${(user?.businessName || "H").charAt(0)}</div>`}
      <div>
        <div style="font-size:18px;font-weight:700">${user?.businessName || "HustleOS AI"}</div>
        <div style="font-size:12px;color:#6b7280">${user?.phone || ""}</div>
      </div>
    </div>
    <div style="text-align:right">
      <div class="invoice-number">${inv.invoiceNumber}</div>
      <span class="status status-${inv.status}">${inv.status}</span>
    </div>
  </div>
  <div class="info-grid">
    <div class="info-block">
      <h3>Bill To</h3>
      <p style="font-weight:600">${inv.customerName}</p>
      <p style="color:#6b7280;font-size:14px">${inv.customerEmail || ""}</p>
    </div>
    <div class="info-block" style="text-align:right">
      <h3>Invoice Details</h3>
      <p style="font-size:14px">Issue Date: ${new Date(inv.createdAt).toLocaleDateString()}</p>
      <p style="font-size:14px">Due Date: ${inv.dueDate}</p>
      ${inv.paidAt ? `<p style="font-size:14px;color:#065f46">Paid On: ${new Date(inv.paidAt).toLocaleDateString()}</p>` : ""}
    </div>
  </div>
  <table>
    <thead>
      <tr>
        <th>Item</th>
        <th style="text-align:center">Qty</th>
        <th style="text-align:right">Unit</th>
        <th style="text-align:right">Total</th>
      </tr>
    </thead>
    <tbody>
      ${itemsHtml}
    </tbody>
  </table>
  <div class="totals">
    <div class="totals-row">
      <span style="color:#6b7280">Subtotal</span>
      <span>${inv.currency} ${Number(inv.subtotal).toLocaleString()}</span>
    </div>
    ${Number(inv.discount) > 0 ? `<div class="totals-row"><span style="color:#6b7280">Discount</span><span style="color:#dc2626">-${inv.currency} ${Number(inv.discount).toLocaleString()}</span></div>` : ""}
    <div class="totals-row">
      <span style="color:#6b7280">Tax</span>
      <span>${inv.currency} ${Number(inv.tax).toLocaleString()}</span>
    </div>
    <div class="totals-row total-row">
      <span>Total</span>
      <span>${inv.currency} ${Number(inv.total).toLocaleString()}</span>
    </div>
    ${Number(inv.amountPaid) > 0 ? `
    <div class="totals-row" style="color:#6b7280">
      <span>Amount Paid</span>
      <span>${inv.currency} ${Number(inv.amountPaid).toLocaleString()}</span>
    </div>
    <div class="totals-row" style="font-weight:600">
      <span>Amount Due</span>
      <span>${inv.currency} ${Number(inv.amountDue).toLocaleString()}</span>
    </div>
    ` : ""}
  </div>
  ${inv.notes ? `<div style="margin-top:40px;padding:16px;background:#f9fafb;border-radius:8px"><h3 style="margin:0 0 8px">Notes</h3><p style="margin:0;font-size:14px">${inv.notes}</p></div>` : ""}
  <div class="footer">
    Generated by HustleOS AI &mdash; Built for African Entrepreneurs
  </div>
</body>
</html>`;

    res.setHeader("Content-Type", "text/html");
    res.setHeader("Content-Disposition", `inline; filename="${inv.invoiceNumber}.html"`);
    res.send(html);
  } catch (err) {
    logger.error({ err }, "GET /invoices/:id/pdf error");
    res.status(500).json({ error: "Internal server error" });
  }
});

async function generateReceipt(
  tenantId: string,
  inv: typeof invoicesTable.$inferSelect,
  amount: number,
  method: string,
) {
  try {
    const receiptNumber = await nextReceiptNumber(tenantId);
    const [receipt] = await db
      .insert(receiptsTable)
      .values({
        id: generateId(),
        tenantId,
        receiptNumber,
        invoiceId: inv.id,
        invoiceNumber: inv.invoiceNumber,
        customerId: inv.customerId,
        customerName: inv.customerName,
        customerEmail: inv.customerEmail,
        amount: String(amount),
        currency: inv.currency,
        paymentMethod: method,
      })
      .returning();

    // Send receipt email
    if (isResendConfigured() && inv.customerEmail) {
      const [user] = await db.select().from(usersTable).where(eq(usersTable.id, tenantId)).limit(1);
      const { html, text } = buildReceiptEmail({
        receiptNumber: receipt.receiptNumber,
        invoiceNumber: inv.invoiceNumber,
        customerName: inv.customerName,
        amount,
        currency: inv.currency,
        paymentMethod: method,
        businessName: user?.businessName || "HustleOS AI",
        businessLogo: user?.businessLogo || undefined,
      });
      await sendEmail({
        to: inv.customerEmail,
        subject: `Receipt ${receipt.receiptNumber} from ${user?.businessName || "HustleOS AI"}`,
        html,
        text,
      });
    }
  } catch (err) {
    logger.error({ err }, "generateReceipt error");
  }
}

export default router;
