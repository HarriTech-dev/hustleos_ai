import { Router } from "express";
import { db, receiptsTable, invoicesTable } from "@workspace/db";
import { eq, and, sql } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth";
import { logger } from "../lib/logger";

const router = Router();

function formatReceipt(r: typeof receiptsTable.$inferSelect) {
  return {
    id: r.id,
    receiptNumber: r.receiptNumber,
    invoiceId: r.invoiceId,
    invoiceNumber: r.invoiceNumber,
    customerId: r.customerId,
    customerName: r.customerName,
    customerEmail: r.customerEmail ?? null,
    amount: Number(r.amount),
    currency: r.currency,
    paymentMethod: r.paymentMethod ?? null,
    notes: r.notes ?? null,
    createdAt: r.createdAt.toISOString(),
  };
}

router.get("/receipts", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const { search } = req.query as Record<string, string>;
    const conditions = [eq(receiptsTable.tenantId, tenantId)];
    const items = await db
      .select()
      .from(receiptsTable)
      .where(and(...conditions))
      .orderBy(sql`created_at desc`);
    res.json(items.map(formatReceipt));
  } catch (err) {
    logger.error({ err }, "GET /receipts error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/receipts/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const [r] = await db
      .select()
      .from(receiptsTable)
      .where(and(eq(receiptsTable.id, req.params.id as string), eq(receiptsTable.tenantId, tenantId)))
      .limit(1);
    if (!r) { res.status(404).json({ error: "Receipt not found" }); return; }
    res.json(formatReceipt(r));
  } catch (err) {
    logger.error({ err }, "GET /receipts/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
