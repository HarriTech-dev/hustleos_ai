import { Router } from "express";
import { db, customersTable, invoicesTable } from "@workspace/db";
import { eq, and, ilike, sql } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth";
import { generateId } from "../lib/id";
import { logger } from "../lib/logger";
import { writeAuditLog } from "./audit-logs";
import { createNotification } from "./notifications";

const router = Router();

function formatCustomer(c: typeof customersTable.$inferSelect, totalSpent = 0, invoiceCount = 0) {
  return {
    id: c.id,
    name: c.name,
    email: c.email,
    phone: c.phone ?? null,
    address: c.address ?? null,
    country: c.country ?? null,
    segment: c.segment ?? null,
    currency: c.currency,
    totalSpent,
    invoiceCount,
    notes: c.notes ?? null,
    createdAt: c.createdAt.toISOString(),
  };
}

router.get("/customers", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const { search, segment } = req.query as Record<string, string>;

    const conditions = [
      eq(customersTable.tenantId, tenantId),
      search ? ilike(customersTable.name, `%${search}%`) : undefined,
      segment ? eq(customersTable.segment, segment) : undefined,
    ].filter(Boolean) as Parameters<typeof and>;

    // Single query with aggregate subquery — no N+1
    const statsSubquery = db
      .select({
        customerId: invoicesTable.customerId,
        totalSpent: sql<number>`coalesce(sum(${invoicesTable.total}) filter (where ${invoicesTable.status} = 'paid'), 0)`.as("total_spent"),
        invoiceCount: sql<number>`count(*)`.as("invoice_count"),
      })
      .from(invoicesTable)
      .where(eq(invoicesTable.tenantId, tenantId))
      .groupBy(invoicesTable.customerId)
      .as("stats");

    const rows = await db
      .select({
        customer: customersTable,
        totalSpent: statsSubquery.totalSpent,
        invoiceCount: statsSubquery.invoiceCount,
      })
      .from(customersTable)
      .leftJoin(statsSubquery, eq(customersTable.id, statsSubquery.customerId))
      .where(and(...conditions))
      .orderBy(sql`${customersTable.createdAt} desc`);

    const enriched = rows.map((r) =>
      formatCustomer(r.customer, Number(r.totalSpent ?? 0), Number(r.invoiceCount ?? 0))
    );

    res.json(enriched);
  } catch (err) {
    logger.error({ err }, "GET /customers error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/customers", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const body = req.body as {
      name: string;
      email: string;
      phone?: string;
      address?: string;
      country?: string;
      segment?: string;
      currency?: string;
      notes?: string;
    };

    const [customer] = await db
      .insert(customersTable)
      .values({
        id: generateId(),
        tenantId,
        name: body.name,
        email: body.email,
        phone: body.phone,
        address: body.address,
        country: body.country,
        segment: body.segment,
        currency: body.currency ?? "NGN",
        notes: body.notes,
      })
      .returning();

    // Audit log
    await writeAuditLog({
      tenantId,
      userId: req.userId as string,
      action: "create",
      resource: "customer",
      resourceId: customer.id,
      changes: { name: customer.name, email: customer.email },
    });
    await createNotification({
      tenantId,
      userId: req.userId as string,
      type: "new_customer",
      title: "New customer added",
      message: `${customer.name} has been added to your customers.`,
      link: `/customers/${customer.id}`,
    });
    res.status(201).json(formatCustomer(customer));
  } catch (err) {
    logger.error({ err }, "POST /customers error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/customers/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const [customer] = await db
      .select()
      .from(customersTable)
      .where(and(eq(customersTable.id, req.params.id as string), eq(customersTable.tenantId, tenantId)))
      .limit(1);

    if (!customer) {
      res.status(404).json({ error: "Customer not found" });
      return;
    }

    const [stats] = await db
      .select({
        totalSpent: sql<number>`coalesce(sum(total) filter (where status = 'paid'), 0)`,
        totalOwed: sql<number>`coalesce(sum(total) filter (where status != 'paid'), 0)`,
        invoiceCount: sql<number>`count(*)`,
      })
      .from(invoicesTable)
      .where(eq(invoicesTable.customerId, customer.id));

    const balance = Number(stats?.totalOwed ?? 0);
    const totalSpent = Number(stats?.totalSpent ?? 0);
    const invoiceCount = Number(stats?.invoiceCount ?? 0);

    res.json({
      ...formatCustomer(customer, totalSpent, invoiceCount),
      balance,
      balanceStatus: balance > 0 ? "debt" : balance < 0 ? "credit" : "clear",
    });
  } catch (err) {
    logger.error({ err }, "GET /customers/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/customers/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const body = req.body as Partial<{
      name: string;
      email: string;
      phone: string;
      address: string;
      country: string;
      segment: string;
      notes: string;
    }>;

    const updates: Partial<typeof customersTable.$inferInsert> = { updatedAt: new Date() };
    if (body.name !== undefined) updates.name = body.name;
    if (body.email !== undefined) updates.email = body.email;
    if (body.phone !== undefined) updates.phone = body.phone;
    if (body.address !== undefined) updates.address = body.address;
    if (body.country !== undefined) updates.country = body.country;
    if (body.segment !== undefined) updates.segment = body.segment;
    if (body.notes !== undefined) updates.notes = body.notes;

    const [customer] = await db
      .update(customersTable)
      .set(updates)
      .where(and(eq(customersTable.id, req.params.id as string), eq(customersTable.tenantId, tenantId)))
      .returning();

    if (!customer) {
      res.status(404).json({ error: "Customer not found" });
      return;
    }
    // Audit log
    await writeAuditLog({
      tenantId,
      userId: req.userId as string,
      action: "update",
      resource: "customer",
      resourceId: customer.id,
      changes: { name: customer.name, email: customer.email, phone: customer.phone },
    });
    res.json(formatCustomer(customer));
  } catch (err) {
    logger.error({ err }, "PATCH /customers/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/customers/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    await db
      .delete(customersTable)
      .where(and(eq(customersTable.id, req.params.id as string), eq(customersTable.tenantId, tenantId)));
    // Audit log
    await writeAuditLog({
      tenantId,
      userId: req.userId as string,
      action: "delete",
      resource: "customer",
      resourceId: req.params.id as string,
      changes: { deleted: true },
    });
    res.status(204).send();
  } catch (err) {
    logger.error({ err }, "DELETE /customers/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/customers/:id/invoices", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const invoices = await db
      .select()
      .from(invoicesTable)
      .where(and(eq(invoicesTable.customerId, req.params.id as string), eq(invoicesTable.tenantId, tenantId)))
      .orderBy(sql`created_at desc`);

    res.json(
      invoices.map((inv) => ({
        id: inv.id,
        invoiceNumber: inv.invoiceNumber,
        customerId: inv.customerId,
        customerName: inv.customerName,
        customerEmail: inv.customerEmail ?? null,
        status: inv.status,
        items: (inv.items as unknown[]) ?? [],
        subtotal: Number(inv.subtotal),
        tax: Number(inv.tax),
        total: Number(inv.total),
        currency: inv.currency,
        notes: inv.notes ?? null,
        dueDate: inv.dueDate,
        paidAt: inv.paidAt?.toISOString() ?? null,
        createdAt: inv.createdAt.toISOString(),
      }))
    );
  } catch (err) {
    logger.error({ err }, "GET /customers/:id/invoices error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/debtors", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;

    const overdueInvoices = await db
      .select()
      .from(invoicesTable)
      .where(
        and(
          eq(invoicesTable.tenantId, tenantId),
          sql`status IN ('sent', 'overdue')`
        )
      )
      .orderBy(sql`due_date asc`);

    const byCustomer = new Map<string, {
      customerId: string;
      customerName: string;
      customerEmail: string | null;
      totalOwed: number;
      overdueCount: number;
      oldestDueDate: string;
      currency: string;
      invoices: Array<{ id: string; invoiceNumber: string; total: number; dueDate: string; status: string }>;
    }>();

    for (const inv of overdueInvoices) {
      const existing = byCustomer.get(inv.customerId);
      const invData = {
        id: inv.id,
        invoiceNumber: inv.invoiceNumber,
        total: Number(inv.total),
        dueDate: inv.dueDate,
        status: inv.status,
      };
      if (existing) {
        existing.totalOwed += Number(inv.total);
        existing.overdueCount += 1;
        if (inv.dueDate < existing.oldestDueDate) existing.oldestDueDate = inv.dueDate;
        existing.invoices.push(invData);
      } else {
        byCustomer.set(inv.customerId, {
          customerId: inv.customerId,
          customerName: inv.customerName,
          customerEmail: inv.customerEmail ?? null,
          totalOwed: Number(inv.total),
          overdueCount: 1,
          oldestDueDate: inv.dueDate,
          currency: inv.currency,
          invoices: [invData],
        });
      }
    }

    res.json(Array.from(byCustomer.values()));
  } catch (err) {
    logger.error({ err }, "GET /debtors error");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
