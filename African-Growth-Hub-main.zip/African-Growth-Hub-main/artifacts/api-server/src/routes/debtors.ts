import { Router } from "express";
import { db, customersTable, invoicesTable, manualDebtsTable } from "@workspace/db";
import { eq, and, ne, sql, desc } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth";
import { generateId } from "../lib/id";
import { logger } from "../lib/logger";
import { writeAuditLog } from "./audit-logs";

const router = Router();

// ─── Invoice-based debtors view ──────────────────────────────────────────────

router.get("/debtors", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;

    // Invoice-based debts — single JOIN query
    const rows = await db
      .select({
        invoiceId: invoicesTable.id,
        invoiceNumber: invoicesTable.invoiceNumber,
        total: invoicesTable.total,
        dueDate: invoicesTable.dueDate,
        status: invoicesTable.status,
        customerId: customersTable.id,
        customerName: customersTable.name,
        customerEmail: customersTable.email,
        customerPhone: customersTable.phone,
        currency: customersTable.currency,
      })
      .from(invoicesTable)
      .innerJoin(customersTable, eq(invoicesTable.customerId, customersTable.id))
      .where(
        and(
          eq(invoicesTable.tenantId, tenantId),
          ne(invoicesTable.status, "paid"),
          ne(invoicesTable.status, "cancelled"),
          ne(invoicesTable.status, "draft"),
        )
      )
      .orderBy(sql`${invoicesTable.dueDate} asc`);

    // Group by customer in memory
    const map = new Map<string, {
      customerId: string;
      customerName: string;
      customerEmail: string | null;
      customerPhone: string | null;
      currency: string;
      invoices: Array<{ id: string; invoiceNumber: string; total: number; dueDate: string; status: string }>;
      totalOwed: number;
      overdueCount: number;
      oldestDueDate: string;
    }>();

    const now = new Date();
    for (const row of rows) {
      if (!map.has(row.customerId)) {
        map.set(row.customerId, {
          customerId: row.customerId,
          customerName: row.customerName,
          customerEmail: row.customerEmail ?? null,
          customerPhone: row.customerPhone ?? null,
          currency: row.currency,
          invoices: [],
          totalOwed: 0,
          overdueCount: 0,
          oldestDueDate: row.dueDate,
        });
      }
      const entry = map.get(row.customerId)!;
      const total = Number(row.total);
      entry.invoices.push({ id: row.invoiceId, invoiceNumber: row.invoiceNumber, total, dueDate: row.dueDate, status: row.status });
      entry.totalOwed += total;
      if (row.status === "overdue" || (row.status !== "partial" && new Date(row.dueDate) < now)) {
        entry.overdueCount++;
      }
    }

    res.json(Array.from(map.values()));
  } catch (err) {
    logger.error({ err }, "GET /debtors error");
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── Manual Debts CRUD ────────────────────────────────────────────────────────

function formatDebt(d: typeof manualDebtsTable.$inferSelect) {
  return {
    id: d.id,
    debtorName: d.debtorName,
    debtorPhone: d.debtorPhone ?? null,
    debtorEmail: d.debtorEmail ?? null,
    customerId: d.customerId ?? null,
    amount: Number(d.amount),
    amountPaid: Number(d.amountPaid),
    amountDue: Math.max(0, Number(d.amount) - Number(d.amountPaid)),
    reason: d.reason,
    notes: d.notes ?? null,
    status: d.status,
    dueDate: d.dueDate ?? null,
    currency: d.currency,
    createdAt: d.createdAt.toISOString(),
    updatedAt: d.updatedAt.toISOString(),
  };
}

router.get("/debtors/manual", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const { status } = req.query as Record<string, string>;
    const conditions = [
      eq(manualDebtsTable.tenantId, tenantId),
      status ? eq(manualDebtsTable.status, status as typeof manualDebtsTable.$inferSelect.status) : undefined,
    ].filter(Boolean) as Parameters<typeof and>;
    const debts = await db
      .select()
      .from(manualDebtsTable)
      .where(and(...conditions))
      .orderBy(desc(manualDebtsTable.createdAt));
    res.json(debts.map(formatDebt));
  } catch (err) {
    logger.error({ err }, "GET /debtors/manual error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/debtors/manual", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const body = req.body as {
      debtorName: string;
      debtorPhone?: string;
      debtorEmail?: string;
      customerId?: string;
      amount: number;
      reason: string;
      notes?: string;
      dueDate?: string;
      currency?: string;
    };

    if (!body.debtorName || !body.amount || !body.reason) {
      res.status(400).json({ error: "debtorName, amount, and reason are required" });
      return;
    }

    const [debt] = await db.insert(manualDebtsTable).values({
      id: generateId(),
      tenantId,
      debtorName: body.debtorName,
      debtorPhone: body.debtorPhone,
      debtorEmail: body.debtorEmail,
      customerId: body.customerId,
      amount: String(body.amount),
      amountPaid: "0",
      reason: body.reason,
      notes: body.notes,
      status: "outstanding",
      dueDate: body.dueDate,
      currency: body.currency ?? "NGN",
    }).returning();

    await writeAuditLog({
      tenantId,
      userId: req.userId as string,
      action: "create",
      resource: "manual_debt",
      resourceId: debt.id,
      changes: { debtorName: body.debtorName, amount: body.amount, reason: body.reason },
    });

    res.status(201).json(formatDebt(debt));
  } catch (err) {
    logger.error({ err }, "POST /debtors/manual error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/debtors/manual/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const debtId = req.params.id as string;
    const body = req.body as Partial<{
      amountPaid: number;
      notes: string;
      status: string;
      dueDate: string;
    }>;

    const [existing] = await db
      .select()
      .from(manualDebtsTable)
      .where(and(eq(manualDebtsTable.id, debtId), eq(manualDebtsTable.tenantId, tenantId)))
      .limit(1);

    if (!existing) {
      res.status(404).json({ error: "Manual debt not found" });
      return;
    }

    const updates: Partial<typeof manualDebtsTable.$inferInsert> = { updatedAt: new Date() };

    if (body.amountPaid !== undefined) {
      const newAmountPaid = Math.min(Number(existing.amount), body.amountPaid);
      updates.amountPaid = String(newAmountPaid);
      const amountDue = Math.max(0, Number(existing.amount) - newAmountPaid);
      if (amountDue <= 0) {
        updates.status = "paid";
      } else if (newAmountPaid > 0) {
        updates.status = "partial";
      }
    }

    if (body.status !== undefined) {
      updates.status = body.status as typeof manualDebtsTable.$inferSelect.status;
    }
    if (body.notes !== undefined) updates.notes = body.notes;
    if (body.dueDate !== undefined) updates.dueDate = body.dueDate;

    const [updated] = await db
      .update(manualDebtsTable)
      .set(updates)
      .where(and(eq(manualDebtsTable.id, debtId), eq(manualDebtsTable.tenantId, tenantId)))
      .returning();

    await writeAuditLog({
      tenantId,
      userId: req.userId as string,
      action: "update",
      resource: "manual_debt",
      resourceId: debtId,
      changes: { status: updates.status, amountPaid: updates.amountPaid },
    });

    res.json(formatDebt(updated));
  } catch (err) {
    logger.error({ err }, "PATCH /debtors/manual/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/debtors/manual/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const tenantId = req.tenantId as string;
    const debtId = req.params.id as string;
    await db.delete(manualDebtsTable).where(and(eq(manualDebtsTable.id, debtId), eq(manualDebtsTable.tenantId, tenantId)));
    await writeAuditLog({
      tenantId,
      userId: req.userId as string,
      action: "delete",
      resource: "manual_debt",
      resourceId: debtId,
      changes: { deleted: true },
    });
    res.status(204).send();
  } catch (err) {
    logger.error({ err }, "DELETE /debtors/manual/:id error");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
