import crypto from "crypto";
import { Router, type Request } from "express";
import { db, subscriptionPlansTable, subscriptionsTable, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../lib/auth";
import { generateId } from "../lib/id";
import { logger } from "../lib/logger";

const router = Router();

/* ------------------------------------------------------------------ */
/*  Currency price map — localized pricing per plan per currency       */
/* ------------------------------------------------------------------ */

/** Prices in each currency's major unit (e.g. ₦3000, $5, CFA 2500) */
const CURRENCY_PRICES: Record<string, Record<string, number>> = {
  plan_pro: {
    NGN: 3000,
    XAF: 2500,  // Central Africa CFA (Cameroon, Gabon, Chad, Congo…)
    XOF: 2500,  // West Africa CFA (Senegal, Ivory Coast…)
    GHS: 35,
    KES: 400,
    USD: 5,
    EUR: 4,
    GBP: 4,
    ZAR: 90,
    UGX: 18000,
    TZS: 12000,
    RWF: 5000,
    ETB: 280,
    MAD: 50,
    EGP: 150,
    ZMW: 110,
    MZN: 320,
  },
  plan_premium: {
    NGN: 8000,
    XAF: 5000,
    XOF: 5000,
    GHS: 90,
    KES: 1100,
    USD: 12,
    EUR: 10,
    GBP: 10,
    ZAR: 240,
    UGX: 45000,
    TZS: 32000,
    RWF: 13000,
    ETB: 750,
    MAD: 130,
    EGP: 400,
    ZMW: 290,
    MZN: 850,
  },
};

/** Return the localized plan price for a given currency.
 *  Falls back to the plan's default NGN price if currency is unknown. */
function getLocalizedPrice(planId: string, planDefaultPrice: number, currency: string): number {
  return CURRENCY_PRICES[planId]?.[currency] ?? planDefaultPrice;
}

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

function activateSubscription(
  tenantId: string,
  planId: string,
  planName: string,
  provider: string,
  reference: string,
) {
  const now = new Date();
  const endDate = new Date(now);
  endDate.setMonth(endDate.getMonth() + 1);

  return db
    .insert(subscriptionsTable)
    .values({
      id: generateId(),
      tenantId,
      planId,
      planName,
      status: "active",
      provider,
      providerReference: reference,
      currentPeriodStart: now,
      currentPeriodEnd: endDate,
      cancelAtPeriodEnd: false,
    })
    .onConflictDoUpdate({
      target: subscriptionsTable.tenantId,
      set: {
        planId,
        planName,
        status: "active",
        provider,
        providerReference: reference,
        currentPeriodStart: now,
        currentPeriodEnd: endDate,
        cancelAtPeriodEnd: false,
      },
    });
}

/* Paystack: verify HMAC-SHA512 of raw body against x-paystack-signature header */
function verifyPaystackSignature(rawBody: Buffer, signature: string): boolean {
  const secret = process.env.PAYSTACK_SECRET_KEY ?? "";
  const hash = crypto.createHmac("sha512", secret).update(rawBody).digest("hex");
  return hash === signature;
}

/* Flutterwave: compare verif-hash header against FLUTTERWAVE_WEBHOOK_HASH env var */
function verifyFlutterwaveSignature(header: string | undefined): boolean {
  const expected = process.env.FLUTTERWAVE_WEBHOOK_HASH;
  if (!expected) {
    logger.warn("FLUTTERWAVE_WEBHOOK_HASH not set — skipping header check");
    return true;
  }
  return header === expected;
}

/* ------------------------------------------------------------------ */
/*  GET /subscriptions/plans  (public)                                */
/* ------------------------------------------------------------------ */
router.get("/subscriptions/plans", async (_req, res) => {
  try {
    const plans = await db
      .select()
      .from(subscriptionPlansTable)
      .where(eq(subscriptionPlansTable.isActive, true));

    res.json(
      plans.map((p) => ({
        id: p.id,
        name: p.name,
        price: Number(p.price),
        currency: p.currency,
        interval: p.interval,
        features: p.features,
        isPopular: p.isPopular,
      }))
    );
  } catch (err) {
    logger.error({ err }, "GET /subscriptions/plans error");
    res.status(500).json({ error: "Internal server error" });
  }
});

/* ------------------------------------------------------------------ */
/*  GET /subscriptions/current                                        */
/* ------------------------------------------------------------------ */
router.get("/subscriptions/current", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const subs = await db
      .select()
      .from(subscriptionsTable)
      .where(eq(subscriptionsTable.tenantId, req.tenantId as string))
      .limit(1);

    if (!subs[0]) {
      res.status(404).json({ error: "No active subscription" });
      return;
    }

    const s = subs[0];
    res.json({
      id: s.id,
      planId: s.planId,
      planName: s.planName,
      status: s.status,
      currentPeriodStart: s.currentPeriodStart.toISOString(),
      currentPeriodEnd: s.currentPeriodEnd.toISOString(),
      cancelAtPeriodEnd: s.cancelAtPeriodEnd,
    });
  } catch (err) {
    logger.error({ err }, "GET /subscriptions/current error");
    res.status(500).json({ error: "Internal server error" });
  }
});

/* ------------------------------------------------------------------ */
/*  POST /subscriptions/checkout                                      */
/*  Initializes a real payment session with Paystack or Flutterwave  */
/* ------------------------------------------------------------------ */
router.post("/subscriptions/checkout", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const { planId, provider, currency } = req.body as {
      planId: string;
      provider: "paystack" | "flutterwave";
      currency?: string;
    };

    if (!planId || !provider) {
      res.status(400).json({ error: "planId and provider are required" });
      return;
    }

    const [plan] = await db
      .select()
      .from(subscriptionPlansTable)
      .where(eq(subscriptionPlansTable.id, planId))
      .limit(1);

    if (!plan) {
      res.status(404).json({ error: "Plan not found" });
      return;
    }

    if (Number(plan.price) === 0) {
      res.status(400).json({ error: "Free plan does not require payment" });
      return;
    }

    const chargeCurrency = currency ?? plan.currency;
    const localPrice = getLocalizedPrice(planId, Number(plan.price), chargeCurrency);

    const reference = `hustle-${generateId()}`;
    const [userRecord] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, req.userId as string))
      .limit(1);

    const domain = (process.env.REPLIT_DOMAINS?.split(",")[0] ?? "localhost");
    const baseUrl = domain.startsWith("http") ? domain : `https://${domain}`;
    const tenantId = req.tenantId as string;

    let checkoutUrl = "";

    /* ── Paystack ─────────────────────────────────────────────────── */
    if (provider === "paystack") {
      const paystackKey = process.env.PAYSTACK_SECRET_KEY;
      if (!paystackKey) {
        res.status(500).json({ error: "Paystack secret key not configured. Set PAYSTACK_SECRET_KEY in your environment secrets." });
        return;
      }

      const callbackUrl = `${baseUrl}/api/subscriptions/verify-redirect?provider=paystack&planId=${planId}&tenantId=${tenantId}`;

      const response = await fetch("https://api.paystack.co/transaction/initialize", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${paystackKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: userRecord?.email ?? "user@example.com",
          amount: Math.round(localPrice * 100), // minor units (kobo, cents, etc.)
          currency: chargeCurrency,
          reference,
          callback_url: callbackUrl,
          metadata: {
            planId,
            tenantId,
            expectedAmount: Math.round(localPrice * 100),
            expectedCurrency: chargeCurrency,
          },
        }),
      });

      const data = (await response.json()) as {
        status?: boolean;
        message?: string;
        data?: { authorization_url: string };
      };

      if (!data.status || !data.data?.authorization_url) {
        logger.error({ data }, "Paystack initialize failed");
        res.status(500).json({ error: data.message || "Paystack checkout failed. Please check your Paystack configuration." });
        return;
      }

      checkoutUrl = data.data.authorization_url;

    /* ── Flutterwave ──────────────────────────────────────────────── */
    } else if (provider === "flutterwave") {
      const fwKey = process.env.FLUTTERWAVE_SECRET_KEY;
      if (!fwKey) {
        res.status(500).json({ error: "Flutterwave secret key not configured. Set FLUTTERWAVE_SECRET_KEY in your environment secrets." });
        return;
      }

      const redirectUrl = `${baseUrl}/api/subscriptions/verify-redirect?provider=flutterwave&planId=${planId}&tenantId=${tenantId}&reference=${reference}`;

      const response = await fetch("https://api.flutterwave.com/v3/payments", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${fwKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          tx_ref: reference,
          amount: localPrice,         // major units for Flutterwave
          currency: chargeCurrency,
          redirect_url: redirectUrl,
          // Enable all payment methods — Flutterwave shows what's available per country
          payment_options: "card,banktransfer,mobilemoney,mpesa,ussd,barter,qr",
          customer: {
            email: userRecord?.email ?? "user@example.com",
            name: userRecord?.name ?? "User",
          },
          customizations: {
            title: `HustleOS AI — ${plan.name}`,
            description: `Subscribe to ${plan.name} plan`,
            logo: `${baseUrl}/apple-touch-icon.png`,
          },
          meta: {
            planId,
            tenantId,
            expectedAmount: localPrice,
            expectedCurrency: chargeCurrency,
          },
        }),
      });

      const data = (await response.json()) as {
        status?: string;
        message?: string;
        data?: { link: string };
      };

      if (data.status !== "success" || !data.data?.link) {
        logger.error({ data }, "Flutterwave initialize failed");
        res.status(500).json({ error: data.message || "Flutterwave checkout failed. Please check your Flutterwave configuration." });
        return;
      }

      checkoutUrl = data.data.link;
    } else {
      res.status(400).json({ error: "Invalid provider. Must be paystack or flutterwave." });
      return;
    }

    res.json({ checkoutUrl, reference });
  } catch (err) {
    logger.error({ err }, "POST /subscriptions/checkout error");
    res.status(500).json({ error: "Internal server error" });
  }
});

/* ------------------------------------------------------------------ */
/*  GET /subscriptions/verify-redirect                                */
/*  Server-side callback hit after payment gateway redirects user.   */
/*  Re-verifies with the provider API and activates subscription.    */
/* ------------------------------------------------------------------ */
router.get("/subscriptions/verify-redirect", async (req, res) => {
  const { provider, planId, tenantId, reference, trxref, transaction_id, status: fwStatus } = req.query as Record<string, string | undefined>;

  const resolvedReference = reference ?? trxref;

  const domain = (process.env.REPLIT_DOMAINS?.split(",")[0] ?? "localhost");
  const baseUrl = domain.startsWith("http") ? domain : `https://${domain}`;
  const billingUrl = `${baseUrl}/billing`;

  const fail = (reason: string) => {
    logger.warn({ reason, provider, planId, tenantId }, "verify-redirect failed");
    res.redirect(`${billingUrl}?payment=failed&reason=${encodeURIComponent(reason)}`);
  };

  try {
    if (!provider || !planId || !tenantId) {
      return fail("Missing required parameters");
    }

    const [plan] = await db
      .select()
      .from(subscriptionPlansTable)
      .where(eq(subscriptionPlansTable.id, planId))
      .limit(1);

    if (!plan) return fail("Plan not found");

    /* ── Paystack redirect verification ──────────────────────────── */
    if (provider === "paystack") {
      if (!resolvedReference) return fail("Missing payment reference");

      const paystackKey = process.env.PAYSTACK_SECRET_KEY;
      const verifyRes = await fetch(`https://api.paystack.co/transaction/verify/${resolvedReference}`, {
        headers: { Authorization: `Bearer ${paystackKey}` },
      });
      const verifyData = (await verifyRes.json()) as {
        status?: boolean;
        data?: {
          status: string;
          amount: number;
          currency: string;
          metadata?: { planId?: string; tenantId?: string; expectedAmount?: number; expectedCurrency?: string };
        };
      };

      if (!verifyData.status || verifyData.data?.status !== "success") {
        return fail("Paystack verification failed");
      }

      const paidAmount = verifyData.data.amount ?? 0;
      const paidCurrency = verifyData.data.currency ?? "NGN";

      // Use stored expectedAmount if available, else derive from CURRENCY_PRICES
      const expectedAmount =
        verifyData.data.metadata?.expectedAmount ??
        Math.round(getLocalizedPrice(planId, Number(plan.price), paidCurrency) * 100);

      if (paidAmount < expectedAmount) {
        logger.warn({ paidAmount, expectedAmount, paidCurrency }, "Paystack redirect: amount mismatch");
        return fail("Payment amount does not match plan price");
      }

      await activateSubscription(tenantId, planId, plan.name, "paystack", resolvedReference);
      logger.info({ tenantId, planId, paidCurrency }, "Subscription activated via Paystack redirect");
      return res.redirect(`${billingUrl}?payment=success&plan=${encodeURIComponent(plan.name)}`);

    /* ── Flutterwave redirect verification ───────────────────────── */
    } else if (provider === "flutterwave") {
      if (fwStatus !== "successful") return fail("Payment was not successful");
      if (!transaction_id) return fail("Missing transaction ID");

      const fwKey = process.env.FLUTTERWAVE_SECRET_KEY;
      const verifyRes = await fetch(`https://api.flutterwave.com/v3/transactions/${transaction_id}/verify`, {
        headers: { Authorization: `Bearer ${fwKey}` },
      });
      const verifyData = (await verifyRes.json()) as {
        status?: string;
        data?: {
          status: string;
          amount: number;
          currency: string;
          tx_ref: string;
          meta?: { planId?: string; tenantId?: string; expectedAmount?: number; expectedCurrency?: string };
        };
      };

      if (verifyData.status !== "success" || verifyData.data?.status !== "successful") {
        return fail("Flutterwave verification failed");
      }

      const paidAmount = verifyData.data.amount ?? 0;
      const paidCurrency = verifyData.data.currency ?? "NGN";

      // Use stored expectedAmount if available, else derive from CURRENCY_PRICES
      const expectedAmount =
        verifyData.data.meta?.expectedAmount ??
        getLocalizedPrice(planId, Number(plan.price), paidCurrency);

      if (paidAmount < expectedAmount) {
        logger.warn({ paidAmount, expectedAmount, paidCurrency }, "Flutterwave redirect: amount mismatch");
        return fail("Payment amount does not match plan price");
      }

      const ref = verifyData.data.tx_ref ?? resolvedReference ?? transaction_id;
      await activateSubscription(tenantId, planId, plan.name, "flutterwave", ref);
      logger.info({ tenantId, planId, paidCurrency }, "Subscription activated via Flutterwave redirect");
      return res.redirect(`${billingUrl}?payment=success&plan=${encodeURIComponent(plan.name)}`);

    } else {
      return fail("Unknown provider");
    }
  } catch (err) {
    logger.error({ err }, "GET /subscriptions/verify-redirect error");
    return fail("Server error during verification");
  }
});

/* ------------------------------------------------------------------ */
/*  POST /subscriptions/webhooks/paystack                             */
/*  Verifies HMAC-SHA512 signature; re-verifies with Paystack API.   */
/* ------------------------------------------------------------------ */
router.post("/subscriptions/webhooks/paystack", async (req: Request, res) => {
  try {
    const signature = req.headers["x-paystack-signature"] as string | undefined;

    const rawBody: Buffer = Buffer.isBuffer(req.body) ? req.body : Buffer.from(JSON.stringify(req.body));

    if (!signature || !verifyPaystackSignature(rawBody, signature)) {
      logger.warn("Paystack webhook: invalid signature");
      res.status(401).json({ error: "Invalid signature" });
      return;
    }

    const event = JSON.parse(rawBody.toString()) as {
      event?: string;
      data?: {
        reference?: string;
        amount?: number;
        currency?: string;
        status?: string;
        metadata?: { planId?: string; tenantId?: string; expectedAmount?: number; expectedCurrency?: string };
      };
    };

    logger.info({ eventType: event?.event }, "Paystack webhook received");

    if (event?.event === "charge.success") {
      const { reference, metadata, currency: paidCurrency } = event.data ?? {};
      const { planId, tenantId } = metadata ?? {};

      if (!reference || !planId || !tenantId) {
        logger.warn({ event }, "Paystack webhook: missing fields in payload");
        res.status(200).json({ received: true });
        return;
      }

      const paystackKey = process.env.PAYSTACK_SECRET_KEY;
      const verifyRes = await fetch(`https://api.paystack.co/transaction/verify/${reference}`, {
        headers: { Authorization: `Bearer ${paystackKey}` },
      });
      const verifyData = (await verifyRes.json()) as {
        status?: boolean;
        data?: { status: string; amount: number; currency: string };
      };

      if (!verifyData.status || verifyData.data?.status !== "success") {
        logger.warn({ reference }, "Paystack webhook: API re-verification failed");
        res.status(200).json({ received: true });
        return;
      }

      const [plan] = await db
        .select()
        .from(subscriptionPlansTable)
        .where(eq(subscriptionPlansTable.id, planId))
        .limit(1);

      if (!plan) {
        logger.warn({ planId }, "Paystack webhook: plan not found");
        res.status(200).json({ received: true });
        return;
      }

      const verifiedCurrency = verifyData.data?.currency ?? paidCurrency ?? "NGN";
      const paidAmount = verifyData.data?.amount ?? 0;
      const expectedAmount =
        metadata?.expectedAmount ??
        Math.round(getLocalizedPrice(planId, Number(plan.price), verifiedCurrency) * 100);

      if (paidAmount < expectedAmount) {
        logger.warn({ paidAmount, expectedAmount, verifiedCurrency, reference }, "Paystack webhook: amount mismatch");
        res.status(200).json({ received: true });
        return;
      }

      await activateSubscription(tenantId, planId, plan.name, "paystack", reference);
      logger.info({ tenantId, planId }, "Subscription activated via Paystack webhook");
    }

    res.status(200).json({ received: true });
  } catch (err) {
    logger.error({ err }, "Paystack webhook error");
    res.status(200).json({ received: true });
  }
});

/* ------------------------------------------------------------------ */
/*  POST /subscriptions/webhooks/flutterwave                         */
/*  Verifies verif-hash header; re-verifies with Flutterwave API.    */
/* ------------------------------------------------------------------ */
router.post("/subscriptions/webhooks/flutterwave", async (req: Request, res) => {
  try {
    const verifHash = req.headers["verif-hash"] as string | undefined;

    if (!verifyFlutterwaveSignature(verifHash)) {
      logger.warn("Flutterwave webhook: invalid verif-hash");
      res.status(401).json({ error: "Invalid signature" });
      return;
    }

    const rawBody: Buffer = Buffer.isBuffer(req.body) ? req.body : Buffer.from(JSON.stringify(req.body));
    const event = JSON.parse(rawBody.toString()) as {
      event?: string;
      data?: {
        id?: number;
        status?: string;
        tx_ref?: string;
        amount?: number;
        currency?: string;
        meta?: { planId?: string; tenantId?: string; expectedAmount?: number; expectedCurrency?: string };
      };
    };

    logger.info({ eventType: event?.event }, "Flutterwave webhook received");

    if (event?.event === "charge.completed" && event?.data?.status === "successful") {
      const { id: txId, tx_ref, meta } = event.data ?? {};
      const { planId, tenantId } = meta ?? {};

      if (!txId || !planId || !tenantId) {
        logger.warn({ event }, "Flutterwave webhook: missing fields in payload");
        res.status(200).json({ received: true });
        return;
      }

      const fwKey = process.env.FLUTTERWAVE_SECRET_KEY;
      const verifyRes = await fetch(`https://api.flutterwave.com/v3/transactions/${txId}/verify`, {
        headers: { Authorization: `Bearer ${fwKey}` },
      });
      const verifyData = (await verifyRes.json()) as {
        status?: string;
        data?: { status: string; amount: number; currency: string };
      };

      if (verifyData.status !== "success" || verifyData.data?.status !== "successful") {
        logger.warn({ txId }, "Flutterwave webhook: API re-verification failed");
        res.status(200).json({ received: true });
        return;
      }

      const [plan] = await db
        .select()
        .from(subscriptionPlansTable)
        .where(eq(subscriptionPlansTable.id, planId))
        .limit(1);

      if (!plan) {
        logger.warn({ planId }, "Flutterwave webhook: plan not found");
        res.status(200).json({ received: true });
        return;
      }

      const verifiedCurrency = verifyData.data?.currency ?? "NGN";
      const paidAmount = verifyData.data?.amount ?? 0;
      const expectedAmount =
        meta?.expectedAmount ??
        getLocalizedPrice(planId, Number(plan.price), verifiedCurrency);

      if (paidAmount < expectedAmount) {
        logger.warn({ paidAmount, expectedAmount, verifiedCurrency, tx_ref }, "Flutterwave webhook: amount mismatch");
        res.status(200).json({ received: true });
        return;
      }

      const reference = tx_ref ?? String(txId);
      await activateSubscription(tenantId, planId, plan.name, "flutterwave", reference);
      logger.info({ tenantId, planId }, "Subscription activated via Flutterwave webhook");
    }

    res.status(200).json({ received: true });
  } catch (err) {
    logger.error({ err }, "Flutterwave webhook error");
    res.status(200).json({ received: true });
  }
});

export default router;
