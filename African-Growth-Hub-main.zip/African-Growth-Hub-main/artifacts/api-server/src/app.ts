import express, { type Express, type Request, type Response, type NextFunction } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import helmet from "helmet";
import { rateLimit } from "express-rate-limit";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

// Trust the Replit reverse proxy so req.ip and rate limiting work correctly
app.set("trust proxy", 1);

// Security headers
app.use(
  helmet({
    contentSecurityPolicy: false,
    crossOriginResourcePolicy: { policy: "cross-origin" },
  })
);

// Rate limiting — 200 req/min per IP (generous for an SME SaaS)
const limiter = rateLimit({
  windowMs: 60 * 1000,
  max: 200,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Too many requests. Please wait a moment and try again." },
});

// Stricter limit on auth-adjacent and AI endpoints (60/min)
const aiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 60,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Rate limit reached on AI endpoint. Please try again shortly." },
});

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req: { id: unknown; method: string; url?: string }) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res: { statusCode: number }) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);

const allowedOrigins = process.env.REPLIT_DOMAINS
  ? process.env.REPLIT_DOMAINS.split(",").map((d) => `https://${d.trim()}`)
  : [];

app.use(
  cors({
    origin: (origin, cb) => {
      // Allow requests with no origin (curl, mobile apps, server-to-server)
      if (!origin) return cb(null, true);
      // Allow any replit.dev / replit.app subdomain in development
      if (origin.endsWith(".replit.dev") || origin.endsWith(".replit.app")) return cb(null, true);
      // Allow explicit production domains
      if (allowedOrigins.includes(origin)) return cb(null, true);
      // Allow localhost for local dev
      if (origin.startsWith("http://localhost") || origin.startsWith("http://127.0.0.1")) return cb(null, true);
      cb(null, false);
    },
    credentials: true,
  })
);

// Capture raw body for webhook signature verification BEFORE JSON parsing.
// Webhook routes need Buffer; AI routes get a tight cap; all other routes get 1 MB.
app.use((req: Request, _res: Response, next: NextFunction) => {
  if (req.path.startsWith("/api/subscriptions/webhooks/")) {
    express.raw({ type: "application/json", limit: "1mb" })(req, _res, next);
  } else if (req.path.startsWith("/api/ai/") || req.path.startsWith("/api/transactions/parse")) {
    express.json({ limit: "64kb" })(req, _res, next);
  } else {
    express.json({ limit: "1mb" })(req, _res, next);
  }
});

app.use(express.urlencoded({ extended: true, limit: "1mb" }));

app.use("/api", limiter);
app.use("/api/ai", aiLimiter);
app.use("/api", router);

// Global error handler — catches anything that escapes route try/catch blocks
app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
  const message = err instanceof Error ? err.message : "Internal server error";
  const status = (err as { status?: number })?.status ?? 500;
  logger.error({ err }, "Unhandled error");
  if (!res.headersSent) {
    res.status(status).json({ error: message });
  }
});

export default app;
