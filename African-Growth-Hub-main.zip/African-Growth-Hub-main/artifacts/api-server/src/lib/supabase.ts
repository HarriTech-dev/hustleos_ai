import { createClient } from "@supabase/supabase-js";

const rawUrl = process.env.SUPABASE_URL ?? "";
// SUPABASE_URL secret may have /rest/v1/ appended — strip it
const supabaseUrl = rawUrl.replace(/\/rest\/v1\/?$/, "").replace(/\/$/, "");
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY ?? "";

if (!supabaseUrl || !serviceRoleKey) {
  throw new Error("SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY env vars are required");
}

// Server-side Supabase client with service role key for admin operations
export const supabase = createClient(supabaseUrl, serviceRoleKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
});
