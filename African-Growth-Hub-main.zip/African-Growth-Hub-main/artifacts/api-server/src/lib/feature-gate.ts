import { type Response, type NextFunction } from "express";
import { db, subscriptionPlansTable, subscriptionsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { logger } from "./logger";
import type { AuthenticatedRequest } from "./auth";

// Feature flags per plan
const PLAN_FEATURES: Record<string, string[]> = {
  plan_free: ["dashboard", "transactions", "customers", "debtors", "inventory", "invoices", "reports", "ai_advisor", "settings", "team_read"],
  plan_pro: ["dashboard", "transactions", "customers", "debtors", "inventory", "invoices", "reports", "ai_advisor", "forecasting", "crm", "ai_marketing", "team_full", "settings"],
  plan_premium: ["dashboard", "transactions", "customers", "debtors", "inventory", "invoices", "reports", "ai_advisor", "forecasting", "crm", "ai_marketing", "marketplace", "team_full", "notifications", "audit_logs", "settings"],
  plan_enterprise: ["*"], // all features
};

const FEATURE_NAMES: Record<string, string> = {
  dashboard: "Dashboard",
  transactions: "Transactions",
  customers: "Customers",
  debtors: "Debtors",
  inventory: "Inventory",
  invoices: "Invoices",
  reports: "Reports",
  ai_advisor: "AI Advisor",
  forecasting: "Forecasting",
  crm: "CRM",
  ai_marketing: "AI Marketing",
  marketplace: "Marketplace",
  team_read: "Team (View Only)",
  team_full: "Team (Full)",
  notifications: "Notifications",
  audit_logs: "Audit Logs",
  settings: "Settings",
};

export async function getTenantPlan(tenantId: string): Promise<{ planId: string; planName: string; features: string[] } | null> {
  try {
    const [sub] = await db
      .select()
      .from(subscriptionsTable)
      .where(and(eq(subscriptionsTable.tenantId, tenantId), eq(subscriptionsTable.status, "active")))
      .limit(1);

    if (!sub) {
      // Default to free plan
      return { planId: "plan_free", planName: "Free", features: PLAN_FEATURES.plan_free };
    }

    const [plan] = await db.select().from(subscriptionPlansTable).where(eq(subscriptionPlansTable.id, sub.planId)).limit(1);
    if (!plan) return { planId: sub.planId, planName: sub.planName, features: PLAN_FEATURES.plan_free };

    const features = PLAN_FEATURES[plan.id] || plan.features || PLAN_FEATURES.plan_free;
    return { planId: plan.id, planName: plan.name, features };
  } catch (err) {
    logger.error({ err, tenantId }, "getTenantPlan error");
    return null;
  }
}

export function requireFeature(feature: string) {
  return async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    const tenantId = req.tenantId as string;
    const plan = await getTenantPlan(tenantId);
    if (!plan) {
      res.status(403).json({ error: "Unable to verify subscription plan" });
      return;
    }
    const allowed = plan.features.includes("*") || plan.features.includes(feature);
    if (!allowed) {
      res.status(403).json({
        error: "Feature not available on your plan",
        feature: FEATURE_NAMES[feature] || feature,
        currentPlan: plan.planName,
        upgradeRequired: true,
      });
      return;
    }
    next();
  };
}

export async function checkFeature(tenantId: string, feature: string): Promise<boolean> {
  const plan = await getTenantPlan(tenantId);
  if (!plan) return false;
  return plan.features.includes("*") || plan.features.includes(feature);
}
