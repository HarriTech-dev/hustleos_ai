import { Resend } from "resend";

const apiKey = process.env.RESEND_API_KEY;
export const resend = apiKey ? new Resend(apiKey) : null;
export const FROM_EMAIL = process.env.RESEND_FROM_EMAIL || "onboarding@resend.dev";

export function isResendConfigured(): boolean {
  return !!resend;
}

export async function sendEmail({
  to,
  subject,
  html,
  text,
}: {
  to: string;
  subject: string;
  html: string;
  text?: string;
}): Promise<{ id?: string; error?: string }> {
  if (!resend) {
    return { error: "Resend not configured" };
  }
  try {
    const { data, error } = await resend.emails.send({
      from: FROM_EMAIL,
      to,
      subject,
      html,
      text,
    });
    if (error) {
      return { error: error.message };
    }
    return { id: data?.id };
  } catch (err: any) {
    return { error: err?.message || "Email send failed" };
  }
}

export function buildInvoiceEmail({
  invoiceNumber,
  customerName,
  items,
  subtotal,
  discount,
  tax,
  total,
  currency,
  dueDate,
  businessName,
  notes,
  invoiceUrl,
  businessLogo,
}: {
  invoiceNumber: string;
  customerName: string;
  items: Array<{ description: string; quantity: number; unitPrice: number; total: number }>;
  subtotal: number;
  discount?: number;
  tax: number;
  total: number;
  currency: string;
  dueDate: string;
  businessName: string;
  notes?: string | null;
  invoiceUrl?: string;
  businessLogo?: string;
}): { html: string; text: string } {
  const itemsHtml = items
    .map(
      (i) =>
        `<tr>
          <td style="padding:8px;border-bottom:1px solid #e5e7eb">${i.description}</td>
          <td style="padding:8px;border-bottom:1px solid #e5e7eb;text-align:center">${i.quantity}</td>
          <td style="padding:8px;border-bottom:1px solid #e5e7eb;text-align:right">${currency} ${i.unitPrice.toLocaleString()}</td>
          <td style="padding:8px;border-bottom:1px solid #e5e7eb;text-align:right">${currency} ${i.total.toLocaleString()}</td>
        </tr>`
    )
    .join("");

  const html = `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Invoice ${invoiceNumber}</title></head>
<body style="font-family:system-ui,-apple-system,sans-serif;background:#f3f4f6;padding:24px">
  <div style="max-width:600px;margin:0 auto;background:#fff;border-radius:8px;padding:32px;box-shadow:0 1px 3px rgba(0,0,0,0.1)">
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:8px">
      ${businessLogo ? `<img src="${businessLogo}" style="width:40px;height:40px;object-fit:cover;border-radius:8px">` : ""}
      <h2 style="margin:0;font-size:20px">${businessName}</h2>
    </div>
    <p style="margin:0 0 24px;color:#6b7280;font-size:14px">Invoice #${invoiceNumber}</p>
    <p style="margin:0 0 8px"><strong>Bill To:</strong> ${customerName}</p>
    <p style="margin:0 0 24px"><strong>Due Date:</strong> ${dueDate}</p>
    <table style="width:100%;border-collapse:collapse;margin-bottom:16px;font-size:14px">
      <thead>
        <tr style="background:#f9fafb;text-align:left">
          <th style="padding:8px;border-bottom:2px solid #e5e7eb">Item</th>
          <th style="padding:8px;border-bottom:2px solid #e5e7eb;text-align:center">Qty</th>
          <th style="padding:8px;border-bottom:2px solid #e5e7eb;text-align:right">Unit</th>
          <th style="padding:8px;border-bottom:2px solid #e5e7eb;text-align:right">Total</th>
        </tr>
      </thead>
      <tbody>${itemsHtml}</tbody>
    </table>
    <div style="text-align:right;font-size:14px">
      <p style="margin:4px 0"><strong>Subtotal:</strong> ${currency} ${subtotal.toLocaleString()}</p>
      ${discount && discount > 0 ? `<p style="margin:4px 0;color:#dc2626"><strong>Discount:</strong> -${currency} ${discount.toLocaleString()}</p>` : ""}
      <p style="margin:4px 0"><strong>Tax:</strong> ${currency} ${tax.toLocaleString()}</p>
      <p style="margin:12px 0;font-size:18px;font-weight:600">Total: ${currency} ${total.toLocaleString()}</p>
    </div>
    ${notes ? `<p style="margin-top:24px;font-size:12px;color:#6b7280"><strong>Notes:</strong> ${notes}</p>` : ""}
    ${invoiceUrl ? `<p style="margin-top:24px"><a href="${invoiceUrl}" style="display:inline-block;padding:12px 24px;background:#111827;color:#fff;border-radius:6px;text-decoration:none;font-size:14px">View Invoice</a></p>` : ""}
    <p style="margin-top:32px;font-size:12px;color:#9ca3af;text-align:center">Sent via HustleOS AI</p>
  </div>
</body>
</html>`;

  const text = `Invoice ${invoiceNumber} from ${businessName}

Bill To: ${customerName}
Due Date: ${dueDate}

Items:
${items.map((i) => `- ${i.description} x${i.quantity} @ ${currency} ${i.unitPrice.toLocaleString()} = ${currency} ${i.total.toLocaleString()}`).join("\n")}

Subtotal: ${currency} ${subtotal.toLocaleString()}
${discount && discount > 0 ? `Discount: -${currency} ${discount.toLocaleString()}\n` : ""}Tax: ${currency} ${tax.toLocaleString()}
Total: ${currency} ${total.toLocaleString()}

${notes ? `Notes: ${notes}\n` : ""}${invoiceUrl ? `View invoice: ${invoiceUrl}\n` : ""}
Sent via HustleOS AI`;

  return { html, text };
}

export function buildReceiptEmail({
  receiptNumber,
  invoiceNumber,
  customerName,
  amount,
  currency,
  paymentMethod,
  businessName,
  businessLogo,
}: {
  receiptNumber: string;
  invoiceNumber: string;
  customerName: string;
  amount: number;
  currency: string;
  paymentMethod: string;
  businessName: string;
  businessLogo?: string;
}): { html: string; text: string } {
  const html = `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Receipt ${receiptNumber}</title></head>
<body style="font-family:system-ui,-apple-system,sans-serif;background:#f3f4f6;padding:24px">
  <div style="max-width:600px;margin:0 auto;background:#fff;border-radius:8px;padding:32px;box-shadow:0 1px 3px rgba(0,0,0,0.1)">
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:8px">
      ${businessLogo ? `<img src="${businessLogo}" style="width:40px;height:40px;object-fit:cover;border-radius:8px">` : ""}
      <h2 style="margin:0;font-size:20px">${businessName}</h2>
    </div>
    <p style="margin:0 0 24px;color:#6b7280;font-size:14px">Receipt #${receiptNumber}</p>
    <div style="padding:20px;background:#f0fdf4;border-radius:8px;margin-bottom:24px">
      <p style="margin:0 0 8px;font-size:24px;font-weight:600;color:#166534">${currency} ${amount.toLocaleString()}</p>
      <p style="margin:0;color:#166534;font-size:14px">Payment received for invoice ${invoiceNumber}</p>
    </div>
    <p style="margin:0 0 8px"><strong>Customer:</strong> ${customerName}</p>
    <p style="margin:0 0 24px"><strong>Payment Method:</strong> ${paymentMethod}</p>
    <p style="margin-top:32px;font-size:12px;color:#9ca3af;text-align:center">Thank you for your business! &mdash; Sent via HustleOS AI</p>
  </div>
</body>
</html>`;

  const text = `Receipt ${receiptNumber} from ${businessName}

${currency} ${amount.toLocaleString()} received
Invoice: ${invoiceNumber}
Customer: ${customerName}
Payment Method: ${paymentMethod}

Thank you for your business! — Sent via HustleOS AI`;

  return { html, text };
}

export function buildTeamInviteEmail({
  inviteeName,
  inviterName,
  businessName,
  role,
  joinUrl,
}: {
  inviteeName: string;
  inviterName: string;
  businessName: string;
  role: string;
  joinUrl?: string;
}): { html: string; text: string } {
  const html = `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Team Invitation</title></head>
<body style="font-family:system-ui,-apple-system,sans-serif;background:#f3f4f6;padding:24px">
  <div style="max-width:480px;margin:0 auto;background:#fff;border-radius:8px;padding:32px;box-shadow:0 1px 3px rgba(0,0,0,0.1)">
    <h2 style="margin:0 0 8px;font-size:20px">You've been invited to ${businessName}</h2>
    <p style="margin:0 0 24px;color:#6b7280;font-size:14px">Team invitation from ${inviterName}</p>
    <p style="margin:0 0 16px">Hi ${inviteeName},</p>
    <p style="margin:0 0 16px">${inviterName} has invited you to join <strong>${businessName}</strong> on HustleOS AI as a <strong>${role}</strong>.</p>
    ${joinUrl ? `<p style="margin:0 0 24px"><a href="${joinUrl}" style="display:inline-block;padding:12px 24px;background:#111827;color:#fff;border-radius:6px;text-decoration:none;font-size:14px">Accept Invitation</a></p>` : ""}
    <p style="margin:0 0 8px;font-size:12px;color:#9ca3af">If you didn't expect this invitation, you can safely ignore it.</p>
    <p style="margin:0;font-size:12px;color:#9ca3af;text-align:center">Sent via HustleOS AI</p>
  </div>
</body>
</html>`;

  const text = `Team Invitation from ${businessName}

Hi ${inviteeName},

${inviterName} has invited you to join ${businessName} on HustleOS AI as a ${role}.

${joinUrl ? `Accept invitation: ${joinUrl}\n` : ""}
If you didn't expect this invitation, you can safely ignore it.

Sent via HustleOS AI`;

  return { html, text };
}

export function buildWelcomeEmail({
  name,
  businessName,
}: {
  name: string;
  businessName?: string;
}): { html: string; text: string } {
  const html = `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Welcome to HustleOS AI</title></head>
<body style="font-family:system-ui,-apple-system,sans-serif;background:#f3f4f6;padding:24px">
  <div style="max-width:480px;margin:0 auto;background:#fff;border-radius:8px;padding:32px;box-shadow:0 1px 3px rgba(0,0,0,0.1)">
    <h2 style="margin:0 0 8px;font-size:20px">Welcome to HustleOS AI, ${name}!</h2>
    <p style="margin:0 0 24px;color:#6b7280;font-size:14px">Your business operating system is ready.</p>
    <p style="margin:0 0 16px">Hi ${name},</p>
    <p style="margin:0 0 16px">Thanks for joining HustleOS AI. Your account is set up and ready to go.</p>
    ${businessName ? `<p style="margin:0 0 16px">Your business <strong>${businessName}</strong> is now registered.</p>` : ""}
    <p style="margin:0 0 24px">Get started by creating your first invoice, adding inventory, or exploring the AI advisor.</p>
    <p style="margin:0;font-size:12px;color:#9ca3af;text-align:center">Sent via HustleOS AI</p>
  </div>
</body>
</html>`;

  const text = `Welcome to HustleOS AI, ${name}!

Hi ${name},

Thanks for joining HustleOS AI. Your account is set up and ready to go.
${businessName ? `Your business ${businessName} is now registered.\n` : ""}
Get started by creating your first invoice, adding inventory, or exploring the AI advisor.

Sent via HustleOS AI`;

  return { html, text };
}

export function buildPasswordResetEmail({
  name,
  resetUrl,
}: {
  name: string;
  resetUrl: string;
}): { html: string; text: string } {
  const html = `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Password Reset</title></head>
<body style="font-family:system-ui,-apple-system,sans-serif;background:#f3f4f6;padding:24px">
  <div style="max-width:480px;margin:0 auto;background:#fff;border-radius:8px;padding:32px;box-shadow:0 1px 3px rgba(0,0,0,0.1)">
    <h2 style="margin:0 0 8px;font-size:20px">Reset your password</h2>
    <p style="margin:0 0 24px;color:#6b7280;font-size:14px">Password reset request for HustleOS AI</p>
    <p style="margin:0 0 16px">Hi ${name},</p>
    <p style="margin:0 0 16px">We received a request to reset your password. Click the button below to set a new one.</p>
    <p style="margin:0 0 24px"><a href="${resetUrl}" style="display:inline-block;padding:12px 24px;background:#111827;color:#fff;border-radius:6px;text-decoration:none;font-size:14px">Reset Password</a></p>
    <p style="margin:0 0 8px;font-size:12px;color:#9ca3af">If you didn't request this, you can safely ignore this email.</p>
    <p style="margin:0;font-size:12px;color:#9ca3af;text-align:center">Sent via HustleOS AI</p>
  </div>
</body>
</html>`;

  const text = `Reset your password

Hi ${name},

We received a request to reset your password. Click the link below to set a new one:

${resetUrl}

If you didn't request this, you can safely ignore this email.

Sent via HustleOS AI`;

  return { html, text };
}
