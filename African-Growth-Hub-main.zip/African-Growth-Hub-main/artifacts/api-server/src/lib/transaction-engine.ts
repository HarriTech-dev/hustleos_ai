/**
 * Transaction Engine — centralized event dispatcher for all business events.
 * Call these from route handlers after primary DB writes succeed.
 * All side effects are fire-and-forget with try/catch to never block the response.
 */
import { db, transactionsTable, inventoryTable, stockAdjustmentsTable, ordersTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { generateId } from "./id";
import { logger } from "./logger";
import { createNotification } from "../routes/notifications";
import { writeAuditLog } from "../routes/audit-logs";

// ─── Event Types ─────────────────────────────────────────────────────────────

export interface InvoiceSaleEvent {
  tenantId: string;
  userId: string;
  customerId: string;
  customerName: string;
  customerPhone?: string | null;
  invoiceId: string;
  invoiceNumber: string;
  amount: number;
  currency: string;
  items: Array<{ description: string; quantity: number; unitPrice: number; total: number }>;
  date?: string;
}

export interface PaymentReceivedEvent {
  tenantId: string;
  userId: string;
  customerId: string;
  customerName: string;
  invoiceId: string;
  invoiceNumber: string;
  amount: number;
  currency: string;
  isFullyPaid: boolean;
}

export interface StockReceivedEvent {
  tenantId: string;
  userId: string;
  purchaseOrderId: string;
  poNumber: string;
  supplierName: string;
  totalAmount: number;
  currency: string;
  items: Array<{ description: string; quantity: number; unitPrice: number; total: number }>;
}

// ─── Dispatchers ─────────────────────────────────────────────────────────────

/**
 * Called when an invoice is CREATED.
 * Creates a "sale" transaction + deducts inventory + creates CRM order entry.
 */
export async function dispatchInvoiceSale(event: InvoiceSaleEvent): Promise<void> {
  const today = event.date ?? new Date().toISOString().slice(0, 10);

  // 1. Create "sale" transaction linked to customer + invoice
  try {
    await db.insert(transactionsTable).values({
      id: generateId(),
      tenantId: event.tenantId,
      type: "sale",
      amount: String(event.amount),
      description: `Invoice ${event.invoiceNumber} — ${event.customerName}`,
      category: "sales",
      date: today,
      customerId: event.customerId,
      invoiceId: event.invoiceId,
      notes: `Sale recorded for ${event.customerName}`,
    });
  } catch (err) {
    logger.error({ err }, "TransactionEngine: failed to create sale transaction");
  }

  // 2. Deduct inventory per item + create stock adjustment records
  for (const item of event.items) {
    try {
      const [prod] = await db
        .select()
        .from(inventoryTable)
        .where(and(eq(inventoryTable.tenantId, event.tenantId), eq(inventoryTable.name, item.description)))
        .limit(1);

      if (prod) {
        const newQty = Math.max(0, prod.quantity - item.quantity);
        await db
          .update(inventoryTable)
          .set({ quantity: newQty, updatedAt: new Date() })
          .where(eq(inventoryTable.id, prod.id));

        await db.insert(stockAdjustmentsTable).values({
          id: generateId(),
          inventoryId: prod.id,
          tenantId: event.tenantId,
          adjustment: -item.quantity,
          reason: "sale",
          notes: `Sold ${item.quantity} unit(s) via ${event.invoiceNumber}`,
        });

        if (newQty <= prod.lowStockThreshold) {
          await createNotification({
            tenantId: event.tenantId,
            userId: event.userId,
            type: "low_stock",
            title: "Low Stock Alert",
            message: `${prod.name} is now low on stock (${newQty} remaining).`,
            link: `/inventory/${prod.id}`,
          });
        }
      }
    } catch (err) {
      logger.error({ err, item: item.description }, "TransactionEngine: inventory deduction failed");
    }
  }

  // 3. Create CRM order entry (only if customer has a phone number)
  if (event.customerPhone) {
    try {
      await db.insert(ordersTable).values({
        id: generateId(),
        tenantId: event.tenantId,
        customerId: event.customerId,
        customerName: event.customerName,
        customerPhone: event.customerPhone,
        items: event.items,
        total: String(event.amount),
        currency: event.currency,
        status: "pending",
        notes: `Auto-created from invoice ${event.invoiceNumber}`,
        whatsappNumber: event.customerPhone,
      });
    } catch (err) {
      logger.error({ err }, "TransactionEngine: CRM order creation failed");
    }
  }

  // 4. Audit log
  try {
    await writeAuditLog({
      tenantId: event.tenantId,
      userId: event.userId,
      action: "sale_dispatched",
      resource: "invoice",
      resourceId: event.invoiceId,
      changes: { invoiceNumber: event.invoiceNumber, amount: event.amount, customer: event.customerName, itemCount: event.items.length },
    });
  } catch (err) {
    logger.error({ err }, "TransactionEngine: audit log failed for invoice sale");
  }
}

/**
 * Called when a payment is received on an invoice.
 * Updates CRM order status when fully paid.
 */
export async function dispatchPaymentReceived(event: PaymentReceivedEvent): Promise<void> {
  if (!event.isFullyPaid) return;

  // Update CRM order status for this customer's most recent pending order
  try {
    const [order] = await db
      .select()
      .from(ordersTable)
      .where(
        and(
          eq(ordersTable.tenantId, event.tenantId),
          eq(ordersTable.customerId, event.customerId),
          eq(ordersTable.status, "pending"),
        )
      )
      .limit(1);

    if (order) {
      await db
        .update(ordersTable)
        .set({ status: "delivered", updatedAt: new Date() })
        .where(eq(ordersTable.id, order.id));
    }
  } catch (err) {
    logger.error({ err }, "TransactionEngine: CRM order update on payment failed");
  }
}

/**
 * Called when a Purchase Order is marked as received.
 * Creates expense transaction + increases inventory + creates stock adjustments.
 */
export async function dispatchStockReceived(event: StockReceivedEvent): Promise<void> {
  const today = new Date().toISOString().slice(0, 10);

  // 1. Create expense transaction linked to PO
  try {
    await db.insert(transactionsTable).values({
      id: generateId(),
      tenantId: event.tenantId,
      type: "expense",
      amount: String(event.totalAmount),
      description: `Stock received — ${event.supplierName} (${event.poNumber})`,
      category: "inventory",
      date: today,
      purchaseOrderId: event.purchaseOrderId,
      notes: `Purchase order ${event.poNumber} received from ${event.supplierName}`,
    });
  } catch (err) {
    logger.error({ err }, "TransactionEngine: expense transaction failed for PO receive");
  }

  // 2. Increase inventory for each item, create if not found
  for (const item of event.items) {
    try {
      const [prod] = await db
        .select()
        .from(inventoryTable)
        .where(and(eq(inventoryTable.tenantId, event.tenantId), eq(inventoryTable.name, item.description)))
        .limit(1);

      if (prod) {
        const newQty = prod.quantity + item.quantity;
        await db
          .update(inventoryTable)
          .set({ quantity: newQty, updatedAt: new Date() })
          .where(eq(inventoryTable.id, prod.id));

        await db.insert(stockAdjustmentsTable).values({
          id: generateId(),
          inventoryId: prod.id,
          tenantId: event.tenantId,
          adjustment: item.quantity,
          reason: "restock",
          notes: `Restocked ${item.quantity} unit(s) via PO ${event.poNumber}`,
        });
      } else {
        // Auto-create inventory item from PO
        const newProdId = generateId();
        await db.insert(inventoryTable).values({
          id: newProdId,
          tenantId: event.tenantId,
          name: item.description,
          sku: `PO-${event.poNumber.replace(/[^a-zA-Z0-9]/g, "")}-${newProdId.slice(0, 6).toUpperCase()}`,
          quantity: item.quantity,
          lowStockThreshold: 5,
          price: String(item.unitPrice),
          costPrice: String(item.unitPrice),
          category: "general",
          unit: "unit",
          currency: event.currency,
        });

        await db.insert(stockAdjustmentsTable).values({
          id: generateId(),
          inventoryId: newProdId,
          tenantId: event.tenantId,
          adjustment: item.quantity,
          reason: "restock",
          notes: `New product added from PO ${event.poNumber}`,
        });
      }
    } catch (err) {
      logger.error({ err, item: item.description }, "TransactionEngine: stock increase failed");
    }
  }

  // 3. Notification
  try {
    await createNotification({
      tenantId: event.tenantId,
      userId: event.userId,
      type: "system",
      title: "Stock Received",
      message: `Purchase order ${event.poNumber} from ${event.supplierName} received. Inventory updated for ${event.items.length} item(s).`,
      link: `/purchase-orders/${event.purchaseOrderId}`,
    });
  } catch (err) {
    logger.error({ err }, "TransactionEngine: notification failed for stock received");
  }

  // 4. Audit log
  try {
    await writeAuditLog({
      tenantId: event.tenantId,
      userId: event.userId,
      action: "stock_received",
      resource: "purchase_order",
      resourceId: event.purchaseOrderId,
      changes: { poNumber: event.poNumber, supplier: event.supplierName, total: event.totalAmount, items: event.items.length },
    });
  } catch (err) {
    logger.error({ err }, "TransactionEngine: audit log failed for stock received");
  }
}
