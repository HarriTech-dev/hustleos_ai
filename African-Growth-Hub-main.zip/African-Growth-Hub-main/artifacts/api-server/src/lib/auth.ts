import { type Request, type Response, type NextFunction } from "express";
import { db, usersTable, teamMembersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { logger } from "./logger";
import { supabase } from "./supabase";

export interface AuthenticatedRequest extends Request {
  userId?: string;
  tenantId?: string;
  userRole?: string;
}

export async function requireAuth(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const token = authHeader.slice(7);

  try {
    // Verify with Supabase using the server-side client
    const { data: userData, error } = await supabase.auth.getUser(token);

    if (error || !userData.user) {
      res.status(401).json({ error: "Invalid token" });
      return;
    }

    const supabaseUser = userData.user;

    // Upsert user record
    const existing = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, supabaseUser.id))
      .limit(1);

    if (existing.length === 0) {
      await db
        .insert(usersTable)
        .values({
          id: supabaseUser.id,
          email: supabaseUser.email ?? "",
          name: supabaseUser.email?.split("@")[0] ?? "",
          tenantId: supabaseUser.id,
          role: "owner",
          businessName: "",
          currency: "NGN",
        })
        .onConflictDoNothing();
    }

    // Check if user is a team member (has been invited/accepted)
    const [teamMember] = await db
      .select()
      .from(teamMembersTable)
      .where(eq(teamMembersTable.userId, supabaseUser.id))
      .limit(1);

    if (teamMember) {
      req.userId = supabaseUser.id;
      req.tenantId = teamMember.tenantId;
      req.userRole = teamMember.role;
    } else {
      req.userId = supabaseUser.id;
      req.tenantId = existing[0]?.tenantId ?? supabaseUser.id;
      req.userRole = existing[0]?.role ?? "owner";
    }
    next();
  } catch (err) {
    logger.error({ err }, "Auth middleware error");
    res.status(500).json({ error: "Internal server error" });
  }
}
