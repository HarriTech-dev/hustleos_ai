import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';
import { Package, AlertTriangle } from 'lucide-react';

export function Scene4() {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const t1 = setTimeout(() => setPhase(1), 300);
    const t2 = setTimeout(() => setPhase(2), 1500);
    const t3 = setTimeout(() => setPhase(3), 3000);
    const t4 = setTimeout(() => setPhase(4), 8500);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); clearTimeout(t4); };
  }, []);

  return (
    <motion.div 
      className="absolute inset-0 flex items-center p-20 z-10"
      initial={{ opacity: 0, filter: 'blur(20px)' }}
      animate={{ opacity: 1, filter: 'blur(0px)' }}
      exit={{ opacity: 0, x: -100 }}
      transition={{ duration: 0.8 }}
    >
      <div className="w-1/2 pr-12 z-20">
        <motion.h2 
          className="text-5xl font-display font-bold text-white mb-6 leading-tight"
          initial={{ opacity: 0, y: 20 }}
          animate={phase >= 1 ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
        >
          Never run out of stock.
        </motion.h2>
        <motion.p 
          className="text-xl text-muted"
          initial={{ opacity: 0 }}
          animate={phase >= 1 ? { opacity: 1 } : { opacity: 0 }}
          transition={{ delay: 0.2 }}
        >
          Track inventory automatically and get low-stock alerts before it's too late.
        </motion.p>
      </div>

      <div className="w-1/2 relative h-full flex flex-col items-center justify-center gap-4">
        {[
          { name: 'Arabica Beans', stock: 120, low: false },
          { name: 'Robusta Beans', stock: 5, low: true },
          { name: 'Vanilla Syrup', stock: 45, low: false },
        ].map((item, i) => (
          <motion.div 
            key={i}
            className={`w-full max-w-md bg-surface border ${item.low ? 'border-orange-500' : 'border-border'} rounded-xl p-4 flex items-center justify-between`}
            initial={{ x: 100, opacity: 0 }}
            animate={phase >= 2 ? { x: 0, opacity: 1 } : { x: 100, opacity: 0 }}
            transition={{ delay: i * 0.2, type: 'spring' }}
          >
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-background rounded flex items-center justify-center">
                <Package size={18} className="text-muted" />
              </div>
              <span className="text-white font-medium">{item.name}</span>
            </div>
            
            <div className="flex items-center gap-4">
              {item.low && phase >= 3 && (
                <motion.div 
                  initial={{ scale: 0 }} 
                  animate={{ scale: 1 }}
                  className="text-orange-500 flex items-center gap-1 text-sm"
                >
                  <AlertTriangle size={14} /> Low
                </motion.div>
              )}
              <span className={`font-bold ${item.low && phase >= 3 ? 'text-orange-500' : 'text-white'}`}>
                {item.stock} units
              </span>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
