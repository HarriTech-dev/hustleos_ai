import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';
import { Activity } from 'lucide-react';

export function Scene6() {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const t1 = setTimeout(() => setPhase(1), 300);
    const t2 = setTimeout(() => setPhase(2), 1500);
    const t3 = setTimeout(() => setPhase(3), 3500);
    const t4 = setTimeout(() => setPhase(4), 8500);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); clearTimeout(t4); };
  }, []);

  return (
    <motion.div 
      className="absolute inset-0 flex items-center justify-center p-20 z-10"
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, filter: 'blur(10px)' }}
      transition={{ duration: 0.8 }}
    >
      <div className="text-center w-full max-w-3xl">
        <motion.h2 
          className="text-5xl font-display font-bold text-white mb-6"
          initial={{ opacity: 0, y: -20 }}
          animate={phase >= 1 ? { opacity: 1, y: 0 } : { opacity: 0, y: -20 }}
        >
          Log transactions naturally.
        </motion.h2>
        
        <motion.div 
          className="mt-12 p-6 bg-surface border border-border rounded-xl shadow-2xl mx-auto"
          initial={{ y: 50, opacity: 0 }}
          animate={phase >= 2 ? { y: 0, opacity: 1 } : { y: 50, opacity: 0 }}
        >
          <div className="text-left mb-4">
            <span className="text-brand font-medium flex items-center gap-2">
              <Activity size={18} /> NLP Transaction Entry
            </span>
          </div>
          
          <div className="relative overflow-hidden rounded-lg bg-background p-4 border border-border">
            <motion.div className="text-white text-xl font-mono"
              initial={{ width: '0%' }}
              animate={phase >= 3 ? { width: '100%' } : { width: '0%' }}
              style={{ whiteSpace: 'nowrap', overflow: 'hidden' }}
              transition={{ duration: 2, ease: 'linear' }}
            >
              "Spent 5k on fuel for generator"
            </motion.div>
            {phase >= 3 && (
              <motion.span 
                className="inline-block w-2 h-6 bg-brand align-middle ml-1"
                animate={{ opacity: [1, 0] }}
                transition={{ repeat: Infinity, duration: 0.8 }}
              />
            )}
          </div>

          <motion.div 
            className="mt-6 flex justify-between bg-brand/10 p-4 rounded-lg border border-brand/30"
            initial={{ opacity: 0, y: 10 }}
            animate={phase >= 3 ? { opacity: 1, y: 0 } : { opacity: 0, y: 10 }}
            transition={{ delay: 2.5 }}
          >
            <div>
              <div className="text-sm text-muted">Category</div>
              <div className="text-white font-medium">Utilities / Fuel</div>
            </div>
            <div className="text-right">
              <div className="text-sm text-muted">Amount</div>
              <div className="text-red-400 font-bold">-₦5,000</div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </motion.div>
  );
}
