import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';

export function Scene1() {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const t1 = setTimeout(() => setPhase(1), 500);
    const t2 = setTimeout(() => setPhase(2), 1500);
    const t3 = setTimeout(() => setPhase(3), 4500);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, []);

  return (
    <motion.div 
      className="absolute inset-0 flex items-center justify-center z-10"
      initial={{ opacity: 0, scale: 1.1 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9, filter: 'blur(10px)' }}
      transition={{ duration: 1 }}
    >
      <div className="text-center">
        <motion.div 
          className="flex items-center justify-center space-x-4 mb-6"
          initial={{ y: 50, opacity: 0 }}
          animate={phase >= 1 ? { y: 0, opacity: 1 } : { y: 50, opacity: 0 }}
          transition={{ type: 'spring', stiffness: 300, damping: 25 }}
        >
          <div className="w-16 h-16 bg-brand rounded-xl flex items-center justify-center shadow-[0_0_40px_rgba(232,101,10,0.5)]">
            <span className="text-3xl font-bold text-white">H</span>
          </div>
          <h1 className="text-6xl font-display font-bold tracking-tight text-white">
            HustleOS <span className="text-brand">AI</span>
          </h1>
        </motion.div>
        
        <motion.p 
          className="text-2xl text-muted font-light tracking-wide"
          initial={{ opacity: 0, y: 20 }}
          animate={phase >= 2 ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.8 }}
        >
          Built for African Entrepreneurs
        </motion.p>
      </div>
    </motion.div>
  );
}
