import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';
import { Users, MessageCircle } from 'lucide-react';

export function Scene5() {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const t1 = setTimeout(() => setPhase(1), 300);
    const t2 = setTimeout(() => setPhase(2), 1500);
    const t3 = setTimeout(() => setPhase(3), 8500);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, []);

  return (
    <motion.div 
      className="absolute inset-0 flex flex-row-reverse items-center p-20 z-10"
      initial={{ opacity: 0, rotateY: -20 }}
      animate={{ opacity: 1, rotateY: 0 }}
      exit={{ opacity: 0, scale: 1.1 }}
      transition={{ duration: 0.8, ease: 'easeOut' }}
    >
      <div className="w-1/2 pl-12 z-20">
        <motion.h2 
          className="text-5xl font-display font-bold text-white mb-6 leading-tight"
          initial={{ opacity: 0, x: 20 }}
          animate={phase >= 1 ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
        >
          Know your customers.
        </motion.h2>
        <motion.p 
          className="text-xl text-muted"
          initial={{ opacity: 0 }}
          animate={phase >= 1 ? { opacity: 1 } : { opacity: 0 }}
          transition={{ delay: 0.2 }}
        >
          Simple CRM with WhatsApp integration built for the African market.
        </motion.p>
      </div>

      <div className="w-1/2 relative h-full flex items-center justify-center">
        <motion.div 
          className="w-full max-w-md bg-surface border border-border rounded-xl p-8 shadow-2xl relative"
          initial={{ scale: 0.9, opacity: 0 }}
          animate={phase >= 2 ? { scale: 1, opacity: 1 } : { scale: 0.9, opacity: 0 }}
        >
          <div className="flex items-center gap-4 mb-6">
            <div className="w-16 h-16 bg-brand/20 rounded-full flex items-center justify-center text-brand font-bold text-xl">
              EA
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">Emmanuel Adebayo</h3>
              <p className="text-muted">Total Spend: ₦450,000</p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="p-3 bg-background rounded border border-border">
              <p className="text-sm text-muted mb-1">Last Purchase</p>
              <p className="text-white font-medium">2 days ago - Wholesale Coffee (10kg)</p>
            </div>
            
            <div className="w-full py-3 bg-[#25D366]/10 border border-[#25D366] text-[#25D366] rounded-lg text-center font-medium flex items-center justify-center gap-2">
              <MessageCircle size={18} />
              Message on WhatsApp
            </div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
