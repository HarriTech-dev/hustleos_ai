import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';
import { FileText, CheckCircle2 } from 'lucide-react';

export function Scene3() {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const t1 = setTimeout(() => setPhase(1), 300);
    const t2 = setTimeout(() => setPhase(2), 1500);
    const t3 = setTimeout(() => setPhase(3), 3000);
    const t4 = setTimeout(() => setPhase(4), 8500);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); clearTimeout(t4); };
  }, []);

  return (
    <motion.div 
      className="absolute inset-0 flex items-center p-20 z-10"
      initial={{ opacity: 0, y: 100 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 1.1 }}
      transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
    >
      <div className="w-1/2 pr-12 z-20">
        <motion.h2 
          className="text-5xl font-display font-bold text-white mb-6 leading-tight"
          initial={{ opacity: 0, x: -20 }}
          animate={phase >= 1 ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
        >
          Invoices that get paid.
        </motion.p>
        <motion.p 
          className="text-xl text-muted"
          initial={{ opacity: 0 }}
          animate={phase >= 1 ? { opacity: 1 } : { opacity: 0 }}
          transition={{ delay: 0.2 }}
        >
          Create professional invoices in seconds. Auto-deduct inventory.
        </motion.p>
      </div>

      <div className="w-1/2 relative h-full flex items-center justify-center perspective-[1000px]">
        <motion.div 
          className="w-full max-w-md bg-surface border border-border rounded-xl p-8 shadow-2xl relative"
          initial={{ y: 50, opacity: 0, rotateX: 10 }}
          animate={phase >= 2 ? { y: 0, opacity: 1, rotateX: 0 } : { y: 50, opacity: 0, rotateX: 10 }}
        >
          <div className="flex justify-between items-start mb-8">
            <div className="w-12 h-12 bg-brand/20 rounded-lg flex items-center justify-center">
              <FileText className="text-brand" />
            </div>
            <div className="text-right">
              <div className="text-white font-medium">INV-2023-084</div>
              <div className="text-muted text-sm">Due: Today</div>
            </div>
          </div>

          <div className="space-y-4 mb-8">
            <div className="flex justify-between text-white">
              <span>Premium Coffee Beans (5kg)</span>
              <span>₦45,000</span>
            </div>
            <div className="flex justify-between text-white">
              <span>Espresso Machine Service</span>
              <span>₦25,000</span>
            </div>
            <div className="h-px bg-border my-4" />
            <div className="flex justify-between text-white font-bold text-xl">
              <span>Total</span>
              <span>₦70,000</span>
            </div>
          </div>

          <motion.div 
            className="w-full py-3 bg-brand/10 border border-brand text-brand rounded-lg text-center font-medium flex items-center justify-center gap-2"
            initial={{ scale: 0.9, opacity: 0 }}
            animate={phase >= 3 ? { scale: 1, opacity: 1, backgroundColor: '#E8650A', color: 'white' } : { scale: 0.9, opacity: 0 }}
          >
            {phase >= 3 ? <CheckCircle2 size={18} /> : null}
            {phase >= 3 ? 'Marked as Paid' : 'Send Invoice'}
          </motion.div>
        </motion.div>
      </div>
    </motion.div>
  );
}
