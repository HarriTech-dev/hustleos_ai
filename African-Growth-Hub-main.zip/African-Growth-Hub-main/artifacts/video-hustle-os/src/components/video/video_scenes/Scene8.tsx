import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';

export function Scene8() {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const t1 = setTimeout(() => setPhase(1), 1000);
    const t2 = setTimeout(() => setPhase(2), 3000);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, []);

  return (
    <motion.div 
      className="absolute inset-0 flex flex-col items-center justify-center z-10"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 1.5 }}
    >
      <motion.h2 
        className="text-6xl font-display font-bold text-white text-center mb-8"
        initial={{ y: 30, opacity: 0 }}
        animate={phase >= 1 ? { y: 0, opacity: 1 } : { y: 30, opacity: 0 }}
        transition={{ duration: 1 }}
      >
        Run Your Business.<br />
        <span className="text-brand">Own Your Future.</span>
      </motion.h2>

      <motion.div 
        className="flex items-center gap-3"
        initial={{ scale: 0.9, opacity: 0 }}
        animate={phase >= 2 ? { scale: 1, opacity: 1 } : { scale: 0.9, opacity: 0 }}
        transition={{ type: 'spring' }}
      >
        <div className="w-12 h-12 bg-brand rounded-lg flex items-center justify-center shadow-[0_0_30px_rgba(232,101,10,0.5)]">
          <span className="text-2xl font-bold text-white">H</span>
        </div>
        <span className="text-3xl font-display font-bold text-white tracking-tight">HustleOS</span>
      </motion.div>
    </motion.div>
  );
}
