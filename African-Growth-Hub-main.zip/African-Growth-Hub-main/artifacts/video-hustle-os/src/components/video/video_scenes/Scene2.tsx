import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';
import { BarChart3, TrendingUp, Users, Package } from 'lucide-react';

export function Scene2() {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const t1 = setTimeout(() => setPhase(1), 300);
    const t2 = setTimeout(() => setPhase(2), 1000);
    const t3 = setTimeout(() => setPhase(3), 2000);
    const t4 = setTimeout(() => setPhase(4), 8500);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); clearTimeout(t4); };
  }, []);

  return (
    <motion.div 
      className="absolute inset-0 flex items-center p-20 z-10"
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -100 }}
      transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
    >
      <div className="w-1/3 pr-12">
        <motion.h2 
          className="text-5xl font-display font-bold text-white mb-6 leading-tight"
          initial={{ opacity: 0, y: 20 }}
          animate={phase >= 1 ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
        >
          Everything in one place.
        </motion.h2>
        <motion.p 
          className="text-xl text-muted"
          initial={{ opacity: 0 }}
          animate={phase >= 1 ? { opacity: 1 } : { opacity: 0 }}
          transition={{ delay: 0.2 }}
        >
          Real-time insights across your entire business.
        </motion.p>
      </div>

      <div className="w-2/3 relative h-full flex items-center justify-center perspective-[1000px]">
        <motion.div 
          className="w-full max-w-2xl bg-surface border border-border rounded-2xl p-8 shadow-2xl relative"
          initial={{ rotateY: 20, opacity: 0, z: -100 }}
          animate={phase >= 2 ? { rotateY: -5, opacity: 1, z: 0 } : { rotateY: 20, opacity: 0, z: -100 }}
          transition={{ type: 'spring', stiffness: 100, damping: 20 }}
        >
          <div className="flex justify-between items-center mb-8 border-b border-border pb-4">
            <h3 className="text-xl font-semibold text-white">Overview</h3>
            <span className="text-brand font-medium">This Week</span>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <motion.div 
              className="bg-background rounded-xl p-6 border border-border"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={phase >= 3 ? { scale: 1, opacity: 1 } : { scale: 0.8, opacity: 0 }}
              transition={{ delay: 0 }}
            >
              <div className="flex items-center space-x-3 mb-4 text-muted">
                <TrendingUp size={20} className="text-brand" />
                <span>Revenue</span>
              </div>
              <div className="text-3xl font-bold text-white">₦2.4M</div>
              <div className="text-green-500 text-sm mt-2">+12% vs last week</div>
            </motion.div>

            <motion.div 
              className="bg-background rounded-xl p-6 border border-border"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={phase >= 3 ? { scale: 1, opacity: 1 } : { scale: 0.8, opacity: 0 }}
              transition={{ delay: 0.1 }}
            >
              <div className="flex items-center space-x-3 mb-4 text-muted">
                <Package size={20} className="text-brand" />
                <span>Active Orders</span>
              </div>
              <div className="text-3xl font-bold text-white">48</div>
              <div className="text-orange-500 text-sm mt-2">12 pending fulfillment</div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
