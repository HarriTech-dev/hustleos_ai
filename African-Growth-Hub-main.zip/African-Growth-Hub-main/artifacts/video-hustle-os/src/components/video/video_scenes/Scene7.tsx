import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';
import { BrainCircuit, Sparkles } from 'lucide-react';

export function Scene7() {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const t1 = setTimeout(() => setPhase(1), 500);
    const t2 = setTimeout(() => setPhase(2), 2000);
    const t3 = setTimeout(() => setPhase(3), 4000);
    const t4 = setTimeout(() => setPhase(4), 10500);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); clearTimeout(t4); };
  }, []);

  return (
    <motion.div 
      className="absolute inset-0 flex items-center p-20 z-10"
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 1, ease: 'easeOut' }}
    >
      <div className="w-1/2 pr-12 z-20">
        <motion.div 
          className="w-16 h-16 bg-gradient-to-br from-brand to-orange-400 rounded-2xl flex items-center justify-center mb-6 shadow-[0_0_30px_rgba(232,101,10,0.6)]"
          initial={{ scale: 0, rotate: -45 }}
          animate={phase >= 1 ? { scale: 1, rotate: 0 } : { scale: 0, rotate: -45 }}
          transition={{ type: 'spring' }}
        >
          <BrainCircuit className="text-white" size={32} />
        </motion.div>

        <motion.h2 
          className="text-5xl font-display font-bold text-white mb-6 leading-tight"
          initial={{ opacity: 0, y: 20 }}
          animate={phase >= 1 ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
        >
          Your AI Business Advisor.
        </motion.h2>
        <motion.p 
          className="text-xl text-muted"
          initial={{ opacity: 0 }}
          animate={phase >= 1 ? { opacity: 1 } : { opacity: 0 }}
          transition={{ delay: 0.2 }}
        >
          Powered by GPT-4o-mini. Trained for the African market context.
        </motion.p>
      </div>

      <div className="w-1/2 relative h-full flex items-center justify-center">
        <motion.div 
          className="w-full max-w-md bg-surface border border-border rounded-xl p-6 shadow-2xl relative"
          initial={{ y: 50, opacity: 0 }}
          animate={phase >= 2 ? { y: 0, opacity: 1 } : { y: 50, opacity: 0 }}
        >
          <div className="bg-background rounded-lg p-4 mb-4 border border-border text-white text-sm">
            How can I increase my sales during the rainy season in Lagos?
          </div>

          <motion.div 
            className="bg-brand/10 border border-brand/20 rounded-lg p-4"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={phase >= 3 ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
          >
            <div className="flex items-center gap-2 mb-2 text-brand font-medium">
              <Sparkles size={16} /> AI Advisor
            </div>
            <p className="text-white text-sm leading-relaxed">
              Based on your inventory, you have excess Robusta beans. During the rainy season, hot beverage demand spikes. I recommend running a "Monsoon Bundle" promo on WhatsApp targeting your top 20 customers in Victoria Island...
            </p>
          </motion.div>
        </motion.div>
      </div>
    </motion.div>
  );
}
