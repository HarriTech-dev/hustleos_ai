import { motion, AnimatePresence } from 'framer-motion';
import { useVideoPlayer } from '@/lib/video/hooks';
import { Scene1 } from './video_scenes/Scene1';
import { Scene2 } from './video_scenes/Scene2';
import { Scene3 } from './video_scenes/Scene3';
import { Scene4 } from './video_scenes/Scene4';
import { Scene5 } from './video_scenes/Scene5';
import { Scene6 } from './video_scenes/Scene6';
import { Scene7 } from './video_scenes/Scene7';
import { Scene8 } from './video_scenes/Scene8';

const SCENE_DURATIONS = {
  hero: 6000,
  dashboard: 10000,
  invoices: 10000,
  inventory: 10000,
  customers: 10000,
  transactions: 10000,
  ai: 12000,
  closing: 8000
};

export default function VideoTemplate() {
  const { currentScene } = useVideoPlayer({ durations: SCENE_DURATIONS });

  return (
    <div className="relative w-full h-screen bg-background overflow-hidden font-body">
      {/* Persistent Background */}
      <div className="absolute inset-0 z-0">
        <motion.div 
          className="absolute w-[80vw] h-[80vw] rounded-full blur-[120px] opacity-10"
          style={{ background: 'radial-gradient(circle, #E8650A, transparent)' }}
          animate={{
            x: ['-20%', '10%', '-10%'],
            y: ['-10%', '20%', '-10%'],
            scale: [1, 1.2, 0.9]
          }}
          transition={{ duration: 20, repeat: Infinity, ease: 'easeInOut' }}
        />
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0IiBoZWlnaHQ9IjQiPjxyZWN0IHdpZHRoPSI0IiBoZWlnaHQ9IjQiIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSIvPjwvc3ZnPg==')] opacity-20"></div>
      </div>

      {/* Persistent UI Accents */}
      <motion.div 
        className="absolute top-0 bottom-0 left-12 w-[1px] bg-gradient-to-b from-transparent via-brand/30 to-transparent z-0"
        animate={{
          x: currentScene === 0 ? -100 : 0,
          opacity: currentScene === 0 ? 0 : 1
        }}
        transition={{ duration: 1 }}
      />
      <motion.div 
        className="absolute top-12 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-brand/30 to-transparent z-0"
        animate={{
          y: currentScene === 0 ? -100 : 0,
          opacity: currentScene === 0 ? 0 : 1
        }}
        transition={{ duration: 1 }}
      />

      <AnimatePresence mode="popLayout">
        {currentScene === 0 && <Scene1 key="s1" />}
        {currentScene === 1 && <Scene2 key="s2" />}
        {currentScene === 2 && <Scene3 key="s3" />}
        {currentScene === 3 && <Scene4 key="s4" />}
        {currentScene === 4 && <Scene5 key="s5" />}
        {currentScene === 5 && <Scene6 key="s6" />}
        {currentScene === 6 && <Scene7 key="s7" />}
        {currentScene === 7 && <Scene8 key="s8" />}
      </AnimatePresence>
    </div>
  );
}
