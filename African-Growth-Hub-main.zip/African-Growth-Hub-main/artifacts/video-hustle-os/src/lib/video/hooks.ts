import { useState, useEffect, useRef } from 'react';

declare global {
  interface Window {
    startRecording?: () => void;
    stopRecording?: () => void;
  }
}

export function useVideoPlayer({ durations }: { durations: Record<string, number> }) {
  const [currentScene, setCurrentScene] = useState(0);
  const sceneKeys = Object.keys(durations);
  const hasFinishedFirstPass = useRef(false);

  useEffect(() => {
    // Start recording on mount
    if (window.startRecording) {
      window.startRecording();
    }
  }, []);

  useEffect(() => {
    const currentKey = sceneKeys[currentScene];
    const duration = durations[currentKey];

    const timer = setTimeout(() => {
      if (currentScene === sceneKeys.length - 1) {
        // First full pass complete
        if (!hasFinishedFirstPass.current && window.stopRecording) {
          window.stopRecording();
          hasFinishedFirstPass.current = true;
        }
        // Loop
        setCurrentScene(0);
      } else {
        setCurrentScene(prev => prev + 1);
      }
    }, duration);

    return () => clearTimeout(timer);
  }, [currentScene, durations, sceneKeys]);

  return { currentScene };
}
