import { Link, useLocation } from "wouter";
import {
  LayoutDashboard,
  Package2,
  FileText,
  Users,
  Bot,
  Settings,
  LogOut,
  Sun,
  Moon,
  ArrowLeftRight,
  UserX,
  BarChart3,
  TrendingUp,
  CreditCard,
  Store,
  MessageSquare,
  Shield,
  UsersRound,
  Bell,
  Receipt,
  FileSpreadsheet,
  Megaphone,
  GraduationCap,
  Lock,
} from "lucide-react";
import { useAuth } from "../../contexts/AuthContext";
import { useTheme } from "../theme-provider";
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar";
import { Button } from "../ui/button";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "../../hooks/use-toast";

interface NavItem {
  href: string;
  label: string;
  icon: React.ElementType;
  roles?: string[];
  feature?: string;
}

const navItems: NavItem[] = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/transactions", label: "Transactions", icon: ArrowLeftRight },
  { href: "/customers", label: "Customers", icon: Users },
  { href: "/debtors", label: "Debtors", icon: UserX },
  { href: "/inventory", label: "Inventory", icon: Package2 },
  { href: "/invoices", label: "Invoices", icon: FileText },
  { href: "/quotes", label: "Quotations", icon: FileSpreadsheet },
  { href: "/purchase-orders", label: "Purchase Orders", icon: Receipt },
  { href: "/reports", label: "Reports", icon: BarChart3 },
  { href: "/crm", label: "WhatsApp CRM", icon: MessageSquare, feature: "crm" },
  { href: "/ai", label: "AI Advisor", icon: Bot },
  { href: "/ai/marketing", label: "AI Marketing", icon: Megaphone, feature: "ai_marketing" },
  { href: "/training-videos", label: "Training Videos", icon: GraduationCap },
  { href: "/forecasting", label: "Forecasting", icon: TrendingUp, feature: "forecasting" },
  { href: "/marketplace", label: "Marketplace", icon: Store, feature: "marketplace" },
  { href: "/team", label: "Team", icon: UsersRound, roles: ["owner", "admin"], feature: "team_full" },
  { href: "/billing", label: "Billing", icon: CreditCard, roles: ["owner", "admin"] },
  { href: "/notifications", label: "Notifications", icon: Bell, feature: "notifications" },
  { href: "/audit-logs", label: "Audit Logs", icon: Shield, roles: ["owner", "admin"], feature: "audit_logs" },
  { href: "/settings", label: "Settings", icon: Settings },
];

function getAllowedRoles(role: string | null | undefined): string[] {
  if (!role || role === "owner") return ["owner", "admin", "manager", "staff"];
  if (role === "admin") return ["admin", "manager", "staff"];
  if (role === "manager") return ["manager", "staff"];
  return ["staff"];
}

interface SidebarContentProps {
  onNavigate?: () => void;
}

export function SidebarContent({ onNavigate }: SidebarContentProps) {
  const [location] = useLocation();
  const { user, profile, signOut } = useAuth();
  const { theme, setTheme } = useTheme();
  const { toast } = useToast();
  const userRole = profile?.role || user?.user_metadata?.role || "owner";
  const allowedRoles = getAllowedRoles(userRole);

  const { data: planData } = useQuery({
    queryKey: ["subscription-plan"],
    queryFn: async () => {
      const token = await (async () => {
        const { data } = await import("../../lib/supabase").then((m) => m.supabase.auth.getSession());
        return data.session?.access_token ?? "";
      })();
      const res = await fetch("/api/subscriptions/current", { headers: { Authorization: `Bearer ${token}` } });
      if (!res.ok) return null;
      return res.json();
    },
    staleTime: 5 * 60 * 1000,
  });

  const activePlanId = planData?.planId || "plan_free";

  const PLAN_FEATURES: Record<string, string[]> = {
    plan_free: ["dashboard", "transactions", "customers", "debtors", "inventory", "invoices", "reports", "ai_advisor", "settings", "team_read"],
    plan_pro: ["dashboard", "transactions", "customers", "debtors", "inventory", "invoices", "reports", "ai_advisor", "forecasting", "crm", "ai_marketing", "team_full", "settings"],
    plan_premium: ["dashboard", "transactions", "customers", "debtors", "inventory", "invoices", "reports", "ai_advisor", "forecasting", "crm", "ai_marketing", "marketplace", "team_full", "notifications", "audit_logs", "settings"],
    plan_enterprise: ["*"],
  };

  const features = PLAN_FEATURES[activePlanId] || PLAN_FEATURES.plan_free;
  const hasFeature = (f?: string) => !f || features.includes("*") || features.includes(f);

  const filteredNavItems = navItems.filter((item) => {
    if (!item.roles) return true;
    return item.roles.some((role) => allowedRoles.includes(role));
  });

  return (
    <div className="flex h-full flex-col bg-sidebar">
      <div className="flex h-16 shrink-0 items-center px-6 border-b">
        <div className="flex items-center gap-2 font-bold text-xl tracking-tight text-primary">
          <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground text-sm font-bold">
            H
          </div>
          HustleOS
        </div>
      </div>

      <div className="flex-1 overflow-y-auto py-4">
        <nav className="grid gap-0.5 px-3 text-sm font-medium">
          {filteredNavItems.map((item) => {
            const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
            const locked = !hasFeature(item.feature);
            return (
              <Link
                key={item.href}
                href={locked ? "/billing" : item.href}
                onClick={(e) => {
                  if (locked) {
                    e.preventDefault();
                    toast({ title: "Upgrade required", description: `${item.label} is not available on your plan.`, variant: "destructive" });
                  } else {
                    onNavigate?.();
                  }
                }}
                className={`flex items-center gap-3 rounded-md px-3 py-2 transition-colors ${
                  isActive && !locked
                    ? "bg-primary/10 text-primary font-semibold"
                    : locked
                    ? "text-muted-foreground opacity-60 cursor-not-allowed"
                    : "text-sidebar-foreground hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground"
                }`}
              >
                <item.icon className="h-4 w-4 shrink-0" />
                {item.label}
                {locked && <Lock className="h-3 w-3 ml-auto text-muted-foreground" />}
              </Link>
            );
          })}
        </nav>
      </div>

      <div className="mt-auto border-t p-4 space-y-3">
        <div className="flex items-center gap-3 px-1">
          <Avatar className="h-9 w-9 shrink-0">
            <AvatarImage src={profile?.avatarUrl || user?.user_metadata?.avatar_url} />
            <AvatarFallback className="bg-primary/10 text-primary font-semibold">
              {(profile?.name || user?.email)?.charAt(0).toUpperCase() || "U"}
            </AvatarFallback>
          </Avatar>
          <div className="flex flex-col overflow-hidden flex-1">
            <span className="truncate text-sm font-medium leading-tight">
              {profile?.name || user?.user_metadata?.name || "User"}
            </span>
            <span className="truncate text-xs text-muted-foreground leading-tight">
              {user?.email}
            </span>
          </div>
          <span className="text-[10px] uppercase bg-muted px-1.5 py-0.5 rounded text-muted-foreground font-medium">
            {userRole}
          </span>
        </div>

        <div className="flex items-center justify-between px-1">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="h-8 w-8"
            title="Toggle theme"
          >
            {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={signOut}
            className="text-muted-foreground hover:text-destructive h-8 gap-1.5"
          >
            <LogOut className="h-3.5 w-3.5" />
            Logout
          </Button>
        </div>
      </div>
    </div>
  );
}

export function Sidebar() {
  return (
    <aside className="fixed inset-y-0 left-0 z-50 hidden w-64 border-r md:flex flex-col">
      <SidebarContent />
    </aside>
  );
}
