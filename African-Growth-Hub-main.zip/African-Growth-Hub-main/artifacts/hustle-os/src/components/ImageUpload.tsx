import { useState, useRef } from "react";
import { useAuth } from "../contexts/AuthContext";
import { useToast } from "../hooks/use-toast";
import { ImagePlus, X, Loader2, Upload } from "lucide-react";
import { cn } from "../lib/utils";

interface ImageUploadProps {
  value?: string | null;
  onChange: (url: string | null) => void;
  folder?: string;
  accept?: string;
  maxSizeMB?: number;
  label?: string;
  description?: string;
  className?: string;
  aspectRatio?: "square" | "video" | "wide";
  shape?: "rounded" | "circle" | "square";
}

export default function ImageUpload({
  value,
  onChange,
  folder = "uploads",
  accept = "image/*",
  maxSizeMB = 5,
  label,
  description,
  className,
  aspectRatio = "square",
  shape = "rounded",
}: ImageUploadProps) {
  const { session } = useAuth();
  const { toast } = useToast();
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);

  const authHeaders = {
    Authorization: `Bearer ${session?.access_token}`,
    "Content-Type": "application/json",
  };

  const maxBytes = maxSizeMB * 1024 * 1024;

  const handleFile = async (file: File) => {
    if (file.size > maxBytes) {
      toast({
        variant: "destructive",
        title: "File too large",
        description: `Maximum ${maxSizeMB} MB allowed.`,
      });
      return;
    }

    setUploading(true);
    setProgress(10);

    try {
      const data = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });

      setProgress(50);

      const res = await fetch("/api/upload", {
        method: "POST",
        headers: authHeaders,
        body: JSON.stringify({ data, folder }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Upload failed");
      }

      const { url } = (await res.json()) as { url: string };
      setProgress(100);
      onChange(url);
      toast({ title: "Upload complete", description: "Your image is ready." });
    } catch (err: any) {
      toast({
        variant: "destructive",
        title: "Upload failed",
        description: err.message || "Please try again.",
      });
    } finally {
      setTimeout(() => {
        setUploading(false);
        setProgress(0);
      }, 500);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    handleFile(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (!file) return;
    handleFile(file);
  };

  const handleRemove = () => {
    onChange(null);
    if (fileRef.current) fileRef.current.value = "";
  };

  const aspectClasses = {
    square: "aspect-square",
    video: "aspect-video",
    wide: "aspect-[2/1]",
  };

  const shapeClasses = {
    rounded: "rounded-lg",
    circle: "rounded-full",
    square: "rounded-none",
  };

  return (
    <div className={className}>
      {label && <label className="text-sm font-medium mb-2 block">{label}</label>}
      <input
        ref={fileRef}
        type="file"
        accept={accept}
        className="hidden"
        onChange={handleFileChange}
      />

      {value ? (
        <div className="relative group">
          <div className={cn(
            "overflow-hidden border bg-muted",
            aspectClasses[aspectRatio],
            shapeClasses[shape]
          )}>
            <img
              src={value}
              alt="Preview"
              className="w-full h-full object-cover"
              onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
            />
          </div>
          <div className="absolute inset-0 flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity bg-black/40 rounded-lg">
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="bg-white text-foreground rounded-full p-2 hover:bg-white/90 shadow-lg"
              title="Replace"
            >
              <Upload className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={handleRemove}
              className="bg-white text-destructive rounded-full p-2 hover:bg-white/90 shadow-lg"
              title="Remove"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          onDragOver={(e) => e.preventDefault()}
          onDrop={handleDrop}
          disabled={uploading}
          className={cn(
            "w-full flex flex-col items-center justify-center gap-2 border-2 border-dashed border-border rounded-lg text-muted-foreground hover:border-primary/50 hover:text-primary transition-colors disabled:opacity-50 disabled:cursor-not-allowed",
            aspectClasses[aspectRatio]
          )}
        >
          {uploading ? (
            <>
              <Loader2 className="h-8 w-8 animate-spin" />
              <span className="text-sm font-medium">Uploading... {progress}%</span>
            </>
          ) : (
            <>
              <ImagePlus className="h-8 w-8" />
              <span className="text-sm font-medium">Click or drag to upload</span>
              {description && <span className="text-xs">{description}</span>}
            </>
          )}
        </button>
      )}
    </div>
  );
}
