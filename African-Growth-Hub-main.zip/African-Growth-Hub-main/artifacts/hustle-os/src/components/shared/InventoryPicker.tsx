import { useState, useEffect, useRef } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Search, Package, ChevronDown } from "lucide-react";
import { cn } from "../../lib/utils";

interface InventoryItem {
  id: string;
  name: string;
  sku: string;
  quantity: number;
  price: number;
  currency: string;
  category: string;
  unit: string;
}

interface Props {
  onSelect: (item: { name: string; unitPrice: number; stock: number }) => void;
  currency?: string;
  disabled?: boolean;
}

export function InventoryPicker({ onSelect, currency, disabled }: Props) {
  const { session } = useAuth();
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [loading, setLoading] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    if (!open || !session) return;
    setLoading(true);
    const params = search ? `?search=${encodeURIComponent(search)}` : "";
    fetch(`/api/inventory${params}`, {
      headers: { Authorization: `Bearer ${session.access_token}` },
    })
      .then((r) => r.json())
      .then((data) => {
        setItems(Array.isArray(data) ? data : []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [open, search, session]);

  const handleSelect = (item: InventoryItem) => {
    onSelect({ name: item.name, unitPrice: item.price, stock: item.quantity });
    setOpen(false);
    setSearch("");
  };

  const stockBadge = (qty: number) => {
    if (qty === 0) return <Badge variant="destructive" className="text-xs">Out of stock</Badge>;
    if (qty <= 5) return <Badge className="bg-amber-100 text-amber-800 text-xs">{qty} left</Badge>;
    return <Badge variant="secondary" className="text-xs">{qty} in stock</Badge>;
  };

  return (
    <div className="relative" ref={ref}>
      <Button
        type="button"
        variant="outline"
        size="sm"
        disabled={disabled}
        onClick={() => setOpen((v) => !v)}
        className="gap-1.5 h-8 text-xs text-muted-foreground"
      >
        <Package className="h-3 w-3" />
        Pick from inventory
        <ChevronDown className="h-3 w-3" />
      </Button>

      {open && (
        <div className="absolute top-full left-0 mt-1 z-50 w-80 rounded-lg border bg-popover shadow-lg">
          <div className="p-2 border-b">
            <div className="flex items-center gap-2 px-2 py-1.5 rounded-md border bg-background">
              <Search className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search inventory..."
                className="h-auto border-0 p-0 text-sm focus-visible:ring-0 shadow-none"
                autoFocus
              />
            </div>
          </div>
          <div className="max-h-64 overflow-y-auto p-1">
            {loading ? (
              <div className="py-6 text-center text-xs text-muted-foreground">Loading...</div>
            ) : items.length === 0 ? (
              <div className="py-6 text-center text-xs text-muted-foreground">
                {search ? "No matching items" : "No inventory items yet"}
              </div>
            ) : (
              items.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleSelect(item)}
                  disabled={item.quantity === 0}
                  className={cn(
                    "w-full flex items-start gap-3 px-3 py-2.5 rounded-md text-left hover:bg-accent transition-colors",
                    item.quantity === 0 && "opacity-50 cursor-not-allowed"
                  )}
                >
                  <Package className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm font-medium truncate">{item.name}</span>
                      {stockBadge(item.quantity)}
                    </div>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-xs text-muted-foreground">{currency ?? item.currency} {item.price.toLocaleString()}</span>
                      <span className="text-xs text-muted-foreground">·</span>
                      <span className="text-xs text-muted-foreground">{item.category}</span>
                    </div>
                  </div>
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
