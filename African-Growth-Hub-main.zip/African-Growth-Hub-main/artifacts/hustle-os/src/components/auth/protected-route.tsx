import { Redirect, Route } from "wouter";
import { useAuth } from "../../contexts/AuthContext";
import { MainLayout } from "../layout/main-layout";
import { Spinner } from "../ui/spinner";

interface ProtectedRouteProps {
  component: any;
  path: string;
  allowedRoles?: string[];
}

export function ProtectedRoute({ component: Component, path, allowedRoles }: ProtectedRouteProps) {
  const { user, profile, loading } = useAuth();
  const userRole = profile?.role || user?.user_metadata?.role || "owner";

  return (
    <Route path={path}>
      {(params) => {
        if (loading) {
          return (
            <div className="flex min-h-screen items-center justify-center">
              <Spinner className="h-8 w-8 text-primary" />
            </div>
          );
        }

        if (!user) {
          return <Redirect to="/auth/login" />;
        }

        if (allowedRoles && !allowedRoles.includes(userRole)) {
          return (
            <MainLayout>
              <div className="flex flex-col items-center justify-center py-20 text-center">
                <h2 className="text-xl font-semibold mb-2">Access Restricted</h2>
                <p className="text-muted-foreground">You need {allowedRoles.join(" or ")} permissions to access this page.</p>
              </div>
            </MainLayout>
          );
        }

        return (
          <MainLayout>
            <Component params={params} />
          </MainLayout>
        );
      }}
    </Route>
  );
}
