import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "../../contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Badge } from "../../components/ui/badge";
import { Skeleton } from "../../components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../../components/ui/table";
import { Avatar, AvatarFallback } from "../../components/ui/avatar";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Textarea } from "../../components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import { formatCurrency } from "../../lib/format";
import { AlertTriangle, Clock, Users, TrendingDown, Mail, MessageCircle, Plus, X, Loader2, HandCoins } from "lucide-react";
import { Link } from "wouter";
import { cn } from "../../lib/utils";
import { useState } from "react";
import { CURRENCY_LABELS, UNIQUE_CURRENCIES } from "../../lib/currencies";
import { useToast } from "../../hooks/use-toast";

interface Debtor {
  customerId: string;
  customerName: string;
  customerEmail: string | null;
  customerPhone: string | null;
  totalOwed: number;
  overdueCount: number;
  oldestDueDate: string;
  currency: string;
  invoices: Array<{ id: string; invoiceNumber: string; total: number; dueDate: string; status: string }>;
}

interface ManualDebt {
  id: string;
  debtorName: string;
  debtorPhone: string | null;
  debtorEmail: string | null;
  amount: number;
  amountPaid: number;
  amountDue: number;
  reason: string;
  notes: string | null;
  status: string;
  dueDate: string | null;
  currency: string;
  createdAt: string;
}

async function fetchDebtors(accessToken: string): Promise<Debtor[]> {
  const res = await fetch("/api/debtors", { headers: { Authorization: `Bearer ${accessToken}` } });
  if (!res.ok) throw new Error("Failed to fetch debtors");
  return res.json();
}

async function fetchManualDebts(accessToken: string): Promise<ManualDebt[]> {
  const res = await fetch("/api/debtors/manual", { headers: { Authorization: `Bearer ${accessToken}` } });
  if (!res.ok) throw new Error("Failed to fetch manual debts");
  return res.json();
}

function daysSince(dateStr: string): number {
  const d = new Date(dateStr);
  const now = new Date();
  return Math.floor((now.getTime() - d.getTime()) / (1000 * 60 * 60 * 24));
}

function urgencyBadge(days: number) {
  if (days > 60) return <Badge variant="destructive">Critical ({days}d overdue)</Badge>;
  if (days > 30) return <Badge className="bg-amber-500 hover:bg-amber-600 text-white">High ({days}d overdue)</Badge>;
  if (days > 0) return <Badge className="bg-yellow-500 hover:bg-yellow-600 text-white">Medium ({days}d overdue)</Badge>;
  return <Badge variant="outline">Due soon</Badge>;
}

function buildWhatsAppMessage(name: string, amount: string, invoices: Debtor["invoices"], currency = "NGN") {
  const invoiceList = invoices.slice(0, 3).map((i) => `• ${i.invoiceNumber} — ${formatCurrency(i.total, currency)}`).join("\n");
  const msg = `Hi ${name},\n\nThis is a friendly reminder that you have outstanding invoices totalling *${amount}*:\n\n${invoiceList}${invoices.length > 3 ? `\n• ...and ${invoices.length - 3} more` : ""}\n\nKindly settle at your earliest convenience. Thank you! 🙏`;
  return encodeURIComponent(msg);
}

const STATUS_BADGE: Record<string, string> = {
  outstanding: "bg-red-100 text-red-800",
  partial: "bg-amber-100 text-amber-800",
  paid: "bg-green-100 text-green-800",
  cancelled: "bg-muted text-muted-foreground",
};

export default function Debtors() {
  const { session } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [tab, setTab] = useState<"invoices" | "manual">("invoices");
  const [showAddForm, setShowAddForm] = useState(false);

  // Form state for adding manual debt
  const [form, setForm] = useState({
    debtorName: "",
    debtorPhone: "",
    debtorEmail: "",
    amount: "",
    reason: "",
    notes: "",
    dueDate: "",
    currency: "NGN",
  });

  const { data: debtors, isLoading } = useQuery<Debtor[]>({
    queryKey: ["debtors"],
    queryFn: () => fetchDebtors(session?.access_token ?? ""),
    enabled: !!session,
  });

  const { data: manualDebts, isLoading: manualLoading } = useQuery<ManualDebt[]>({
    queryKey: ["manual-debts"],
    queryFn: () => fetchManualDebts(session?.access_token ?? ""),
    enabled: !!session,
  });

  const createDebt = useMutation({
    mutationFn: async (data: typeof form) => {
      const res = await fetch("/api/debtors/manual", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({
          debtorName: data.debtorName,
          debtorPhone: data.debtorPhone || undefined,
          debtorEmail: data.debtorEmail || undefined,
          amount: Number(data.amount),
          reason: data.reason,
          notes: data.notes || undefined,
          dueDate: data.dueDate || undefined,
          currency: data.currency,
        }),
      });
      if (!res.ok) throw new Error("Failed to create debt");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["manual-debts"] });
      setShowAddForm(false);
      setForm({ debtorName: "", debtorPhone: "", debtorEmail: "", amount: "", reason: "", notes: "", dueDate: "", currency: "NGN" });
      toast({ title: "Manual debt added" });
    },
    onError: () => toast({ variant: "destructive", title: "Failed to add debt" }),
  });

  const markPaid = useMutation({
    mutationFn: async ({ id, amount }: { id: string; amount: number }) => {
      const res = await fetch(`/api/debtors/manual/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({ amountPaid: amount }),
      });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["manual-debts"] });
      toast({ title: "Debt updated" });
    },
    onError: () => toast({ variant: "destructive", title: "Failed to update debt" }),
  });

  const deleteDebt = useMutation({
    mutationFn: async (id: string) => {
      await fetch(`/api/debtors/manual/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${session?.access_token}` },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["manual-debts"] });
      toast({ title: "Debt deleted" });
    },
  });

  const totalOwed = (debtors || []).reduce((sum, d) => sum + d.totalOwed, 0);
  const totalDebtors = (debtors || []).length;
  const criticalCount = (debtors || []).filter((d) => daysSince(d.oldestDueDate) > 30).length;
  const manualTotal = (manualDebts || []).filter((d) => d.status !== "paid" && d.status !== "cancelled").reduce((s, d) => s + d.amountDue, 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Debtors Management</h1>
          <p className="text-muted-foreground mt-1">Track customers with outstanding payments and follow up.</p>
        </div>
        {tab === "manual" && (
          <Button onClick={() => setShowAddForm(true)} className="gap-2">
            <Plus className="h-4 w-4" /> Add Manual Debt
          </Button>
        )}
      </div>

      {/* Stats */}
      <div className="grid gap-4 grid-cols-1 sm:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Invoice Debts</CardTitle>
            <TrendingDown className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">{formatCurrency(totalOwed, "NGN")}</div>
            <p className="text-xs text-muted-foreground mt-1">{totalDebtors} customer(s)</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Manual Debts</CardTitle>
            <HandCoins className="h-4 w-4 text-amber-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-600">{formatCurrency(manualTotal, "NGN")}</div>
            <p className="text-xs text-muted-foreground mt-1">{(manualDebts || []).filter((d) => d.status === "outstanding" || d.status === "partial").length} outstanding</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Critical Cases</CardTitle>
            <AlertTriangle className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{criticalCount}</div>
            <p className="text-xs text-muted-foreground mt-1">Over 30 days overdue</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Debtors</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalDebtors + (manualDebts || []).length}</div>
            <p className="text-xs text-muted-foreground mt-1">All types</p>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-muted rounded-lg w-fit">
        <button
          onClick={() => setTab("invoices")}
          className={cn("px-4 py-1.5 rounded-md text-sm font-medium transition-colors", tab === "invoices" ? "bg-background shadow-sm" : "text-muted-foreground hover:text-foreground")}
        >
          Invoice Debtors {totalDebtors > 0 && <span className="ml-1.5 bg-destructive text-destructive-foreground rounded-full px-1.5 py-0.5 text-xs">{totalDebtors}</span>}
        </button>
        <button
          onClick={() => setTab("manual")}
          className={cn("px-4 py-1.5 rounded-md text-sm font-medium transition-colors", tab === "manual" ? "bg-background shadow-sm" : "text-muted-foreground hover:text-foreground")}
        >
          Manual Debts {(manualDebts || []).filter((d) => d.status !== "paid").length > 0 && (
            <span className="ml-1.5 bg-amber-500 text-white rounded-full px-1.5 py-0.5 text-xs">{(manualDebts || []).filter((d) => d.status !== "paid").length}</span>
          )}
        </button>
      </div>

      {/* Add manual debt form */}
      {showAddForm && tab === "manual" && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-base">Add Manual Debt</CardTitle>
            <Button variant="ghost" size="icon" onClick={() => setShowAddForm(false)}><X className="h-4 w-4" /></Button>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label>Debtor Name *</Label>
                <Input placeholder="Name of person who owes you" value={form.debtorName} onChange={(e) => setForm((f) => ({ ...f, debtorName: e.target.value }))} />
              </div>
              <div className="grid gap-2">
                <Label>Amount *</Label>
                <Input type="number" min="0" placeholder="0" value={form.amount} onChange={(e) => setForm((f) => ({ ...f, amount: e.target.value }))} />
              </div>
              <div className="grid gap-2">
                <Label>Phone Number</Label>
                <Input placeholder="+234..." value={form.debtorPhone} onChange={(e) => setForm((f) => ({ ...f, debtorPhone: e.target.value }))} />
              </div>
              <div className="grid gap-2">
                <Label>Email</Label>
                <Input type="email" placeholder="email@example.com" value={form.debtorEmail} onChange={(e) => setForm((f) => ({ ...f, debtorEmail: e.target.value }))} />
              </div>
              <div className="grid gap-2">
                <Label>Reason *</Label>
                <Input placeholder="e.g. Loan, goods delivered, service rendered" value={form.reason} onChange={(e) => setForm((f) => ({ ...f, reason: e.target.value }))} />
              </div>
              <div className="grid gap-2">
                <Label>Due Date</Label>
                <Input type="date" value={form.dueDate} onChange={(e) => setForm((f) => ({ ...f, dueDate: e.target.value }))} />
              </div>
              <div className="grid gap-2">
                <Label>Currency</Label>
                <Select value={form.currency} onValueChange={(v) => setForm((f) => ({ ...f, currency: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{UNIQUE_CURRENCIES.map((c) => <SelectItem key={c} value={c}>{CURRENCY_LABELS[c] ?? c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid gap-2">
              <Label>Notes</Label>
              <Textarea placeholder="Additional context..." value={form.notes} onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))} className="min-h-[60px]" />
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setShowAddForm(false)}>Cancel</Button>
              <Button
                onClick={() => createDebt.mutate(form)}
                disabled={!form.debtorName || !form.amount || !form.reason || createDebt.isPending}
                className="gap-2"
              >
                {createDebt.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
                Add Debt
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Invoice Debtors Tab */}
      {tab === "invoices" && (
        <Card>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="p-6 space-y-4">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-20 w-full" />)}</div>
            ) : !debtors?.length ? (
              <div className="py-20 text-center">
                <TrendingDown className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="font-medium">No outstanding invoice debts</p>
                <p className="text-sm text-muted-foreground mt-1">All your customers are paid up!</p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Customer</TableHead>
                    <TableHead>Invoices</TableHead>
                    <TableHead className="text-right">Total Owed</TableHead>
                    <TableHead>Urgency</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {debtors.map((d) => {
                    const days = daysSince(d.oldestDueDate);
                    const whatsappMsg = buildWhatsAppMessage(d.customerName, formatCurrency(d.totalOwed, d.currency), d.invoices, d.currency);
                    return (
                      <TableRow key={d.customerId}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <Avatar className="h-9 w-9">
                              <AvatarFallback className="text-sm font-semibold bg-primary/10 text-primary">
                                {d.customerName.slice(0, 2).toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium text-sm">{d.customerName}</p>
                              {d.customerEmail && <p className="text-xs text-muted-foreground">{d.customerEmail}</p>}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            {d.invoices.slice(0, 2).map((inv) => (
                              <Link key={inv.id} href={`/invoices/${inv.id}`}>
                                <Badge variant="outline" className="text-xs cursor-pointer hover:bg-accent">{inv.invoiceNumber}</Badge>
                              </Link>
                            ))}
                            {d.invoices.length > 2 && <Badge variant="secondary" className="text-xs">+{d.invoices.length - 2}</Badge>}
                          </div>
                        </TableCell>
                        <TableCell className="text-right font-bold text-destructive">
                          {formatCurrency(d.totalOwed, d.currency)}
                        </TableCell>
                        <TableCell>{urgencyBadge(days)}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-1">
                            {d.customerEmail && (
                              <a href={`mailto:${d.customerEmail}?subject=Payment Reminder&body=Dear ${d.customerName},%0A%0AYou have outstanding invoices totalling ${formatCurrency(d.totalOwed, d.currency)}.%0A%0AKindly settle at your earliest convenience.`}>
                                <Button variant="ghost" size="icon" className="h-8 w-8"><Mail className="h-3.5 w-3.5" /></Button>
                              </a>
                            )}
                            {d.customerPhone && (
                              <a href={`https://wa.me/${d.customerPhone.replace(/\D/g, "")}?text=${whatsappMsg}`} target="_blank" rel="noreferrer">
                                <Button variant="ghost" size="icon" className="h-8 w-8 text-green-600"><MessageCircle className="h-3.5 w-3.5" /></Button>
                              </a>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      )}

      {/* Manual Debts Tab */}
      {tab === "manual" && (
        <Card>
          <CardContent className="p-0">
            {manualLoading ? (
              <div className="p-6 space-y-4">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-16 w-full" />)}</div>
            ) : !manualDebts?.length ? (
              <div className="py-20 text-center">
                <HandCoins className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="font-medium">No manual debts recorded</p>
                <p className="text-sm text-muted-foreground mt-1">Track loans and non-invoice debts here.</p>
                <Button className="mt-4 gap-2" onClick={() => setShowAddForm(true)}>
                  <Plus className="h-4 w-4" /> Add First Debt
                </Button>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Debtor</TableHead>
                    <TableHead>Reason</TableHead>
                    <TableHead className="text-right">Amount Due</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Due Date</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {manualDebts.map((d) => (
                    <TableRow key={d.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-8 w-8">
                            <AvatarFallback className="text-xs font-semibold bg-amber-100 text-amber-800">
                              {d.debtorName.slice(0, 2).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium text-sm">{d.debtorName}</p>
                            {d.debtorPhone && <p className="text-xs text-muted-foreground">{d.debtorPhone}</p>}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground max-w-[140px] truncate">{d.reason}</TableCell>
                      <TableCell className="text-right font-bold">
                        <div>
                          <div className={cn(d.status === "paid" ? "text-green-600" : "text-amber-600")}>
                            {formatCurrency(d.amountDue, d.currency)}
                          </div>
                          {d.amountPaid > 0 && (
                            <div className="text-xs text-muted-foreground">{formatCurrency(d.amountPaid, d.currency)} paid</div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className={cn("inline-block px-2 py-0.5 rounded-full text-xs font-medium capitalize", STATUS_BADGE[d.status])}>
                          {d.status}
                        </span>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {d.dueDate ? new Date(d.dueDate).toLocaleDateString() : "—"}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          {d.debtorPhone && (
                            <a href={`https://wa.me/${d.debtorPhone.replace(/\D/g, "")}?text=${encodeURIComponent(`Hi ${d.debtorName}, this is a reminder that you owe ${formatCurrency(d.amount, d.currency)} for: ${d.reason}. Kindly settle at your earliest convenience. Thank you!`)}`} target="_blank" rel="noreferrer">
                              <Button variant="ghost" size="icon" className="h-8 w-8 text-green-600"><MessageCircle className="h-3.5 w-3.5" /></Button>
                            </a>
                          )}
                          {d.status !== "paid" && d.status !== "cancelled" && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 text-xs"
                              disabled={markPaid.isPending}
                              onClick={() => markPaid.mutate({ id: d.id, amount: d.amount })}
                            >
                              Mark Paid
                            </Button>
                          )}
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-muted-foreground hover:text-destructive"
                            disabled={deleteDebt.isPending}
                            onClick={() => deleteDebt.mutate(d.id)}
                          >
                            <X className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
