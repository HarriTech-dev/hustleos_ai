import { useEffect, useState } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Skeleton } from "../../components/ui/skeleton";
import { Badge } from "../../components/ui/badge";
import { useToast } from "../../hooks/use-toast";
import { Bell, Check, CheckCheck, Trash2, FileText, Package, Users, CreditCard, AlertTriangle, Info } from "lucide-react";
import { useLocation } from "wouter";

interface Notification {
  id: string;
  type: string;
  title: string;
  message: string;
  link?: string | null;
  read: boolean;
  createdAt: string;
}

const TYPE_ICONS: Record<string, React.ElementType> = {
  invoice_paid: FileText,
  invoice_overdue: AlertTriangle,
  low_stock: Package,
  new_customer: Users,
  payment_received: CreditCard,
  team_invite: Users,
  subscription_expiry: CreditCard,
  report_ready: FileText,
  system: Info,
};

const TYPE_COLORS: Record<string, string> = {
  invoice_paid: "text-green-600 bg-green-50 dark:bg-green-900/20",
  invoice_overdue: "text-red-600 bg-red-50 dark:bg-red-900/20",
  low_stock: "text-amber-600 bg-amber-50 dark:bg-amber-900/20",
  new_customer: "text-blue-600 bg-blue-50 dark:bg-blue-900/20",
  payment_received: "text-green-600 bg-green-50 dark:bg-green-900/20",
  team_invite: "text-purple-600 bg-purple-50 dark:bg-purple-900/20",
  subscription_expiry: "text-orange-600 bg-orange-50 dark:bg-orange-900/20",
  report_ready: "text-blue-600 bg-blue-50 dark:bg-blue-900/20",
  system: "text-gray-600 bg-gray-50 dark:bg-gray-900/20",
};

function timeAgo(dateStr: string) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "Just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

export default function Notifications() {
  const { session } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [items, setItems] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [markingAll, setMarkingAll] = useState(false);

  const authHeaders = { Authorization: `Bearer ${session?.access_token}`, "Content-Type": "application/json" };

  const fetchNotifications = async () => {
    if (!session) return;
    try {
      const r = await fetch("/api/notifications", { headers: authHeaders });
      const data = await r.json();
      setItems(data.items ?? []);
    } catch {
      /* silently fail */
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchNotifications(); }, [session]);

  const markRead = async (id: string) => {
    await fetch(`/api/notifications/${id}/read`, { method: "POST", headers: authHeaders });
    setItems((prev) => prev.map((n) => n.id === id ? { ...n, read: true } : n));
  };

  const markAllRead = async () => {
    setMarkingAll(true);
    try {
      await fetch("/api/notifications/read-all", { method: "POST", headers: authHeaders });
      setItems((prev) => prev.map((n) => ({ ...n, read: true })));
    } finally {
      setMarkingAll(false);
    }
  };

  const deleteNotification = async (id: string) => {
    await fetch(`/api/notifications/${id}`, { method: "DELETE", headers: authHeaders });
    setItems((prev) => prev.filter((n) => n.id !== id));
  };

  const handleClick = (n: Notification) => {
    if (!n.read) markRead(n.id);
    if (n.link) navigate(n.link);
  };

  const unread = items.filter((n) => !n.read).length;

  return (
    <div className="space-y-6 max-w-2xl">
      <div className="flex flex-col sm:flex-row items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight flex items-center gap-2">
            Notifications
            {unread > 0 && (
              <Badge variant="destructive" className="text-xs">{unread}</Badge>
            )}
          </h1>
          <p className="text-muted-foreground mt-1">Stay on top of your business activity.</p>
        </div>
        {unread > 0 && (
          <Button variant="outline" size="sm" onClick={markAllRead} disabled={markingAll} className="gap-1.5">
            <CheckCheck className="h-4 w-4" />
            Mark All Read
          </Button>
        )}
      </div>

      {loading ? (
        <div className="space-y-3">
          {Array(5).fill(0).map((_, i) => <Skeleton key={i} className="h-20 w-full" />)}
        </div>
      ) : items.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center">
            <Bell className="h-12 w-12 text-muted-foreground/40 mx-auto mb-3" />
            <p className="font-medium text-muted-foreground">No notifications yet</p>
            <p className="text-sm text-muted-foreground/70 mt-1">We'll alert you when important things happen.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {items.map((n) => {
            const Icon = TYPE_ICONS[n.type] ?? Info;
            const colorClass = TYPE_COLORS[n.type] ?? TYPE_COLORS.system;
            return (
              <div
                key={n.id}
                onClick={() => handleClick(n)}
                className={`flex items-start gap-4 p-4 rounded-xl border cursor-pointer transition-all hover:shadow-sm ${
                  n.read ? "bg-background opacity-70 hover:opacity-100" : "bg-card shadow-sm border-primary/20"
                }`}
              >
                <div className={`p-2 rounded-full shrink-0 ${colorClass}`}>
                  <Icon className="h-4 w-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <p className={`text-sm font-semibold truncate ${!n.read ? "text-foreground" : "text-muted-foreground"}`}>
                      {n.title}
                    </p>
                    <div className="flex items-center gap-1.5 shrink-0">
                      {!n.read && <span className="h-2 w-2 rounded-full bg-primary shrink-0" />}
                      <span className="text-xs text-muted-foreground">{timeAgo(n.createdAt)}</span>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mt-0.5 line-clamp-2">{n.message}</p>
                </div>
                <Button
                  size="icon"
                  variant="ghost"
                  className="shrink-0 h-7 w-7 opacity-0 group-hover:opacity-100 hover:text-destructive"
                  onClick={(e) => { e.stopPropagation(); deleteNotification(n.id); }}
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
