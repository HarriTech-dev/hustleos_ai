import { useState } from "react";
import { useLocation } from "wouter";
import { useCreateCustomer } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Textarea } from "../../components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import { useToast } from "../../hooks/use-toast";
import { ArrowLeft, Loader2, UserPlus } from "lucide-react";
import { Link } from "wouter";

import { CURRENCY_LABELS, UNIQUE_CURRENCIES } from "../../lib/currencies";
import { COUNTRY_NAMES, COUNTRY_CURRENCY_MAP } from "../../lib/countries";

export default function NewCustomer() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { mutateAsync: createCustomer, isPending: creating } = useCreateCustomer();

  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    address: "",
    city: "",
    country: "Nigeria",
    currency: "NGN",
    notes: "",
  });

  const set = (field: string, value: string) => setForm((f) => ({ ...f, [field]: value }));

  const handleSubmit = async () => {
    if (!form.name || !form.email) {
      toast({ variant: "destructive", title: "Required fields", description: "Name and email are required." });
      return;
    }
    try {
      const customer = await createCustomer({ data: { name: form.name, email: form.email, phone: form.phone || undefined, address: form.address ? `${form.address}${form.city ? ", " + form.city : ""}` : undefined, country: form.country, currency: form.currency, notes: form.notes || undefined } });
      toast({ title: "Customer added!", description: `${form.name} has been added to your customers.` });
      navigate(`/customers/${customer.id}`);
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Failed to add customer. Check if email is unique." });
    }
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div className="flex items-center gap-4">
        <Link href="/customers">
          <Button variant="ghost" size="icon" className="h-9 w-9">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight flex items-center gap-2">
            <UserPlus className="h-6 w-6 sm:h-7 sm:w-7" /> Add Customer
          </h1>
          <p className="text-muted-foreground mt-1">Add a new client to your customer database.</p>
        </div>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Contact Information</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-2">
              <Label htmlFor="name">Full Name *</Label>
              <Input id="name" value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="Emeka Okonkwo" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="company">Company</Label>
              <Input id="company" value={form.company} onChange={(e) => set("company", e.target.value)} placeholder="Okonkwo & Sons Ltd" />
            </div>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-2">
              <Label htmlFor="email">Email Address *</Label>
              <Input id="email" type="email" value={form.email} onChange={(e) => set("email", e.target.value)} placeholder="emeka@example.com" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input id="phone" type="tel" value={form.phone} onChange={(e) => set("phone", e.target.value)} placeholder="+234 800 000 0000" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Location</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-2">
            <Label htmlFor="address">Address</Label>
            <Input id="address" value={form.address} onChange={(e) => set("address", e.target.value)} placeholder="123 Lagos Street, Victoria Island" />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-2">
              <Label htmlFor="city">City</Label>
              <Input id="city" value={form.city} onChange={(e) => set("city", e.target.value)} placeholder="Lagos" />
            </div>
            <div className="grid gap-2">
              <Label>Country</Label>
              <Select value={form.country} onValueChange={(v) => {
                const currency = COUNTRY_CURRENCY_MAP[v] || form.currency;
                setForm({...form, country: v, currency});
              }}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{COUNTRY_NAMES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Billing Preferences</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-2">
            <Label>Default Currency</Label>
            <Select value={form.currency} onValueChange={(v) => set("currency", v)}>
              <SelectTrigger className="max-w-[200px]"><SelectValue /></SelectTrigger>
              <SelectContent>{UNIQUE_CURRENCIES.map((c) => <SelectItem key={c} value={c}>{CURRENCY_LABELS[c] ?? c}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea id="notes" value={form.notes} onChange={(e) => set("notes", e.target.value)} placeholder="Any special notes about this customer..." className="min-h-[80px]" />
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-3 justify-end">
        <Link href="/customers">
          <Button variant="outline">Cancel</Button>
        </Link>
        <Button onClick={handleSubmit} disabled={creating} className="gap-2 min-w-[140px]">
          {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : <UserPlus className="h-4 w-4" />}
          Add Customer
        </Button>
      </div>
    </div>
  );
}
