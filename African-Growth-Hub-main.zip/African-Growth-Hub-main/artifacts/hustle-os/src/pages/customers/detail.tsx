import { useParams, useLocation } from "wouter";
import { useAuth } from "../../contexts/AuthContext";
import { Badge } from "../../components/ui/badge";
import { Button } from "../../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../../components/ui/card";
import { Skeleton } from "../../components/ui/skeleton";
import { Separator } from "../../components/ui/separator";
import { useToast } from "../../hooks/use-toast";
import { ArrowLeft, Mail, Phone, MapPin, MessageCircle, FileText, Trash2, Loader2, Edit2, CheckCircle } from "lucide-react";
import { useState, useEffect } from "react";

interface Customer {
  id: string;
  name: string;
  email: string;
  phone?: string | null;
  address?: string | null;
  country?: string | null;
  segment?: string | null;
  currency: string;
  notes?: string | null;
  createdAt: string;
  totalSpent?: number;
  invoiceCount?: number;
  balance?: number;
  balanceStatus?: string;
}

interface Invoice {
  id: string;
  invoiceNumber: string;
  status: string;
  total: number;
  currency: string;
  dueDate: string;
  createdAt: string;
}

const STATUS_BADGE: Record<string, string> = {
  draft: "bg-muted text-muted-foreground",
  sent: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  paid: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
  overdue: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
  cancelled: "bg-gray-100 text-gray-600",
};

function fmt(amount: number, currency: string) {
  try {
    return new Intl.NumberFormat("en-NG", { style: "currency", currency, minimumFractionDigits: 0 }).format(amount);
  } catch {
    return `${currency} ${amount.toLocaleString()}`;
  }
}

export default function CustomerDetail() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { session } = useAuth();
  const { toast } = useToast();
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState(false);

  const authHeaders = { Authorization: `Bearer ${session?.access_token}`, "Content-Type": "application/json" };

  useEffect(() => {
    if (!id || !session) return;
    Promise.all([
      fetch(`/api/customers/${id}`, { headers: authHeaders }).then((r) => r.json()),
      fetch(`/api/customers/${id}/invoices`, { headers: authHeaders }).then((r) => r.json()),
    ])
      .then(([c, inv]) => {
        setCustomer(c);
        setInvoices(Array.isArray(inv) ? inv : []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, session?.access_token]);

  const handleDelete = async () => {
    if (!confirm("Delete this customer? Their invoices will remain.")) return;
    setDeleting(true);
    try {
      await fetch(`/api/customers/${id}`, { method: "DELETE", headers: authHeaders });
      toast({ title: "Customer deleted" });
      navigate("/customers");
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Failed to delete customer." });
      setDeleting(false);
    }
  };

  const totalSpent = invoices.filter((i) => i.status === "paid").reduce((s, i) => s + i.total, 0);
  const outstanding = invoices.filter((i) => i.status === "sent" || i.status === "overdue").reduce((s, i) => s + i.total, 0);

  if (loading) {
    return (
      <div className="space-y-6 max-w-3xl">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-48 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!customer) {
    return (
      <div className="text-center py-20">
        <p className="text-muted-foreground">Customer not found.</p>
        <Button variant="ghost" onClick={() => navigate("/customers")} className="mt-4 gap-2">
          <ArrowLeft className="h-4 w-4" /> Back
        </Button>
      </div>
    );
  }

  const whatsappNumber = customer.phone?.replace(/\D/g, "");

  return (
    <div className="space-y-6 max-w-3xl">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <Button variant="ghost" onClick={() => navigate("/customers")} className="gap-2 -ml-2 shrink-0">
          <ArrowLeft className="h-4 w-4" /> Customers
        </Button>
        <div className="flex gap-2 flex-wrap">
          {whatsappNumber && (
            <Button size="sm" variant="outline" asChild className="gap-1.5 text-green-600 border-green-200 hover:bg-green-50 dark:hover:bg-green-900/20">
              <a href={`https://wa.me/${whatsappNumber}`} target="_blank" rel="noopener noreferrer">
                <MessageCircle className="h-3.5 w-3.5" /> WhatsApp
              </a>
            </Button>
          )}
          <Button size="sm" variant="outline" asChild className="gap-1.5">
            <a href={`mailto:${customer.email}`}>
              <Mail className="h-3.5 w-3.5" /> Email
            </a>
          </Button>
          <Button size="sm" variant="destructive" onClick={handleDelete} disabled={deleting} className="gap-1.5">
            {deleting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
            Delete
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-start gap-4">
            <div className="h-14 w-14 rounded-full bg-primary/10 text-primary flex items-center justify-center text-2xl font-bold shrink-0">
              {customer.name?.charAt(0).toUpperCase() ?? '?'}
            </div>
            <div className="flex-1">
              <CardTitle className="text-xl">{customer.name}</CardTitle>
              {customer.segment && (
                <Badge variant="secondary" className="mt-1 text-xs">{customer.segment}</Badge>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <a href={`mailto:${customer.email}`} className="flex items-center gap-2 text-sm hover:text-primary transition-colors">
              <Mail className="h-4 w-4 text-muted-foreground shrink-0" /> {customer.email}
            </a>
            {customer.phone && (
              <a href={`tel:${customer.phone}`} className="flex items-center gap-2 text-sm hover:text-primary transition-colors">
                <Phone className="h-4 w-4 text-muted-foreground shrink-0" /> {customer.phone}
              </a>
            )}
            {customer.address && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="h-4 w-4 shrink-0" /> {customer.address}{customer.country ? `, ${customer.country}` : ""}
              </div>
            )}
          </div>
          {customer.notes && (
            <div className="bg-muted/40 rounded-lg p-3 text-sm text-muted-foreground">
              {customer.notes}
            </div>
          )}

          <Separator />

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
            <div>
              <p className="text-2xl font-bold text-green-600">{fmt(totalSpent, customer.currency)}</p>
              <p className="text-xs text-muted-foreground">Total Paid</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-amber-600">{fmt(outstanding, customer.currency)}</p>
              <p className="text-xs text-muted-foreground">Outstanding</p>
            </div>
            <div>
              <p className={`text-2xl font-bold ${customer.balanceStatus === "debt" ? "text-red-600" : customer.balanceStatus === "credit" ? "text-blue-600" : "text-muted-foreground"}`}>
                {fmt(customer.balance ?? 0, customer.currency)}
              </p>
              <p className="text-xs text-muted-foreground">Balance</p>
            </div>
            <div>
              <p className="text-2xl font-bold">{invoices.length}</p>
              <p className="text-xs text-muted-foreground">Invoices</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <FileText className="h-4 w-4" /> Invoice History
          </CardTitle>
          <Button size="sm" onClick={() => navigate("/invoices/new")} variant="outline" className="gap-1.5 text-xs">
            + New Invoice
          </Button>
        </CardHeader>
        <CardContent>
          {invoices.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">No invoices yet.</p>
          ) : (
            <div className="space-y-2">
              {invoices.map((inv) => (
                <div
                  key={inv.id}
                  onClick={() => navigate(`/invoices/${inv.id}`)}
                  className="flex items-center justify-between p-3 rounded-lg border cursor-pointer hover:bg-muted/40 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium ${STATUS_BADGE[inv.status]}`}>
                      {inv.status}
                    </span>
                    <span className="text-sm font-medium">{inv.invoiceNumber}</span>
                    <span className="text-xs text-muted-foreground hidden sm:block">
                      Due {new Date(inv.dueDate).toLocaleDateString()}
                    </span>
                  </div>
                  <span className="font-semibold text-sm">{fmt(inv.total, inv.currency)}</span>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
