import { useState } from "react";
import { Link, useLocation } from "wouter";
import { supabase } from "../../lib/supabase";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "../../components/ui/card";
import { useToast } from "../../hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import { COUNTRY_NAMES, COUNTRY_CURRENCY_MAP } from "../../lib/countries";
import { UNIQUE_CURRENCIES, CURRENCY_LABELS } from "../../lib/currencies";

export default function Register() {
  const [formData, setFormData] = useState({
    name: "",
    businessName: "",
    email: "",
    password: "",
    country: "",
    currency: "NGN"
  });
  const [loading, setLoading] = useState(false);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Register via API server which uses the admin key to auto-confirm the email
      const resp = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data = (await resp.json()) as { error?: string };

      if (!resp.ok) {
        toast({
          variant: "destructive",
          title: "Registration Failed",
          description: "Registration failed. Please check your details and try again.",
        });
        setLoading(false);
        return;
      }

      // Account created — now sign them in immediately
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: formData.email,
        password: formData.password,
      });

      if (signInError) {
        toast({
          variant: "destructive",
          title: "Account created but sign-in failed",
          description: signInError.message,
        });
        setLocation("/auth/login");
      } else {
        toast({ title: "Welcome to HustleOS!", description: "Your account is ready." });
        setLocation("/");
      }
    } catch {
      toast({
        variant: "destructive",
        title: "Network Error",
        description: "Could not connect. Please try again.",
      });
    }

    setLoading(false);
  };

  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-muted/30 p-4 sm:p-6 py-6 sm:py-12">
      <Card className="w-full max-w-xl shadow-lg border-primary/10">
        <CardHeader className="space-y-2 text-center pb-6 sm:pb-8">
          <div className="mx-auto mb-3 sm:mb-4 flex h-10 w-10 sm:h-12 sm:w-12 items-center justify-center rounded-xl bg-primary text-primary-foreground">
            <span className="text-xl sm:text-2xl font-bold">H</span>
          </div>
          <CardTitle className="text-2xl sm:text-3xl font-bold tracking-tight text-foreground">Start your hustle</CardTitle>
          <CardDescription className="text-sm sm:text-base">
            Set up your business operating system in minutes
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleRegister} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  placeholder="John Doe"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="businessName">Business Name</Label>
                <Input
                  id="businessName"
                  placeholder="Acme Trading Co."
                  value={formData.businessName}
                  onChange={(e) => setFormData({...formData, businessName: e.target.value})}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email address</Label>
              <Input
                id="email"
                type="email"
                placeholder="name@business.com"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="At least 6 characters"
                value={formData.password}
                onChange={(e) => setFormData({...formData, password: e.target.value})}
                minLength={6}
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="country">Country</Label>
                <Select value={formData.country} onValueChange={(v) => {
                  const currency = COUNTRY_CURRENCY_MAP[v] || "NGN";
                  setFormData({...formData, country: v, currency});
                }}>
                  <SelectTrigger id="country">
                    <SelectValue placeholder="Select country" />
                  </SelectTrigger>
                  <SelectContent>
                    {COUNTRY_NAMES.map(c => (
                      <SelectItem key={c} value={c}>{c}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="currency">Base Currency</Label>
                <Select value={formData.currency} onValueChange={(v) => setFormData({...formData, currency: v})}>
                  <SelectTrigger id="currency">
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    {UNIQUE_CURRENCIES.map(c => (
                      <SelectItem key={c} value={c}>{CURRENCY_LABELS[c] ?? c}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button type="submit" className="w-full h-11 text-base font-semibold mt-6" disabled={loading}>
              {loading ? "Creating account..." : "Create Account"}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex flex-col items-center justify-center border-t p-6">
          <div className="text-sm text-muted-foreground">
            Already have an account?{" "}
            <Link href="/auth/login" className="font-semibold text-primary hover:underline">
              Sign in
            </Link>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
}
