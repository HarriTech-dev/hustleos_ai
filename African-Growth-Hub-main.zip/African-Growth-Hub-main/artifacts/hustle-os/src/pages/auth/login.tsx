import { useState } from "react";
import { Link, useLocation } from "wouter";
import { supabase } from "../../lib/supabase";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "../../components/ui/card";
import { useToast } from "../../hooks/use-toast";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      const isUnconfirmed = error.message.toLowerCase().includes("email not confirmed") ||
        error.message.toLowerCase().includes("confirmation");
      toast({
        variant: "destructive",
        title: isUnconfirmed ? "Email Not Confirmed" : "Login Failed",
        description: isUnconfirmed
          ? "Please check your inbox and click the confirmation link, or create a new account."
          : error.message,
      });
    } else {
      setLocation("/");
    }
    
    setLoading(false);
  };

  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-muted/30 p-4 sm:p-6">
      <Card className="w-full max-w-[420px] shadow-lg border-primary/10">
        <CardHeader className="space-y-2 text-center pb-6 sm:pb-8">
          <div className="mx-auto mb-3 sm:mb-4 flex h-10 w-10 sm:h-12 sm:w-12 items-center justify-center rounded-xl bg-primary text-primary-foreground">
            <span className="text-xl sm:text-2xl font-bold">H</span>
          </div>
          <CardTitle className="text-2xl sm:text-3xl font-bold tracking-tight text-foreground">Welcome back</CardTitle>
          <CardDescription className="text-sm sm:text-base">
            Enter your credentials to access your command center
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email address</Label>
              <Input
                id="email"
                type="email"
                placeholder="name@business.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="h-11"
                data-testid="input-email"
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between flex-wrap gap-1">
                <Label htmlFor="password">Password</Label>
                <Link href="/auth/forgot-password" className="text-sm font-medium text-primary hover:underline">
                  Forgot password?
                </Link>
              </div>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="h-11"
                data-testid="input-password"
              />
            </div>
            <Button type="submit" className="w-full h-11 text-base font-semibold mt-6" disabled={loading} data-testid="button-login">
              {loading ? "Signing in..." : "Sign in to HustleOS"}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex flex-col items-center justify-center border-t p-4 sm:p-6">
          <div className="text-sm text-muted-foreground">
            Don't have an account?{" "}
            <Link href="/auth/register" className="font-semibold text-primary hover:underline">
              Create one now
            </Link>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
}
