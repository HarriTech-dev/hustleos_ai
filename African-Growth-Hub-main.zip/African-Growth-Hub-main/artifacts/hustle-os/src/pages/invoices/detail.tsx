import { useParams, useLocation } from "wouter";
import { useAuth } from "../../contexts/AuthContext";
import { Badge } from "../../components/ui/badge";
import { Button } from "../../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Separator } from "../../components/ui/separator";
import { Skeleton } from "../../components/ui/skeleton";
import { useToast } from "../../hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../../components/ui/dialog";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import {
  ArrowLeft, Download, Send, CheckCircle, Printer, Trash2, Loader2,
  MessageCircle, History, Receipt, CreditCard
} from "lucide-react";
import { useState, useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useGetMe, getGetDashboardSummaryQueryKey, getGetRecentActivityQueryKey, getGetRevenueChartQueryKey, getGetInvoiceStatsQueryKey, getListInvoicesQueryKey } from "@workspace/api-client-react";

interface InvoiceItem {
  name: string;
  description?: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

interface PaymentRecord {
  id: string;
  amount: number;
  method: string;
  notes: string | null;
  createdAt: string;
}

interface AuditLog {
  id: string;
  action: string;
  changes: Record<string, unknown> | null;
  createdAt: string;
}

interface Invoice {
  id: string;
  invoiceNumber: string;
  customerId: string;
  customerName: string;
  customerEmail: string | null;
  status: "draft" | "sent" | "paid" | "overdue" | "cancelled" | "viewed" | "partial";
  items: InvoiceItem[];
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  amountPaid: number;
  amountDue: number;
  currency: string;
  notes: string | null;
  dueDate: string;
  paidAt: string | null;
  viewedAt: string | null;
  createdAt: string;
  payments: PaymentRecord[];
}

const STATUS_COLORS: Record<string, string> = {
  draft: "bg-muted text-muted-foreground",
  sent: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  viewed: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300",
  paid: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
  partial: "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300",
  overdue: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
  cancelled: "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400",
};

function fmt(amount: number, currency: string) {
  return new Intl.NumberFormat("en-NG", { style: "currency", currency, minimumFractionDigits: 2 }).format(amount);
}

export default function InvoiceDetail() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { session } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const { data: profile } = useGetMe();
  const [invoice, setInvoice] = useState<Invoice | null>(null);
  const [loading, setLoading] = useState(true);
  const [acting, setActing] = useState<string | null>(null);
  const [history, setHistory] = useState<AuditLog[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("cash");
  const [paymentNotes, setPaymentNotes] = useState("");

  const authHeaders = { Authorization: `Bearer ${session?.access_token}`, "Content-Type": "application/json" };

  const invalidateCrossModule = () => {
    qc.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
    qc.invalidateQueries({ queryKey: getGetRecentActivityQueryKey() });
    qc.invalidateQueries({ queryKey: getGetRevenueChartQueryKey() });
    qc.invalidateQueries({ queryKey: getGetInvoiceStatsQueryKey() });
    qc.invalidateQueries({ queryKey: getListInvoicesQueryKey() });
    qc.invalidateQueries({ queryKey: ["debtors"] });
    qc.invalidateQueries({ queryKey: ["transactions-summary"] });
  };

  const loadInvoice = async () => {
    if (!id || !session) return;
    const r = await fetch(`/api/invoices/${id}`, { headers: authHeaders });
    const data = await r.json();
    setInvoice(data);
  };

  useEffect(() => {
    if (!id || !session) return;
    loadInvoice().then(() => setLoading(false)).catch(() => setLoading(false));
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, session?.access_token]);

  const doAction = async (action: "send" | "mark-paid" | "delete") => {
    if (!invoice) return;
    setActing(action);
    try {
      if (action === "delete") {
        await fetch(`/api/invoices/${id}`, { method: "DELETE", headers: authHeaders });
        toast({ title: "Invoice deleted" });
        navigate("/invoices");
        return;
      }
      const r = await fetch(`/api/invoices/${id}/${action}`, { method: "POST", headers: authHeaders });
      const updated = await r.json();
      setInvoice(updated);
      toast({ title: action === "send" ? "Invoice sent" : "Marked as paid" });
      if (action === "mark-paid") invalidateCrossModule();
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Action failed. Try again." });
    } finally {
      setActing(null);
    }
  };

  const handlePayment = async () => {
    if (!invoice || !paymentAmount) return;
    const amount = Number(paymentAmount);
    if (amount <= 0 || amount > invoice.amountDue) {
      toast({ variant: "destructive", title: "Invalid amount" });
      return;
    }
    setActing("payment");
    try {
      const r = await fetch(`/api/invoices/${id}/payments`, {
        method: "POST",
        headers: authHeaders,
        body: JSON.stringify({ amount, method: paymentMethod, notes: paymentNotes || undefined }),
      });
      const updated = await r.json();
      setInvoice(updated);
      setShowPayment(false);
      setPaymentAmount("");
      setPaymentNotes("");
      toast({ title: "Payment recorded" });
      invalidateCrossModule();
    } catch {
      toast({ variant: "destructive", title: "Payment failed" });
    } finally {
      setActing(null);
    }
  };

  const shareWhatsApp = async () => {
    try {
      const r = await fetch(`/api/invoices/${id}/whatsapp`, { headers: authHeaders });
      const { link } = await r.json();
      window.open(link, "_blank");
    } catch {
      toast({ variant: "destructive", title: "Could not generate WhatsApp link" });
    }
  };

  const downloadPDF = async () => {
    try {
      setActing("pdf");
      const r = await fetch(`/api/invoices/${id}/pdf`, { headers: authHeaders });
      if (!r.ok) throw new Error("Failed to fetch PDF");
      const html = await r.text();
      const blob = new Blob([html], { type: "text/html" });
      const url = URL.createObjectURL(blob);
      const win = window.open(url, "_blank");
      if (win) {
        win.addEventListener("load", () => URL.revokeObjectURL(url));
      }
    } catch {
      toast({ variant: "destructive", title: "PDF download failed", description: "Try again." });
    } finally {
      setActing(null);
    }
  };

  const loadHistory = async () => {
    try {
      const r = await fetch(`/api/invoices/${id}/history`, { headers: authHeaders });
      const data = await r.json();
      setHistory(data);
      setShowHistory(true);
    } catch {
      toast({ variant: "destructive", title: "Could not load history" });
    }
  };

  const printInvoice = () => window.print();

  if (loading) {
    return (
      <div className="space-y-6 max-w-3xl mx-auto">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-64 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  if (!invoice) {
    return (
      <div className="text-center py-20">
        <p className="text-muted-foreground">Invoice not found.</p>
        <Button variant="ghost" onClick={() => navigate("/invoices")} className="mt-4 gap-2">
          <ArrowLeft className="h-4 w-4" /> Back to Invoices
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-3xl mx-auto print:max-w-full">
      {/* Actions */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 print:hidden">
        <Button variant="ghost" onClick={() => navigate("/invoices")} className="gap-2 -ml-2 shrink-0">
          <ArrowLeft className="h-4 w-4" /> Invoices
        </Button>
        <div className="flex gap-2 flex-wrap">
          {invoice.status === "draft" && (
            <Button size="sm" variant="outline" onClick={() => doAction("send")} disabled={!!acting} className="gap-1.5">
              {acting === "send" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
              Send
            </Button>
          )}
          {(invoice.status === "sent" || invoice.status === "overdue" || invoice.status === "viewed" || invoice.status === "partial") && (
            <>
              <Button size="sm" onClick={() => setShowPayment(true)} disabled={!!acting} className="gap-1.5">
                <CreditCard className="h-3.5 w-3.5" /> Record Payment
              </Button>
              <Button size="sm" variant="outline" onClick={() => doAction("mark-paid")} disabled={!!acting} className="gap-1.5">
                {acting === "mark-paid" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CheckCircle className="h-3.5 w-3.5" />}
                Mark Paid
              </Button>
            </>
          )}
          <Button size="sm" variant="outline" onClick={shareWhatsApp} className="gap-1.5">
            <MessageCircle className="h-3.5 w-3.5" /> WhatsApp
          </Button>
          <Button size="sm" variant="outline" onClick={downloadPDF} className="gap-1.5">
            <Download className="h-3.5 w-3.5" /> PDF
          </Button>
          <Button size="sm" variant="outline" onClick={printInvoice} className="gap-1.5">
            <Printer className="h-3.5 w-3.5" /> Print
          </Button>
          <Button size="sm" variant="outline" onClick={loadHistory} className="gap-1.5">
            <History className="h-3.5 w-3.5" /> History
          </Button>
          <Button size="sm" variant="destructive" onClick={() => doAction("delete")} disabled={!!acting} className="gap-1.5">
            {acting === "delete" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
            Delete
          </Button>
        </div>
      </div>

      {/* Invoice Card */}
      <Card className="print:shadow-none print:border-0">
        <CardHeader className="pb-4">
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-primary font-bold text-xl mb-1">
                <img
                  src={profile?.businessLogo || "/logo.png"}
                  alt="Logo"
                  className="h-8 w-8 rounded-lg object-cover bg-primary shrink-0"
                  onError={(e) => { (e.target as HTMLImageElement).src = ''; (e.target as HTMLImageElement).style.display = 'none'; }}
                />
                HustleOS
              </div>
              <p className="text-sm text-muted-foreground">Business Management Platform</p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-primary">{invoice.invoiceNumber}</p>
              <span className={`inline-block mt-1 px-2.5 py-0.5 rounded-full text-xs font-medium ${STATUS_COLORS[invoice.status]}`}>
                {invoice.status.toUpperCase()}
              </span>
              {invoice.viewedAt && (
                <p className="text-xs text-purple-600 mt-1">Viewed {new Date(invoice.viewedAt).toLocaleDateString()}</p>
              )}
            </div>
          </div>
        </CardHeader>

        <Separator />

        <CardContent className="pt-6 space-y-6">
          <div className="grid grid-cols-2 gap-6">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Bill To</p>
              <p className="font-semibold text-base">{invoice.customerName}</p>
              {invoice.customerEmail && (
                <p className="text-sm text-muted-foreground">{invoice.customerEmail}</p>
              )}
            </div>
            <div className="text-right">
              <div className="space-y-1">
                <div>
                  <p className="text-xs text-muted-foreground">Issue Date</p>
                  <p className="font-medium text-sm">{new Date(invoice.createdAt).toLocaleDateString()}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Due Date</p>
                  <p className="font-medium text-sm">{new Date(invoice.dueDate).toLocaleDateString()}</p>
                </div>
                {invoice.paidAt && (
                  <div>
                    <p className="text-xs text-muted-foreground">Paid On</p>
                    <p className="font-medium text-sm text-green-600">{new Date(invoice.paidAt).toLocaleDateString()}</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Line Items */}
          <div className="rounded-lg border overflow-hidden table-responsive">
            <table className="w-full text-sm min-w-[500px] sm:min-w-0">
              <thead className="bg-muted/50">
                <tr>
                  <th className="text-left p-3 font-semibold">Item</th>
                  <th className="text-center p-3 font-semibold">Qty</th>
                  <th className="text-right p-3 font-semibold">Unit Price</th>
                  <th className="text-right p-3 font-semibold">Total</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {(invoice.items || []).map((item, i) => (
                  <tr key={i} className="hover:bg-muted/20">
                    <td className="p-3">
                      <p className="font-medium">{item.name}</p>
                      {item.description && <p className="text-xs text-muted-foreground mt-0.5">{item.description}</p>}
                    </td>
                    <td className="p-3 text-center text-muted-foreground">{item.quantity}</td>
                    <td className="p-3 text-right text-muted-foreground">{fmt(item.unitPrice, invoice.currency)}</td>
                    <td className="p-3 text-right font-medium">{fmt(item.total, invoice.currency)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Totals */}
          <div className="flex justify-end">
            <div className="w-64 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span>{fmt(invoice.subtotal, invoice.currency)}</span>
              </div>
              {invoice.discount > 0 && (
                <div className="flex justify-between text-sm text-red-600">
                  <span className="text-muted-foreground">Discount</span>
                  <span>-{fmt(invoice.discount, invoice.currency)}</span>
                </div>
              )}
              {invoice.tax > 0 && (
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Tax</span>
                  <span>{fmt(invoice.tax, invoice.currency)}</span>
                </div>
              )}
              <Separator />
              <div className="flex justify-between font-bold text-base">
                <span>Total</span>
                <span className="text-primary">{fmt(invoice.total, invoice.currency)}</span>
              </div>
              {invoice.amountPaid > 0 && (
                <>
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>Amount Paid</span>
                    <span>{fmt(invoice.amountPaid, invoice.currency)}</span>
                  </div>
                  <div className="flex justify-between text-sm font-semibold">
                    <span>Amount Due</span>
                    <span className={invoice.amountDue > 0 ? "text-red-600" : "text-green-600"}>
                      {fmt(invoice.amountDue, invoice.currency)}
                    </span>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Payment History */}
          {invoice.payments && invoice.payments.length > 0 && (
            <div className="rounded-lg border p-4 space-y-3">
              <div className="flex items-center gap-2 text-sm font-semibold">
                <Receipt className="h-4 w-4 text-muted-foreground" />
                Payment History
              </div>
              <div className="space-y-2">
                {invoice.payments.map((p) => (
                  <div key={p.id} className="flex items-center justify-between text-sm py-2 border-b last:border-0">
                    <div>
                      <span className="font-medium">{fmt(p.amount, invoice.currency)}</span>
                      <span className="text-muted-foreground ml-2 capitalize">{p.method}</span>
                      {p.notes && <span className="text-muted-foreground ml-2">({p.notes})</span>}
                    </div>
                    <span className="text-xs text-muted-foreground">{new Date(p.createdAt).toLocaleDateString()}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {invoice.notes && (
            <div className="bg-muted/40 rounded-lg p-4">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1">Notes</p>
              <p className="text-sm">{invoice.notes}</p>
            </div>
          )}

          <div className="text-center text-xs text-muted-foreground pt-2 border-t print:block">
            Generated by HustleOS AI — Built for African Entrepreneurs
          </div>
        </CardContent>
      </Card>

      {/* Payment Dialog */}
      <Dialog open={showPayment} onOpenChange={setShowPayment}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Record Payment</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Amount Due: {fmt(invoice.amountDue, invoice.currency)}</Label>
            </div>
            <div>
              <Label htmlFor="amount">Payment Amount</Label>
              <Input
                id="amount"
                type="number"
                value={paymentAmount}
                onChange={(e) => setPaymentAmount(e.target.value)}
                placeholder="Enter amount"
                max={invoice.amountDue}
                min={0.01}
                step={0.01}
              />
            </div>
            <div>
              <Label htmlFor="method">Payment Method</Label>
              <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">Cash</SelectItem>
                  <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                  <SelectItem value="card">Card</SelectItem>
                  <SelectItem value="mobile_money">Mobile Money</SelectItem>
                  <SelectItem value="cheque">Cheque</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="notes">Notes (optional)</Label>
              <Input
                id="notes"
                value={paymentNotes}
                onChange={(e) => setPaymentNotes(e.target.value)}
                placeholder="e.g. Bank reference number"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPayment(false)}>Cancel</Button>
            <Button onClick={handlePayment} disabled={!!acting}>
              {acting === "payment" ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
              Record Payment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* History Dialog */}
      <Dialog open={showHistory} onOpenChange={setShowHistory}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Invoice History</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 max-h-[400px] overflow-y-auto">
            {history.length === 0 ? (
              <p className="text-muted-foreground text-sm text-center py-4">No history found.</p>
            ) : (
              history.map((log) => (
                <div key={log.id} className="flex items-start gap-3 text-sm py-2 border-b last:border-0">
                  <div className="w-2 h-2 rounded-full bg-primary mt-1.5 shrink-0" />
                  <div className="flex-1">
                    <p className="font-medium capitalize">{log.action.replace(/_/g, " ")}</p>
                    {log.changes && (
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {Object.entries(log.changes).map(([k, v]) => `${k}: ${v}`).join(", ")}
                      </p>
                    )}
                  </div>
                  <span className="text-xs text-muted-foreground shrink-0">{new Date(log.createdAt).toLocaleString()}</span>
                </div>
              ))
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowHistory(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
