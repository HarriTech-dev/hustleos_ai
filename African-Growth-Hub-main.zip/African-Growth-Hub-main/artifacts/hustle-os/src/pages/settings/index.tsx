import { useState, useEffect, useRef } from "react";
import { useGetMe, useUpdateProfile } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Skeleton } from "../../components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "../../components/ui/avatar";
import { Separator } from "../../components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import { useToast } from "../../hooks/use-toast";
import { useTheme } from "../../components/theme-provider";
import { User, Building2, Globe, Palette, Save, Loader2 } from "lucide-react";
import { useAuth } from "../../contexts/AuthContext";
import ImageUpload from "../../components/ImageUpload";

import { CURRENCY_LABELS, UNIQUE_CURRENCIES } from "../../lib/currencies";
import { COUNTRY_NAMES, COUNTRY_CURRENCY_MAP } from "../../lib/countries";

export default function Settings() {
  const { user } = useAuth();
  const { theme, setTheme } = useTheme();
  const { toast } = useToast();
  const { data: profile, isLoading } = useGetMe();
  const { mutateAsync: updateProfile, isPending: saving } = useUpdateProfile();
  const queryClient = useQueryClient();

  const [form, setForm] = useState({
    name: "",
    businessName: "",
    currency: "NGN",
    country: "Nigeria",
    phone: "",
    avatarUrl: "",
    businessLogo: "",
  });

  const initializedRef = useRef(false);
  useEffect(() => {
    if (profile && !initializedRef.current) {
      initializedRef.current = true;
      setForm({
        name: profile.name || "",
        businessName: profile.businessName || "",
        currency: profile.currency || "NGN",
        country: profile.country || "Nigeria",
        phone: profile.phone || "",
        avatarUrl: profile.avatarUrl || "",
        businessLogo: profile.businessLogo || "",
      });
    }
  }, [profile]);

  const handleSave = async () => {
    try {
      await updateProfile({ data: form });
      // Allow the form to re-sync with the freshly saved profile
      initializedRef.current = false;
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      queryClient.invalidateQueries({ queryKey: ["getMe"] });
      toast({ title: "Settings saved", description: "Your profile has been updated." });
    } catch (e: any) {
      const msg = e?.response?.data?.error || e?.message || "Failed to save settings.";
      toast({ variant: "destructive", title: "Error", description: msg });
    }
  };

  const set = (field: string, value: string) => setForm((f) => ({ ...f, [field]: value }));

  return (
    <div className="space-y-6 max-w-2xl">
      <div className="flex flex-col sm:flex-row items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Settings</h1>
          <p className="text-muted-foreground mt-1">Manage your account and business preferences.</p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <User className="h-4 w-4" /> Profile
          </CardTitle>
          <CardDescription>Your personal account information.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="flex items-center gap-4">
            <Avatar className="h-16 w-16">
              <AvatarImage src={form.avatarUrl || user?.user_metadata?.avatar_url} />
              <AvatarFallback className="bg-primary/10 text-primary text-xl font-bold">
                {form.name?.charAt(0).toUpperCase() || user?.email?.charAt(0).toUpperCase() || "U"}
              </AvatarFallback>
            </Avatar>
            <div>
              {isLoading ? <Skeleton className="h-5 w-32 mb-1" /> : <p className="font-medium">{form.name || "—"}</p>}
              <p className="text-sm text-muted-foreground">{user?.email}</p>
            </div>
          </div>
          <Separator />
          {isLoading ? (
            <div className="space-y-4">
              {Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}
            </div>
          ) : (
            <div className="grid gap-4">
              <div className="grid gap-2">
                <Label>Profile Photo</Label>
                <ImageUpload
                  value={form.avatarUrl || null}
                  onChange={(url) => set("avatarUrl", url || "")}
                  folder="avatars"
                  maxSizeMB={2}
                  description="JPG or PNG, max 2 MB"
                  shape="circle"
                  className="max-w-[160px]"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="name">Full Name</Label>
                <Input id="name" value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="Your full name" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input id="phone" value={form.phone} onChange={(e) => set("phone", e.target.value)} placeholder="+234 800 000 0000" />
              </div>
              <div className="grid gap-2">
                <Label>Email</Label>
                <Input value={user?.email || ""} disabled className="opacity-60" />
                <p className="text-xs text-muted-foreground">Email cannot be changed here. Contact support.</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Building2 className="h-4 w-4" /> Business
          </CardTitle>
          <CardDescription>Your business details and preferences.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {isLoading ? (
            <div className="space-y-4">
              {Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}
            </div>
          ) : (
            <>
              <div className="grid gap-2">
                <Label>Business Logo</Label>
                <ImageUpload
                  value={form.businessLogo || null}
                  onChange={(url) => set("businessLogo", url || "")}
                  folder="business-logos"
                  maxSizeMB={3}
                  description="JPG or PNG, max 3 MB"
                  shape="rounded"
                  className="max-w-[200px]"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="businessName">Business Name</Label>
                <Input
                  id="businessName"
                  value={form.businessName}
                  onChange={(e) => set("businessName", e.target.value)}
                  placeholder="Acme Trading Co."
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label>Country</Label>
                  <Select value={form.country} onValueChange={(v) => {
                    const currency = COUNTRY_CURRENCY_MAP[v] || form.currency;
                    setForm({...form, country: v, currency});
                  }}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {COUNTRY_NAMES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label>Base Currency</Label>
                  <Select value={form.currency} onValueChange={(v) => set("currency", v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {UNIQUE_CURRENCIES.map((c) => <SelectItem key={c} value={c}>{CURRENCY_LABELS[c] ?? c}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Palette className="h-4 w-4" /> Appearance
          </CardTitle>
          <CardDescription>Customize the look of your HustleOS.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-3">
            {(["light", "dark", "system"] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTheme(t)}
                className={`flex-1 py-3 rounded-lg border text-sm font-medium capitalize transition-all ${
                  theme === t ? "border-primary bg-primary/10 text-primary" : "hover:bg-muted"
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={saving} className="gap-2 min-w-[140px]">
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          Save Changes
        </Button>
      </div>
    </div>
  );
}
