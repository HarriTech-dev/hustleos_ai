import { useState } from "react";
import { useGetDashboardSummary, useGetRevenueChart, useGetRecentActivity, useGetTopProducts, useGetAiInsights } from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/ui/card";
import { Badge } from "../../components/ui/badge";
import { Button } from "../../components/ui/button";
import { formatCurrency, formatCurrencyCompact, formatCountCompact } from "../../lib/format";
import { ArrowUpRight, ArrowDownRight, Package, Users, Receipt, TrendingUp, AlertTriangle, Sparkles, RefreshCw, ChevronRight } from "lucide-react";
import { Skeleton } from "../../components/ui/skeleton";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Link } from "wouter";

export default function Dashboard() {
  const { data: summary, isLoading: loadingSummary } = useGetDashboardSummary();
  const { data: revenueData, isLoading: loadingRevenue } = useGetRevenueChart();
  const { data: recentActivity, isLoading: loadingActivity } = useGetRecentActivity();
  const { data: topProducts, isLoading: loadingProducts } = useGetTopProducts();
  const { data: insights, isLoading: loadingInsights, refetch: refetchInsights, isFetching: fetchingInsights } = useGetAiInsights();

  const [insightsExpanded, setInsightsExpanded] = useState(false);
  const currency = summary?.currency || "USD";

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Overview</h1>
        <p className="text-muted-foreground mt-1">Here's what's happening with your business today.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {loadingSummary ? (
              <Skeleton className="h-8 w-[120px]" />
            ) : (
              <>
                <div className="text-2xl font-bold stat-num">{formatCurrencyCompact(summary?.totalRevenue || 0, currency)}</div>
                <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                  {(summary?.revenueGrowth || 0) >= 0 ? (
                    <span className="text-emerald-500 flex items-center"><ArrowUpRight className="h-3 w-3" /> {summary?.revenueGrowth}%</span>
                  ) : (
                    <span className="text-destructive flex items-center"><ArrowDownRight className="h-3 w-3" /> {Math.abs(summary?.revenueGrowth || 0)}%</span>
                  )}
                  from last month
                </p>
              </>
            )}
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Invoices</CardTitle>
            <Receipt className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {loadingSummary ? (
              <Skeleton className="h-8 w-[80px]" />
            ) : (
              <>
                <div className="text-2xl font-bold stat-num">{formatCountCompact(summary?.totalInvoices || 0)}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  <span className="text-destructive font-medium">{summary?.overdueInvoices || 0} overdue</span>
                </p>
              </>
            )}
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Customers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {loadingSummary ? (
              <Skeleton className="h-8 w-[80px]" />
            ) : (
              <div className="text-2xl font-bold stat-num">{formatCountCompact(summary?.totalCustomers || 0)}</div>
            )}
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Inventory Alerts</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {loadingSummary ? (
              <Skeleton className="h-8 w-[80px]" />
            ) : (
              <>
                <div className="text-2xl font-bold stat-num">{formatCountCompact(summary?.lowStockCount || 0)}</div>
                <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                  {(summary?.lowStockCount || 0) > 0 && <AlertTriangle className="h-3 w-3 text-amber-500" />}
                  Items running low
                </p>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* AI Insights Panel */}
      <Card className="border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                <Sparkles className="h-4 w-4 text-primary" />
              </div>
              <div>
                <CardTitle className="text-base">AI Business Insights</CardTitle>
                <CardDescription className="text-xs">Powered by GPT-4o-mini — updated based on your data</CardDescription>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="gap-1 text-xs h-7"
              onClick={() => refetchInsights()}
              disabled={fetchingInsights}
            >
              <RefreshCw className={`h-3 w-3 ${fetchingInsights ? "animate-spin" : ""}`} />
              Refresh
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {loadingInsights || fetchingInsights ? (
            <div className="space-y-2">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-4/5" />
              <Skeleton className="h-4 w-3/5" />
            </div>
          ) : insights && insights.length > 0 ? (
            <div className="space-y-2">
              {(insightsExpanded ? insights : insights.slice(0, 3)).map((insight) => (
                <div key={insight.id} className="flex items-start gap-2 text-sm">
                  <Badge
                    variant="outline"
                    className={`text-[10px] shrink-0 mt-0.5 ${
                      insight.type === "warning" ? "border-amber-400 text-amber-600" :
                      insight.type === "opportunity" ? "border-emerald-400 text-emerald-600" :
                      insight.type === "alert" ? "border-red-400 text-red-600" :
                      "border-blue-400 text-blue-600"
                    }`}
                  >
                    {insight.type}
                  </Badge>
                  <span className="text-muted-foreground leading-relaxed">
                    <span className="font-medium text-foreground">{insight.title}</span>
                    {" — "}
                    {insight.description}
                    {insight.actionLabel && insight.actionRoute && (
                      <Link href={insight.actionRoute} className="ml-1 text-primary hover:underline text-xs">
                        {insight.actionLabel} →
                      </Link>
                    )}
                  </span>
                </div>
              ))}
              {insights.length > 3 && (
                <Button variant="ghost" size="sm" className="h-6 text-xs gap-1 pl-0" onClick={() => setInsightsExpanded(v => !v)}>
                  {insightsExpanded ? "Show less" : `+${insights.length - 3} more insights`}
                  <ChevronRight className={`h-3 w-3 transition-transform ${insightsExpanded ? "rotate-90" : ""}`} />
                </Button>
              )}
            </div>
          ) : (
            <div className="text-center py-4">
              <p className="text-sm text-muted-foreground">No insights available yet. Add some transactions or invoices to get started.</p>
              <Button variant="outline" size="sm" className="mt-2 gap-1" asChild>
                <Link href="/ai">
                  <Sparkles className="h-3 w-3" /> Chat with AI Advisor
                </Link>
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid gap-4 sm:gap-6 grid-cols-1 lg:grid-cols-7">
        <Card className="lg:col-span-4">
          <CardHeader>
            <CardTitle>Revenue Over Time</CardTitle>
            <CardDescription>Monthly revenue performance for the past year</CardDescription>
          </CardHeader>
          <CardContent>
            {loadingRevenue ? (
              <div className="h-[300px] flex items-center justify-center">
                <Skeleton className="h-full w-full" />
              </div>
            ) : (
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={revenueData || []} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                    <XAxis 
                      dataKey="label" 
                      axisLine={false}
                      tickLine={false}
                      tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                      dy={10}
                    />
                    <YAxis 
                      axisLine={false}
                      tickLine={false}
                      tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                      tickFormatter={(value) => `$${value}`}
                    />
                    <Tooltip 
                      contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                      itemStyle={{ color: 'hsl(var(--foreground))' }}
                      formatter={(value: number) => [formatCurrency(value, currency), 'Revenue']}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="value" 
                      stroke="hsl(var(--primary))" 
                      strokeWidth={2}
                      fillOpacity={1} 
                      fill="url(#colorValue)" 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>
        
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest actions in your business</CardDescription>
          </CardHeader>
          <CardContent>
            {loadingActivity ? (
              <div className="space-y-4">
                {[1, 2, 3, 4].map(i => (
                  <div key={i} className="flex items-center gap-4">
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <div className="space-y-2">
                      <Skeleton className="h-4 w-[200px]" />
                      <Skeleton className="h-3 w-[100px]" />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-6">
                {(recentActivity || []).map((activity) => (
                  <div key={activity.id} className="flex items-start gap-4">
                    <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                      {activity.type === 'invoice_created' && <Receipt className="h-4 w-4 text-primary" />}
                      {activity.type === 'invoice_paid' && <TrendingUp className="h-4 w-4 text-emerald-500" />}
                      {activity.type === 'customer_added' && <Users className="h-4 w-4 text-blue-500" />}
                      {activity.type === 'stock_adjusted' && <Package className="h-4 w-4 text-amber-500" />}
                      {activity.type === 'payment_received' && <TrendingUp className="h-4 w-4 text-emerald-500" />}
                    </div>
                    <div className="flex-1 space-y-1">
                      <p className="text-sm font-medium leading-none">
                        {activity.title}
                        {activity.amount && (
                          <span className="ml-2 font-bold text-emerald-600">
                            +{formatCurrency(activity.amount, activity.currency || currency)}
                          </span>
                        )}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {activity.description}
                      </p>
                    </div>
                    <div className="text-xs text-muted-foreground whitespace-nowrap">
                      {new Date(activity.createdAt).toLocaleDateString()}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Top Products */}
      {(topProducts || []).length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Top Products</CardTitle>
            <CardDescription>Best-selling items this period</CardDescription>
          </CardHeader>
          <CardContent>
            {loadingProducts ? (
              <div className="space-y-3">
                {[1, 2, 3].map(i => <Skeleton key={i} className="h-8 w-full" />)}
              </div>
            ) : (
              <div className="space-y-3">
                {(topProducts || []).slice(0, 5).map((p, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <div className="h-7 w-7 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      <span className="text-xs font-bold text-primary">{i + 1}</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{p.name}</p>
                      <p className="text-xs text-muted-foreground">{p.unitsSold} units sold</p>
                    </div>
                    <div className="text-sm font-semibold text-emerald-600">{formatCurrency(p.revenue, currency)}</div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
