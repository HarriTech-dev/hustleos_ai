import { useState, useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useListSubscriptionPlans, useGetCurrentSubscription, useInitiateCheckout } from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Badge } from "../../components/ui/badge";
import { Skeleton } from "../../components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import {
  Check, Zap, Crown, Rocket, Building2, CreditCard, Calendar,
  AlertCircle, Lock, ArrowUpRight, Mail, CheckCircle2, XCircle,
  Globe, ChevronDown,
} from "lucide-react";
import { useToast } from "../../hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "../../components/ui/dialog";

/* ------------------------------------------------------------------ */
/*  Currency & pricing constants                                       */
/* ------------------------------------------------------------------ */

const CURRENCY_PRICES: Record<string, Record<string, number>> = {
  plan_pro: {
    NGN: 3000, XAF: 2500, XOF: 2500, GHS: 35, KES: 400,
    USD: 5, EUR: 4, GBP: 4, ZAR: 90, UGX: 18000, TZS: 12000,
    RWF: 5000, ETB: 280, MAD: 50, EGP: 150, ZMW: 110, MZN: 320,
  },
  plan_premium: {
    NGN: 8000, XAF: 5000, XOF: 5000, GHS: 90, KES: 1100,
    USD: 12, EUR: 10, GBP: 10, ZAR: 240, UGX: 45000, TZS: 32000,
    RWF: 13000, ETB: 750, MAD: 130, EGP: 400, ZMW: 290, MZN: 850,
  },
};

type CurrencyCode = keyof typeof CURRENCY_META;

const CURRENCY_META: Record<string, { symbol: string; name: string; flag: string }> = {
  NGN: { symbol: "₦",    name: "Nigerian Naira",          flag: "🇳🇬" },
  XAF: { symbol: "CFA",  name: "Central African CFA",     flag: "🌍" },
  XOF: { symbol: "CFA",  name: "West African CFA",        flag: "🌍" },
  GHS: { symbol: "GH₵",  name: "Ghanaian Cedi",           flag: "🇬🇭" },
  KES: { symbol: "KSh",  name: "Kenyan Shilling",         flag: "🇰🇪" },
  USD: { symbol: "$",    name: "US Dollar",               flag: "🇺🇸" },
  EUR: { symbol: "€",    name: "Euro",                    flag: "🇪🇺" },
  GBP: { symbol: "£",    name: "British Pound",           flag: "🇬🇧" },
  ZAR: { symbol: "R",    name: "South African Rand",      flag: "🇿🇦" },
  UGX: { symbol: "USh",  name: "Ugandan Shilling",        flag: "🇺🇬" },
  TZS: { symbol: "TSh",  name: "Tanzanian Shilling",      flag: "🇹🇿" },
  RWF: { symbol: "RF",   name: "Rwandan Franc",           flag: "🇷🇼" },
  ETB: { symbol: "Br",   name: "Ethiopian Birr",          flag: "🇪🇹" },
  MAD: { symbol: "د.م.", name: "Moroccan Dirham",         flag: "🇲🇦" },
  EGP: { symbol: "E£",   name: "Egyptian Pound",          flag: "🇪🇬" },
  ZMW: { symbol: "ZK",   name: "Zambian Kwacha",          flag: "🇿🇲" },
  MZN: { symbol: "MT",   name: "Mozambican Metical",      flag: "🇲🇿" },
};

const SUPPORTED_CURRENCIES = Object.keys(CURRENCY_META) as CurrencyCode[];

/** Currencies Paystack natively accepts (conservative list) */
const PAYSTACK_CURRENCIES = new Set(["NGN", "GHS", "USD", "ZAR", "KES"]);

/** Country code → currency code */
const COUNTRY_CURRENCY: Record<string, string> = {
  NG: "NGN", GH: "GHS", ZA: "ZAR", KE: "KES",
  CM: "XAF", CF: "XAF", TD: "XAF", GA: "XAF", GQ: "XAF", CG: "XAF",
  SN: "XOF", CI: "XOF", ML: "XOF", BF: "XOF", NE: "XOF", BJ: "XOF", TG: "XOF",
  UG: "UGX", TZ: "TZS", RW: "RWF", ET: "ETB",
  MA: "MAD", EG: "EGP", ZM: "ZMW", MZ: "MZN",
  US: "USD", CA: "USD", AU: "USD",
  GB: "GBP",
  FR: "EUR", DE: "EUR", IT: "EUR", ES: "EUR", NL: "EUR", BE: "EUR", PT: "EUR",
};

function formatLocalPrice(amount: number, currency: string): string {
  const meta = CURRENCY_META[currency];
  const symbol = meta?.symbol ?? currency;
  const formatted = Number.isInteger(amount)
    ? amount.toLocaleString("en-US")
    : amount.toFixed(2);
  return `${symbol}${formatted}`;
}

function getLocalPrice(planId: string, basePriceNGN: number, currency: string): number {
  return CURRENCY_PRICES[planId]?.[currency] ?? basePriceNGN;
}

/* ------------------------------------------------------------------ */
/*  Geo-detection hook                                                 */
/* ------------------------------------------------------------------ */

interface GeoInfo {
  countryCode: string;
  countryName: string;
  currency: string;
}

function useGeoDetection() {
  const [geo, setGeo] = useState<GeoInfo | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    fetch("https://ipapi.co/json/", { signal: AbortSignal.timeout(4000) })
      .then((r) => r.json())
      .then((d: any) => {
        if (cancelled) return;
        const countryCode: string = d.country_code ?? "";
        const currency: string =
          COUNTRY_CURRENCY[countryCode] ?? d.currency ?? "NGN";
        setGeo({
          countryCode,
          countryName: d.country_name ?? countryCode,
          currency: CURRENCY_META[currency] ? currency : "NGN",
        });
      })
      .catch(() => {
        if (!cancelled) setGeo({ countryCode: "NG", countryName: "Nigeria", currency: "NGN" });
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => { cancelled = true; };
  }, []);

  return { geo, loading };
}

/* ------------------------------------------------------------------ */
/*  Plan display constants                                             */
/* ------------------------------------------------------------------ */

const PLAN_ICONS: Record<string, React.ElementType> = {
  plan_free: Zap, plan_pro: Rocket, plan_premium: Crown, plan_enterprise: Building2,
};
const PLAN_COLORS: Record<string, string> = {
  plan_free: "from-slate-500 to-slate-600",
  plan_pro: "from-orange-500 to-amber-500",
  plan_premium: "from-purple-600 to-indigo-600",
  plan_enterprise: "from-emerald-500 to-teal-600",
};
const PLAN_BORDERS: Record<string, string> = {
  plan_free: "border-slate-200 dark:border-slate-800",
  plan_pro: "border-orange-200 dark:border-orange-900/50",
  plan_premium: "border-purple-200 dark:border-purple-900/50",
  plan_enterprise: "border-emerald-200 dark:border-emerald-900/50",
};
const PLAN_IDEAL_FOR: Record<string, string> = {
  plan_free: "Students, Side Hustlers, New Businesses",
  plan_pro: "Growing Businesses",
  plan_premium: "Established SMEs",
  plan_enterprise: "Schools, Churches, Large Businesses",
};

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */

export default function Billing() {
  const [checkoutPlanId, setCheckoutPlanId] = useState<string | null>(null);
  const [showCheckout, setShowCheckout] = useState(false);
  const [showEnterprise, setShowEnterprise] = useState(false);
  const [showCurrencyPicker, setShowCurrencyPicker] = useState(false);
  const [selectedCurrency, setSelectedCurrency] = useState<string>("NGN");
  const [paymentResult, setPaymentResult] = useState<{
    status: "success" | "failed";
    plan?: string;
    reason?: string;
  } | null>(null);

  const queryClient = useQueryClient();
  const { geo, loading: geoLoading } = useGeoDetection();
  const { data: plans, isLoading: loadingPlans } = useListSubscriptionPlans();
  const { data: currentSub, isLoading: loadingSub } = useGetCurrentSubscription();
  const { mutateAsync: initiateCheckout, isPending: checkingOut } = useInitiateCheckout();
  const { toast } = useToast();

  // Apply detected currency once geo loads
  useEffect(() => {
    if (geo?.currency) setSelectedCurrency(geo.currency);
  }, [geo?.currency]);

  // Handle return from gateway
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const payment = params.get("payment");
    const plan = params.get("plan") ?? undefined;
    const reason = params.get("reason") ?? undefined;

    if (payment === "success") {
      setPaymentResult({ status: "success", plan });
      queryClient.invalidateQueries({ queryKey: ["/api/subscriptions/current"] });
      queryClient.invalidateQueries({ queryKey: ["subscription-plan"] });
      window.history.replaceState({}, "", window.location.pathname);
    } else if (payment === "failed") {
      setPaymentResult({ status: "failed", reason });
      window.history.replaceState({}, "", window.location.pathname);
    } else {
      queryClient.invalidateQueries({ queryKey: ["/api/subscriptions/current"] });
    }
  }, [queryClient]);

  const selectedPlan = plans?.find((p) => p.id === checkoutPlanId);
  const localPrice = selectedPlan
    ? getLocalPrice(selectedPlan.id, selectedPlan.price, selectedCurrency)
    : 0;

  const currencyMeta = CURRENCY_META[selectedCurrency];
  const paystackSupported = PAYSTACK_CURRENCIES.has(selectedCurrency);

  const handleSubscribe = async (planId: string, provider: "paystack" | "flutterwave") => {
    try {
      const result = await initiateCheckout({ data: { planId, provider, currency: selectedCurrency } });
      if (result.checkoutUrl) {
        window.location.href = result.checkoutUrl;
      } else {
        toast({
          variant: "destructive",
          title: "Payment Error",
          description: "Could not get payment link. Please try a different provider.",
        });
      }
      setShowCheckout(false);
    } catch (err: any) {
      const msg = err?.response?.data?.error || err?.message || "Failed to initiate checkout. Please try again.";
      toast({ variant: "destructive", title: "Payment Error", description: msg });
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Billing & Plans</h1>
          <p className="text-muted-foreground mt-1">Manage your subscription and upgrade your plan.</p>
        </div>
        {/* Currency selector */}
        <button
          className="flex items-center gap-2 rounded-lg border px-3 py-2 text-sm hover:bg-muted transition-colors"
          onClick={() => setShowCurrencyPicker(true)}
        >
          <Globe className="h-4 w-4 text-muted-foreground" />
          {geoLoading ? (
            <Skeleton className="h-4 w-24 inline-block" />
          ) : (
            <>
              <span>{currencyMeta?.flag} {selectedCurrency}</span>
              <ChevronDown className="h-3 w-3 text-muted-foreground" />
            </>
          )}
        </button>
      </div>

      {/* Payment result banner */}
      {paymentResult && (
        <Card className={paymentResult.status === "success"
          ? "border-emerald-200 bg-emerald-50 dark:bg-emerald-950/20"
          : "border-red-200 bg-red-50 dark:bg-red-950/20"
        }>
          <CardContent className="p-4 flex items-center gap-3">
            {paymentResult.status === "success" ? (
              <>
                <CheckCircle2 className="h-5 w-5 text-emerald-600 shrink-0" />
                <div>
                  <p className="text-sm font-medium text-emerald-800 dark:text-emerald-300">
                    Payment successful! You are now on the {paymentResult.plan ? <strong>{paymentResult.plan}</strong> : "upgraded"} plan.
                  </p>
                  <p className="text-xs text-emerald-700 dark:text-emerald-400 mt-0.5">
                    Your features have been unlocked. Refresh if you don&apos;t see changes immediately.
                  </p>
                </div>
              </>
            ) : (
              <>
                <XCircle className="h-5 w-5 text-red-600 shrink-0" />
                <div>
                  <p className="text-sm font-medium text-red-800 dark:text-red-300">
                    Payment could not be verified.
                  </p>
                  {paymentResult.reason && (
                    <p className="text-xs text-red-700 dark:text-red-400 mt-0.5">{paymentResult.reason}</p>
                  )}
                  <p className="text-xs text-red-700 dark:text-red-400 mt-0.5">
                    If you were charged, contact support with your reference number.
                  </p>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      )}

      {/* Current subscription */}
      {loadingSub ? (
        <Card><CardContent className="p-6"><Skeleton className="h-24 w-full" /></CardContent></Card>
      ) : currentSub ? (
        <Card className="border-primary/30 bg-primary/5">
          <CardHeader>
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="h-5 w-5 text-primary" />
                  Current Plan: {currentSub.planName}
                </CardTitle>
                <CardDescription className="mt-1">
                  <Badge variant={currentSub.status === "active" ? "default" : "destructive"}>
                    {currentSub.status}
                  </Badge>
                </CardDescription>
              </div>
              {currentSub.currentPeriodEnd && (
                <div className="text-right text-sm text-muted-foreground">
                  <div className="flex items-center gap-1 justify-end">
                    <Calendar className="h-3 w-3" />
                    Renews {new Date(currentSub.currentPeriodEnd).toLocaleDateString()}
                  </div>
                </div>
              )}
            </div>
          </CardHeader>
        </Card>
      ) : (
        <Card className="border-amber-200 bg-amber-50 dark:bg-amber-950/20">
          <CardContent className="p-4 flex items-center gap-3">
            <AlertCircle className="h-5 w-5 text-amber-600 shrink-0" />
            <p className="text-sm text-amber-800 dark:text-amber-300">
              You are on the Free plan. Upgrade to unlock more features.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Plans grid */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Choose a Plan</h2>
          {!geoLoading && geo && (
            <p className="text-xs text-muted-foreground">
              {currencyMeta?.flag} Prices shown in {currencyMeta?.name ?? selectedCurrency} for {geo.countryName}
            </p>
          )}
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4 items-stretch">
          {loadingPlans
            ? Array(4).fill(0).map((_, i) => (
                <div key={i} className="flex flex-col">
                  <Skeleton className="h-full min-h-[420px] w-full rounded-xl" />
                </div>
              ))
            : (plans || []).map((plan) => {
                const Icon = PLAN_ICONS[plan.id] || Zap;
                const gradient = PLAN_COLORS[plan.id] || "from-slate-500 to-slate-600";
                const border = PLAN_BORDERS[plan.id] || "border-slate-200";
                const isCurrent = currentSub?.planId === plan.id;
                const isEnterprise = plan.id === "plan_enterprise";
                const isFree = plan.price === 0 && !isEnterprise;
                const planLocalPrice = getLocalPrice(plan.id, plan.price, selectedCurrency);

                return (
                  <Card
                    key={plan.id}
                    className={`relative flex flex-col overflow-hidden transition-all ${border} ${plan.isPopular ? "border-primary shadow-lg shadow-primary/10 md:scale-[1.02]" : "hover:shadow-md"}`}
                  >
                    {plan.isPopular && (
                      <div className="absolute top-0 right-0 left-0 h-1 bg-gradient-to-r from-orange-500 to-amber-400" />
                    )}
                    <CardHeader className="pb-3 flex-shrink-0">
                      <div className="flex items-start justify-between">
                        <div className={`h-9 w-9 rounded-xl bg-gradient-to-br ${gradient} flex items-center justify-center`}>
                          <Icon className="h-4 w-4 text-white" />
                        </div>
                        {plan.isPopular && (
                          <Badge className="bg-gradient-to-r from-orange-500 to-amber-500 text-white border-0 text-xs shrink-0">
                            Most Popular
                          </Badge>
                        )}
                      </div>
                      <CardTitle className="text-lg mt-2">{plan.name}</CardTitle>
                      <p className="text-xs text-muted-foreground">{PLAN_IDEAL_FOR[plan.id] || ""}</p>
                      <div className="mt-2 min-w-0">
                        <div className="flex flex-wrap items-baseline gap-x-1 gap-y-0.5">
                          <span className="text-base sm:text-lg md:text-xl font-bold leading-tight">
                            {isEnterprise
                              ? "Custom"
                              : isFree
                              ? "Free"
                              : formatLocalPrice(planLocalPrice, selectedCurrency)}
                          </span>
                          {!isFree && !isEnterprise && (
                            <span className="text-muted-foreground text-[10px] sm:text-xs">/month</span>
                          )}
                        </div>
                        {/* Show NGN equivalent for non-NGN currencies */}
                        {!isFree && !isEnterprise && selectedCurrency !== "NGN" && plan.price > 0 && (
                          <p className="text-[10px] text-muted-foreground mt-0.5">
                            ≈ ₦{plan.price.toLocaleString()}/month in Nigeria
                          </p>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent className="flex flex-col flex-grow gap-3 pt-0">
                      <ul className="space-y-2 flex-grow">
                        {(plan.features || []).map((feature) => (
                          <li key={feature} className="flex items-start gap-2 text-xs leading-relaxed">
                            <Check className="h-3.5 w-3.5 text-emerald-500 mt-0.5 shrink-0" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                      <div className="mt-auto pt-2">
                        {isCurrent ? (
                          <Button className="w-full" variant="outline" disabled>
                            <Lock className="h-4 w-4 mr-1" />
                            Current Plan
                          </Button>
                        ) : isEnterprise ? (
                          <Button
                            className="w-full"
                            variant="outline"
                            onClick={() => setShowEnterprise(true)}
                          >
                            <Mail className="h-4 w-4 mr-1" />
                            Contact Us
                          </Button>
                        ) : isFree ? (
                          <Button className="w-full" variant="outline" disabled>
                            Free Forever
                          </Button>
                        ) : (
                          <Button
                            className="w-full"
                            variant={plan.isPopular ? "default" : "outline"}
                            onClick={() => {
                              setCheckoutPlanId(plan.id);
                              setShowCheckout(true);
                            }}
                          >
                            <ArrowUpRight className="h-4 w-4 mr-1" />
                            Upgrade Now
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
        </div>
      </div>

      {/* Payment method dialog */}
      <Dialog open={showCheckout} onOpenChange={setShowCheckout}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>
              Subscribe to {selectedPlan?.name ?? "Plan"}
            </DialogTitle>
            <DialogDescription>
              You will be redirected to a secure payment page. Your subscription activates automatically after payment.
            </DialogDescription>
          </DialogHeader>

          {/* Currency selector inside dialog */}
          <div className="rounded-lg border bg-muted/40 p-3 space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="flex items-center gap-1.5 text-muted-foreground">
                <Globe className="h-3.5 w-3.5" />
                Billing currency
              </span>
              {geoLoading ? (
                <Skeleton className="h-4 w-28" />
              ) : (
                <span className="text-xs text-muted-foreground">{geo?.countryName}</span>
              )}
            </div>
            <Select value={selectedCurrency} onValueChange={setSelectedCurrency}>
              <SelectTrigger className="h-9 text-sm">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="max-h-60">
                {SUPPORTED_CURRENCIES.map((c) => (
                  <SelectItem key={c} value={c}>
                    {CURRENCY_META[c].flag} {CURRENCY_META[c].name} ({c})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Localized price */}
          {selectedPlan && (
            <div className="text-center py-1">
              <p className="text-3xl font-bold">{formatLocalPrice(localPrice, selectedCurrency)}</p>
              <p className="text-xs text-muted-foreground">per month · {selectedPlan.name}</p>
            </div>
          )}

          {/* Gateway buttons */}
          <div className="space-y-3 pt-1">
            {/* Paystack */}
            <Button
              className="w-full h-[60px] flex-col gap-0.5"
              onClick={() => handleSubscribe(checkoutPlanId!, "paystack")}
              disabled={checkingOut || !paystackSupported}
              variant={paystackSupported ? "default" : "outline"}
            >
              <span className="font-bold">Paystack</span>
              <span className="text-[11px] opacity-75">
                {paystackSupported
                  ? "Cards · Bank Transfer · USSD"
                  : `${selectedCurrency} not supported by Paystack`}
              </span>
            </Button>

            {/* Flutterwave */}
            <Button
              variant="outline"
              className="w-full h-[60px] flex-col gap-0.5 border-2"
              onClick={() => handleSubscribe(checkoutPlanId!, "flutterwave")}
              disabled={checkingOut}
            >
              <span className="font-bold">Flutterwave</span>
              <span className="text-[11px] opacity-75">
                Cards · Mobile Money · Bank · M-Pesa · USSD
              </span>
            </Button>

            {!paystackSupported && (
              <p className="text-[11px] text-center text-amber-600 dark:text-amber-400">
                For {currencyMeta?.name ?? selectedCurrency} payments, use Flutterwave.
              </p>
            )}

            <p className="text-xs text-center text-muted-foreground pt-1">
              Secure checkout — your card details are never shared with HustleOS.
            </p>
          </div>
        </DialogContent>
      </Dialog>

      {/* Currency picker dialog */}
      <Dialog open={showCurrencyPicker} onOpenChange={setShowCurrencyPicker}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Select Your Currency</DialogTitle>
            <DialogDescription>
              Choose your preferred currency to see localized pricing.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-1 max-h-72 overflow-y-auto pr-1">
            {SUPPORTED_CURRENCIES.map((c) => {
              const m = CURRENCY_META[c];
              return (
                <button
                  key={c}
                  className={`w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm hover:bg-muted transition-colors text-left ${selectedCurrency === c ? "bg-muted font-medium" : ""}`}
                  onClick={() => {
                    setSelectedCurrency(c);
                    setShowCurrencyPicker(false);
                  }}
                >
                  <span className="text-base">{m.flag}</span>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium">{m.name}</p>
                    <p className="text-xs text-muted-foreground">{c}</p>
                  </div>
                  {selectedCurrency === c && (
                    <Check className="h-4 w-4 text-primary shrink-0" />
                  )}
                </button>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>

      {/* Enterprise dialog */}
      <Dialog open={showEnterprise} onOpenChange={setShowEnterprise}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Enterprise Plan</DialogTitle>
            <DialogDescription>
              Custom pricing for schools, churches, and large businesses.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 pt-2">
            <p className="text-sm text-muted-foreground">
              Contact us for a custom quote tailored to your organization.
            </p>
            <Button className="w-full" variant="outline" asChild>
              <a href="mailto:enterprise@hustleos.ai">
                <Mail className="h-4 w-4 mr-1" />
                Email Us
              </a>
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
