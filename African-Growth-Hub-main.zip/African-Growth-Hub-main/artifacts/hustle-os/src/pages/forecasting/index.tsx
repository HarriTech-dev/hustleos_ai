import { useAuth } from "../../contexts/AuthContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/ui/card";
import { Skeleton } from "../../components/ui/skeleton";
import { Badge } from "../../components/ui/badge";
import { TrendingUp, TrendingDown, DollarSign, BarChart3, Zap, ArrowRight } from "lucide-react";
import { useState, useEffect } from "react";
import {
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Area,
  AreaChart,
} from "recharts";

interface HistoricalPoint {
  month: string;
  key: string;
  revenue: number;
  income: number;
  expenses: number;
  profit: number;
}

interface ForecastPoint {
  month: string;
  key: string;
  forecast: number;
}

interface ForecastData {
  historical: HistoricalPoint[];
  forecast: ForecastPoint[];
  summary: {
    avgMonthlyRevenue: number;
    totalRevenueLast6Months: number;
    growthRate: number;
    projectedNextMonth: number;
    currency: string;
  };
}

function fmt(amount: number, currency: string) {
  if (amount >= 1_000_000) return `${currency} ${(amount / 1_000_000).toFixed(1)}M`;
  if (amount >= 1_000) return `${currency} ${(amount / 1_000).toFixed(0)}K`;
  return `${currency} ${amount.toLocaleString()}`;
}

const COLORS = {
  revenue: "#c46c22",
  income: "#22c55e",
  expenses: "#ef4444",
  profit: "#3b82f6",
  forecast: "#a855f7",
};

export default function Forecasting() {
  const { session } = useAuth();
  const [data, setData] = useState<ForecastData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!session) return;
    fetch("/api/forecasting/revenue", {
      headers: { Authorization: `Bearer ${session.access_token}` },
    })
      .then((r) => r.json())
      .then((d) => { setData(d); setLoading(false); })
      .catch(() => setLoading(false));
  }, [session]);

  if (loading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Forecasting</h1>
          <p className="text-muted-foreground mt-1">AI-powered revenue and profit projections.</p>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {Array(4).fill(0).map((_, i) => <Skeleton key={i} className="h-28" />)}
        </div>
        <Skeleton className="h-80" />
      </div>
    );
  }

  if (!data) {
    return (
      <div className="text-center py-20 text-muted-foreground">Failed to load forecasting data.</div>
    );
  }

  const { summary, historical, forecast } = data;
  const chartData = [
    ...historical.map((h) => ({ ...h, type: "historical" })),
    ...forecast.map((f) => ({ month: f.month, key: f.key, revenue: 0, income: 0, expenses: 0, profit: 0, forecast: f.forecast, type: "forecast" })),
  ];

  const summaryCards = [
    {
      label: "Avg Monthly Revenue",
      value: fmt(summary.avgMonthlyRevenue, summary.currency),
      icon: DollarSign,
      color: "text-primary",
      bg: "bg-primary/10",
    },
    {
      label: "6-Month Total",
      value: fmt(summary.totalRevenueLast6Months, summary.currency),
      icon: BarChart3,
      color: "text-blue-600",
      bg: "bg-blue-50 dark:bg-blue-900/20",
    },
    {
      label: "Growth Rate",
      value: `${summary.growthRate > 0 ? "+" : ""}${summary.growthRate}%`,
      icon: summary.growthRate >= 0 ? TrendingUp : TrendingDown,
      color: summary.growthRate >= 0 ? "text-green-600" : "text-red-600",
      bg: summary.growthRate >= 0 ? "bg-green-50 dark:bg-green-900/20" : "bg-red-50 dark:bg-red-900/20",
    },
    {
      label: "Next Month Forecast",
      value: fmt(summary.projectedNextMonth, summary.currency),
      icon: Zap,
      color: "text-purple-600",
      bg: "bg-purple-50 dark:bg-purple-900/20",
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Forecasting</h1>
          <p className="text-muted-foreground mt-1">AI-powered revenue and profit projections for your business.</p>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {summaryCards.map((c) => (
          <Card key={c.label}>
            <CardContent className="pt-5 pb-4">
              <div className={`inline-flex p-2 rounded-lg ${c.bg} mb-3`}>
                <c.icon className={`h-5 w-5 ${c.color}`} />
              </div>
              <p className={`text-xl font-bold ${c.color}`}>{c.value}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{c.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Revenue & Expense Trends</CardTitle>
          <CardDescription>Last 6 months actuals + 3 month forecast</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={320}>
            <ComposedChart data={chartData} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis
                tick={{ fontSize: 11 }}
                stroke="hsl(var(--muted-foreground))"
                tickFormatter={(v) => fmt(v, "")}
              />
              <Tooltip
                formatter={(value: number, name: string) => [fmt(value, summary.currency), name]}
                contentStyle={{ background: "hsl(var(--background))", border: "1px solid hsl(var(--border))", borderRadius: 8 }}
              />
              <Legend />
              <Bar dataKey="revenue" name="Revenue" fill={COLORS.revenue} radius={[3, 3, 0, 0]} maxBarSize={40} />
              <Bar dataKey="expenses" name="Expenses" fill={COLORS.expenses} radius={[3, 3, 0, 0]} maxBarSize={40} />
              <Line dataKey="profit" name="Profit" type="monotone" stroke={COLORS.profit} strokeWidth={2} dot={false} />
              <Line
                dataKey="forecast"
                name="Forecast"
                type="monotone"
                stroke={COLORS.forecast}
                strokeWidth={2.5}
                strokeDasharray="6 3"
                dot={{ fill: COLORS.forecast, r: 4 }}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>3-Month Revenue Forecast</CardTitle>
          <CardDescription>Projected based on historical growth rate</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={forecast} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
              <defs>
                <linearGradient id="forecastGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={COLORS.forecast} stopOpacity={0.3} />
                  <stop offset="95%" stopColor={COLORS.forecast} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis
                tick={{ fontSize: 11 }}
                stroke="hsl(var(--muted-foreground))"
                tickFormatter={(v) => fmt(v, "")}
              />
              <Tooltip
                formatter={(value: number) => [fmt(value, summary.currency), "Projected Revenue"]}
                contentStyle={{ background: "hsl(var(--background))", border: "1px solid hsl(var(--border))", borderRadius: 8 }}
              />
              <Area type="monotone" dataKey="forecast" stroke={COLORS.forecast} fill="url(#forecastGrad)" strokeWidth={2.5} />
            </AreaChart>
          </ResponsiveContainer>

          <div className="mt-4 grid grid-cols-3 gap-3">
            {forecast.map((f, i) => (
              <div key={f.key} className="text-center p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                <p className="text-xs font-medium text-purple-700 dark:text-purple-300">{f.month}</p>
                <p className="text-lg font-bold text-purple-900 dark:text-purple-100 mt-0.5">{fmt(f.forecast, summary.currency)}</p>
                <Badge variant="secondary" className="text-xs mt-1">Month +{i + 1}</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="border-amber-200 dark:border-amber-800/40 bg-amber-50/50 dark:bg-amber-900/10">
        <CardContent className="pt-5 pb-4">
          <div className="flex items-start gap-3">
            <Zap className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-sm text-amber-900 dark:text-amber-200">Forecast Methodology</p>
              <p className="text-xs text-amber-700 dark:text-amber-300/80 mt-1 leading-relaxed">
                Projections use trend-based forecasting from your last 6 months of invoice payments and recorded transactions.
                Growth rate is clamped between -30% and +50% monthly to prevent extreme outliers.
                Add more transactions and paid invoices for more accurate predictions.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
