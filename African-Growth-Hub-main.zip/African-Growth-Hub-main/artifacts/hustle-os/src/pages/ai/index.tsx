import { useState, useRef, useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useAiChat, useListAiConversations, useGetAiInsights } from "@workspace/api-client-react";
import { Button } from "../../components/ui/button";
import { Textarea } from "../../components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Badge } from "../../components/ui/badge";
import { Skeleton } from "../../components/ui/skeleton";
import { ScrollArea } from "../../components/ui/scroll-area";
import { Bot, Send, Loader2, Sparkles, AlertTriangle, TrendingUp, Lightbulb, MessageSquare, Plus, ChevronRight, Megaphone } from "lucide-react";
import { Link } from "wouter";
import { cn } from "../../lib/utils";
import { useToast } from "../../hooks/use-toast";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt: string;
}

const STARTER_PROMPTS = [
  "How can I improve my cash flow this month?",
  "What's the best way to follow up on overdue invoices?",
  "Give me tips for pricing my products in Nigeria",
  "How do I grow my customer base in Africa?",
  "Should I accept mobile money payments?",
  "How can I reduce my business expenses?",
];

function InsightIcon({ type }: { type: string }) {
  if (type === "alert") return <AlertTriangle className="h-4 w-4 text-destructive" />;
  if (type === "warning") return <AlertTriangle className="h-4 w-4 text-amber-500" />;
  if (type === "opportunity") return <TrendingUp className="h-4 w-4 text-emerald-500" />;
  return <Lightbulb className="h-4 w-4 text-primary" />;
}

function MessageBubble({ message }: { message: Message }) {
  const isUser = message.role === "user";
  return (
    <div className={cn("flex gap-3 mb-4", isUser && "flex-row-reverse")}>
      <div className={cn(
        "h-8 w-8 rounded-full flex items-center justify-center shrink-0",
        isUser ? "bg-primary text-primary-foreground" : "bg-sidebar-accent text-primary"
      )}>
        {isUser ? (
          <span className="text-xs font-bold">You</span>
        ) : (
          <Bot className="h-4 w-4" />
        )}
      </div>
      <div className={cn(
        "max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed",
        isUser
          ? "bg-primary text-primary-foreground rounded-tr-sm"
          : "bg-muted rounded-tl-sm"
      )}>
        {message.content.split("\n").map((line, i) => (
          <span key={i}>
            {line}
            {i < message.content.split("\n").length - 1 && <br />}
          </span>
        ))}
      </div>
    </div>
  );
}

export default function AIAdvisor() {
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [suggestedActions, setSuggestedActions] = useState<string[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: conversations, isLoading: loadingConversations } = useListAiConversations();
  const { data: insights, isLoading: loadingInsights } = useGetAiInsights();
  const { mutateAsync: sendMessage, isPending: sending } = useAiChat();

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async (text?: string) => {
    const messageText = text || input.trim();
    if (!messageText || sending) return;
    setInput("");

    const userMsg: Message = {
      id: crypto.randomUUID(),
      role: "user",
      content: messageText,
      createdAt: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, userMsg]);

    try {
      const result = await sendMessage({ data: { message: messageText, conversationId } });
      setConversationId(result.conversationId ?? null);
      setSuggestedActions(result.suggestedActions ?? []);
      const assistantMsg: Message = {
        id: crypto.randomUUID(),
        role: "assistant",
        content: result.reply,
        createdAt: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, assistantMsg]);
      // Refresh conversation list so new conversation appears in sidebar
      queryClient.invalidateQueries({ queryKey: ["/api/ai/conversations"] });
    } catch (err: any) {
      const msg = err?.message || "Failed to get AI response. Please try again.";
      toast({ variant: "destructive", title: "AI Error", description: msg });
      const errMsg: Message = {
        id: crypto.randomUUID(),
        role: "assistant",
        content: "Sorry, I couldn't connect right now. Please try again.",
        createdAt: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, errMsg]);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const startNewConversation = () => {
    setConversationId(null);
    setMessages([]);
    setSuggestedActions([]);
    setInput("");
  };

  const loadConversation = (conv: { id: string; messages: Message[] }) => {
    setConversationId(conv.id);
    setMessages(conv.messages);
    setSuggestedActions([]);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">AI Business Advisor</h1>
          <p className="text-muted-foreground mt-1">Get expert advice tailored for African entrepreneurs.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" asChild className="gap-2 hidden sm:flex">
            <Link href="/ai/marketing">
              <Megaphone className="h-4 w-4" /> Marketing Generator
            </Link>
          </Button>
          <Button variant="outline" onClick={startNewConversation} className="gap-2 hidden sm:flex">
            <Plus className="h-4 w-4" /> New Chat
          </Button>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-primary" /> Business Insights
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {loadingInsights ? (
                Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-16 w-full rounded-lg" />)
              ) : (
                (insights || []).map((insight) => (
                  <div
                    key={insight.id}
                    className="flex gap-2 p-3 rounded-lg border bg-muted/30 cursor-pointer hover:bg-muted/60 transition-colors"
                    onClick={() => insight.actionRoute && handleSend(`Tell me more about: ${insight.title}`)}
                  >
                    <InsightIcon type={insight.type} />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium truncate">{insight.title}</p>
                      <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{insight.description}</p>
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <MessageSquare className="h-4 w-4 text-primary" /> Recent Chats
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-1">
              {loadingConversations ? (
                Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-9 w-full" />)
              ) : (conversations || []).length === 0 ? (
                <p className="text-xs text-muted-foreground py-2">No conversations yet</p>
              ) : (
                (conversations || []).slice(0, 8).map((conv) => (
                  <button
                    key={conv.id}
                    onClick={() => loadConversation(conv as { id: string; messages: Message[] })}
                    className={cn(
                      "w-full text-left px-3 py-2 text-xs rounded-md transition-colors flex items-center gap-2",
                      conv.id === conversationId
                        ? "bg-primary/10 text-primary font-medium"
                        : "hover:bg-muted text-muted-foreground"
                    )}
                  >
                    <MessageSquare className="h-3 w-3 shrink-0" />
                    <span className="truncate">{conv.title}</span>
                  </button>
                ))
              )}
            </CardContent>
          </Card>
        </div>

        <Card className="flex flex-col" style={{ minHeight: "600px" }}>
          <ScrollArea className="flex-1 p-6">
            {messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full py-16 text-center space-y-6">
                <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
                  <Bot className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Ask your AI Business Advisor</h3>
                  <p className="text-muted-foreground text-sm mt-1 max-w-xs">
                    Expert advice tailored for African entrepreneurs — pricing, cash flow, customers, growth.
                  </p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 w-full max-w-lg">
                  {STARTER_PROMPTS.map((prompt) => (
                    <button
                      key={prompt}
                      onClick={() => handleSend(prompt)}
                      className="text-left text-xs p-3 rounded-lg border bg-muted/30 hover:bg-muted transition-colors flex items-center justify-between gap-2 group"
                    >
                      <span>{prompt}</span>
                      <ChevronRight className="h-3 w-3 shrink-0 text-muted-foreground group-hover:text-foreground" />
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                {messages.map((msg) => (
                  <MessageBubble key={msg.id} message={msg} />
                ))}
                {sending && (
                  <div className="flex gap-3 mb-4">
                    <div className="h-8 w-8 rounded-full bg-sidebar-accent flex items-center justify-center shrink-0">
                      <Bot className="h-4 w-4 text-primary" />
                    </div>
                    <div className="bg-muted rounded-2xl rounded-tl-sm px-4 py-3 flex items-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">Thinking...</span>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>
            )}
          </ScrollArea>

          {suggestedActions.length > 0 && (
            <div className="px-4 pb-2 flex flex-wrap gap-2">
              {suggestedActions.map((action) => (
                <button
                  key={action}
                  onClick={() => handleSend(action)}
                  className="text-xs px-3 py-1.5 rounded-full border bg-muted/50 hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
                >
                  {action}
                </button>
              ))}
            </div>
          )}

          <div className="p-4 border-t">
            <div className="flex gap-2 items-end">
              <Textarea
                ref={textareaRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask anything about your business... (Enter to send, Shift+Enter for new line)"
                className="min-h-[60px] max-h-[160px] resize-none text-sm"
                disabled={sending}
              />
              <Button
                onClick={() => handleSend()}
                disabled={!input.trim() || sending}
                size="icon"
                className="h-[60px] w-[60px] shrink-0"
              >
                {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
              </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-2 text-center">
              AI advice is for guidance only. Always verify important decisions.
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
}
