import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Textarea } from "../../components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import { Skeleton } from "../../components/ui/skeleton";
import { Badge } from "../../components/ui/badge";
import { Separator } from "../../components/ui/separator";
import { useToast } from "../../hooks/use-toast";
import { useAuth } from "../../contexts/AuthContext";
import {
  Megaphone, Copy, RefreshCw, Sparkles, Wand2, ChevronRight, History,
  Trash2, CheckCheck, MessageCircle, Instagram, Mail, Tag,
  Tv2, Smartphone, Gift, TrendingUp, Users, Store, ArrowLeft
} from "lucide-react";
import { Link } from "wouter";
import { cn } from "../../lib/utils";

const TEMPLATES = [
  { id: "facebook-ad",       name: "Facebook Ad",         icon: Tv2,            color: "bg-blue-500/10 text-blue-600",   desc: "Stop the scroll" },
  { id: "whatsapp-broadcast", name: "WhatsApp Broadcast",  icon: MessageCircle,  color: "bg-green-500/10 text-green-600", desc: "Personal & warm" },
  { id: "instagram-caption", name: "Instagram Caption",   icon: Instagram,       color: "bg-pink-500/10 text-pink-600",   desc: "With hashtags" },
  { id: "product-description",name: "Product Description", icon: Tag,            color: "bg-amber-500/10 text-amber-600", desc: "Sell benefits" },
  { id: "flyer-copy",        name: "Flyer Copy",          icon: Megaphone,       color: "bg-orange-500/10 text-orange-600",desc: "Print-ready" },
  { id: "sms-blast",         name: "SMS Blast",           icon: Smartphone,      color: "bg-purple-500/10 text-purple-600",desc: "160 chars max" },
  { id: "email-newsletter",  name: "Email Newsletter",    icon: Mail,            color: "bg-sky-500/10 text-sky-600",     desc: "With subject line" },
  { id: "holiday-campaign",  name: "Holiday Campaign",    icon: Gift,            color: "bg-red-500/10 text-red-600",     desc: "Festive & warm" },
  { id: "sales-campaign",    name: "Sales Campaign",      icon: TrendingUp,      color: "bg-emerald-500/10 text-emerald-600",desc: "Urgency & scarcity" },
  { id: "customer-win-back", name: "Win-Back Message",    icon: Users,           color: "bg-violet-500/10 text-violet-600",desc: "Re-engage customers" },
  { id: "referral-program",  name: "Referral Program",    icon: ChevronRight,    color: "bg-teal-500/10 text-teal-600",   desc: "Grow by sharing" },
  { id: "grand-opening",     name: "Grand Opening",       icon: Store,           color: "bg-yellow-500/10 text-yellow-600",desc: "Launch with a bang" },
];

const TONES = [
  { value: "Friendly and Professional",  emoji: "😊" },
  { value: "Bold and Aggressive",        emoji: "💥" },
  { value: "Warm and Personal",          emoji: "🤝" },
  { value: "Luxury and Premium",         emoji: "✨" },
  { value: "Fun and Playful",            emoji: "🎉" },
  { value: "Urgent and Scarcity",        emoji: "⏰" },
  { value: "Inspirational and Motivating", emoji: "🚀" },
  { value: "Trust and Authority",        emoji: "💎" },
];

interface GeneratedCopy {
  id: string;
  type: string;
  templateName: string;
  content: string;
  variations: string[];
  businessType: string;
  product: string;
  createdAt: string;
}

const HISTORY_KEY = "hustle_marketing_history";

function loadHistory(): GeneratedCopy[] {
  try {
    return JSON.parse(localStorage.getItem(HISTORY_KEY) ?? "[]");
  } catch {
    return [];
  }
}

function saveToHistory(item: GeneratedCopy) {
  const history = loadHistory();
  const updated = [item, ...history].slice(0, 20);
  localStorage.setItem(HISTORY_KEY, JSON.stringify(updated));
}

export default function AIMarketingGenerator() {
  const { toast } = useToast();
  const { session } = useAuth();

  const [step, setStep] = useState<"template" | "form">("template");
  const [template, setTemplate] = useState("facebook-ad");
  const [businessType, setBusinessType] = useState("");
  const [product, setProduct] = useState("");
  const [audience, setAudience] = useState("");
  const [tone, setTone] = useState("Friendly and Professional");
  const [extraInfo, setExtraInfo] = useState("");
  const [variations, setVariations] = useState<1 | 2 | 3>(1);

  const [result, setResult] = useState<GeneratedCopy | null>(null);
  const [activeVariation, setActiveVariation] = useState(0);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const [history, setHistory] = useState<GeneratedCopy[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  useEffect(() => {
    setHistory(loadHistory());
  }, []);

  const selectedTemplate = TEMPLATES.find((t) => t.id === template)!;

  const generate = async () => {
    if (!session) {
      toast({ variant: "destructive", title: "Not logged in" });
      return;
    }
    setLoading(true);
    setResult(null);
    setActiveVariation(0);
    try {
      const res = await fetch("/api/ai/marketing", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ type: template, businessType, product, audience, tone, extraInfo, variations }),
      });
      const data = await res.json();
      if (!res.ok || data.error) throw new Error(data.error || "Failed to generate");

      const item: GeneratedCopy = {
        id: Date.now().toString(),
        type: data.type,
        templateName: data.templateName,
        content: data.content,
        variations: data.variations ?? [data.content],
        businessType: businessType || "Business",
        product: product || "",
        createdAt: data.createdAt,
      };
      setResult(item);
      saveToHistory(item);
      setHistory(loadHistory());
      setStep("form");
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Failed to generate";
      toast({ variant: "destructive", title: "Generation failed", description: msg });
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = async (text: string) => {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    toast({ title: "Copied to clipboard! ✓" });
    setTimeout(() => setCopied(false), 2000);
  };

  const currentText = result?.variations[activeVariation] ?? result?.content ?? "";
  const charCount = currentText.length;

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Link href="/ai">
              <Button variant="ghost" size="sm" className="gap-1.5 h-7 px-2 text-muted-foreground hover:text-foreground">
                <ArrowLeft className="h-3.5 w-3.5" /> AI Advisor
              </Button>
            </Link>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight flex items-center gap-2">
            <span className="h-9 w-9 rounded-xl bg-primary/10 flex items-center justify-center">
              <Megaphone className="h-5 w-5 text-primary" />
            </span>
            AI Marketing Generator
          </h1>
          <p className="text-muted-foreground mt-1">Create scroll-stopping marketing copy for your African business in seconds.</p>
        </div>
        <Button
          variant="outline"
          size="sm"
          className="gap-2 shrink-0"
          onClick={() => setShowHistory(!showHistory)}
        >
          <History className="h-4 w-4" />
          History {history.length > 0 && <Badge variant="secondary" className="ml-0.5 h-4 px-1 text-[10px]">{history.length}</Badge>}
        </Button>
      </div>

      {/* History Panel */}
      {showHistory && (
        <Card className="border-dashed">
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <CardTitle className="text-sm">Recent Generations</CardTitle>
            {history.length > 0 && (
              <Button
                variant="ghost"
                size="sm"
                className="h-7 gap-1.5 text-muted-foreground hover:text-destructive"
                onClick={() => { localStorage.removeItem(HISTORY_KEY); setHistory([]); }}
              >
                <Trash2 className="h-3.5 w-3.5" /> Clear
              </Button>
            )}
          </CardHeader>
          <CardContent>
            {history.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">No history yet. Generate your first copy below.</p>
            ) : (
              <div className="space-y-2">
                {history.map((h) => (
                  <div
                    key={h.id}
                    className="flex items-start gap-3 p-3 rounded-lg border hover:bg-muted/40 cursor-pointer transition-colors"
                    onClick={() => {
                      setResult(h);
                      setActiveVariation(0);
                      setTemplate(h.type);
                      setShowHistory(false);
                      setStep("form");
                    }}
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-medium text-primary">{h.templateName}</span>
                        <span className="text-xs text-muted-foreground">·</span>
                        <span className="text-xs text-muted-foreground">{h.businessType}</span>
                      </div>
                      <p className="text-xs text-muted-foreground line-clamp-2">{h.content}</p>
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <div className="grid gap-6 lg:grid-cols-[1fr_1fr]">
        {/* Left: Inputs */}
        <div className="space-y-4">
          {/* Template Picker */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <Wand2 className="h-4 w-4 text-primary" /> Choose Template
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-2">
                {TEMPLATES.map((t) => {
                  const Icon = t.icon;
                  const isSelected = template === t.id;
                  return (
                    <button
                      key={t.id}
                      onClick={() => setTemplate(t.id)}
                      className={cn(
                        "flex items-start gap-2.5 p-3 rounded-lg border text-left transition-all",
                        isSelected
                          ? "border-primary bg-primary/5 shadow-sm"
                          : "border-border hover:border-primary/40 hover:bg-muted/40"
                      )}
                    >
                      <span className={cn("h-7 w-7 rounded-md flex items-center justify-center shrink-0 mt-0.5", t.color)}>
                        <Icon className="h-3.5 w-3.5" />
                      </span>
                      <div className="min-w-0">
                        <p className={cn("text-xs font-semibold leading-tight", isSelected ? "text-primary" : "")}>{t.name}</p>
                        <p className="text-[10px] text-muted-foreground mt-0.5">{t.desc}</p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Form Fields */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-primary" /> Business Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs">Business Type</Label>
                  <Input
                    value={businessType}
                    onChange={(e) => setBusinessType(e.target.value)}
                    placeholder="e.g. Fashion retail"
                    className="h-9"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Product / Service</Label>
                  <Input
                    value={product}
                    onChange={(e) => setProduct(e.target.value)}
                    placeholder="e.g. Ankara dresses"
                    className="h-9"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs">Target Audience</Label>
                <Input
                  value={audience}
                  onChange={(e) => setAudience(e.target.value)}
                  placeholder="e.g. Young professionals in Lagos aged 25–35"
                  className="h-9"
                />
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs">Tone / Voice</Label>
                <Select value={tone} onValueChange={setTone}>
                  <SelectTrigger className="h-9">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {TONES.map((t) => (
                      <SelectItem key={t.value} value={t.value}>
                        {t.emoji} {t.value}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs">Offer / Extra Info <span className="text-muted-foreground">(optional)</span></Label>
                <Textarea
                  value={extraInfo}
                  onChange={(e) => setExtraInfo(e.target.value)}
                  placeholder="e.g. 30% off this weekend, free delivery above ₦10,000, limited stock"
                  className="resize-none h-20 text-sm"
                />
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs">Variations to generate</Label>
                <div className="flex gap-2">
                  {([1, 2, 3] as const).map((n) => (
                    <button
                      key={n}
                      onClick={() => setVariations(n)}
                      className={cn(
                        "flex-1 h-9 rounded-md border text-sm font-medium transition-all",
                        variations === n
                          ? "border-primary bg-primary text-primary-foreground"
                          : "border-border hover:border-primary/40"
                      )}
                    >
                      {n === 1 ? "1 version" : `${n} versions`}
                    </button>
                  ))}
                </div>
              </div>

              <Button
                onClick={generate}
                disabled={loading}
                className="w-full gap-2 h-10"
              >
                {loading
                  ? <><RefreshCw className="h-4 w-4 animate-spin" /> Generating…</>
                  : <><Sparkles className="h-4 w-4" /> Generate Copy</>
                }
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Right: Output */}
        <div className="flex flex-col">
          <Card className="flex-1 flex flex-col">
            <CardHeader className="pb-3 flex flex-row items-center justify-between">
              <CardTitle className="text-sm flex items-center gap-2">
                {result ? (
                  <>
                    <span className={cn("h-6 w-6 rounded-md flex items-center justify-center", selectedTemplate.color)}>
                      {(() => { const Icon = selectedTemplate.icon; return <Icon className="h-3 w-3" />; })()}
                    </span>
                    {result.templateName}
                  </>
                ) : (
                  <><Megaphone className="h-4 w-4 text-primary" /> Generated Copy</>
                )}
              </CardTitle>
              {result && (
                <span className="text-xs text-muted-foreground">{charCount} chars</span>
              )}
            </CardHeader>

            <CardContent className="flex-1 flex flex-col">
              {loading ? (
                <div className="space-y-3 py-2">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-5/6" />
                  <Skeleton className="h-4 w-4/6" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-4 w-5/6" />
                </div>
              ) : result ? (
                <div className="flex-1 flex flex-col gap-4">
                  {/* Variation Tabs */}
                  {result.variations.length > 1 && (
                    <div className="flex gap-1.5">
                      {result.variations.map((_, i) => (
                        <button
                          key={i}
                          onClick={() => setActiveVariation(i)}
                          className={cn(
                            "px-3 py-1 rounded-md text-xs font-medium transition-all",
                            activeVariation === i
                              ? "bg-primary text-primary-foreground"
                              : "bg-muted hover:bg-muted/80 text-muted-foreground"
                          )}
                        >
                          Version {i + 1}
                        </button>
                      ))}
                    </div>
                  )}

                  {/* Copy Content */}
                  <div className="flex-1 bg-muted/30 rounded-xl p-4 text-sm leading-relaxed whitespace-pre-wrap border min-h-[200px]">
                    {currentText}
                  </div>

                  {/* Actions */}
                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant="default"
                      size="sm"
                      className="gap-2"
                      onClick={() => copyToClipboard(currentText)}
                    >
                      {copied ? <CheckCheck className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      {copied ? "Copied!" : "Copy"}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-2"
                      onClick={generate}
                      disabled={loading}
                    >
                      <RefreshCw className="h-4 w-4" /> Regenerate
                    </Button>
                    {result.type === "whatsapp-broadcast" && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-2 text-green-600 border-green-200 hover:bg-green-50"
                        onClick={() => window.open(`https://wa.me/?text=${encodeURIComponent(currentText)}`, "_blank")}
                      >
                        <MessageCircle className="h-4 w-4" /> Open in WhatsApp
                      </Button>
                    )}
                  </div>

                  <Separator />

                  {/* Quick tip per template */}
                  <div className="bg-primary/5 rounded-lg p-3 text-xs text-muted-foreground leading-relaxed">
                    <span className="font-semibold text-foreground">💡 Pro tip: </span>
                    {result.type === "facebook-ad" && "Test 2–3 variations with ₦500–₦1,000/day budget before scaling the winner."}
                    {result.type === "whatsapp-broadcast" && "Send between 10am–12pm or 6pm–8pm for best open rates on WhatsApp."}
                    {result.type === "instagram-caption" && "Post at 7am, 11am or 7pm when Nigerian Instagram users are most active."}
                    {result.type === "product-description" && "Add a real customer review alongside this description to 3x conversions."}
                    {result.type === "flyer-copy" && "Use a QR code on your flyer that links to your WhatsApp or payment link."}
                    {result.type === "sms-blast" && "Keep a gap of at least 2 weeks between SMS blasts to avoid unsubscribes."}
                    {result.type === "email-newsletter" && "Personalise the subject line with the customer's first name to boost opens by 26%."}
                    {result.type === "holiday-campaign" && "Start holiday campaigns 1–2 weeks before the date — people plan early."}
                    {result.type === "sales-campaign" && "Use real deadlines (e.g. 'ends Sunday midnight') — fake countdowns reduce trust."}
                    {result.type === "customer-win-back" && "Offer something tangible (free delivery, discount) in your win-back message."}
                    {result.type === "referral-program" && "Make the referral reward instant — cash or discount on next purchase works best."}
                    {result.type === "grand-opening" && "Combine with a door prize or lucky draw to drive foot traffic on opening day."}
                  </div>
                </div>
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-center py-16 px-4">
                  <div className="h-16 w-16 rounded-2xl bg-primary/8 flex items-center justify-center mb-4">
                    <Megaphone className="h-8 w-8 text-primary/60" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-1">Ready to create</h3>
                  <p className="text-sm text-muted-foreground max-w-[240px]">
                    Pick a template, fill in your business details, and hit Generate.
                  </p>
                  <div className="mt-6 grid grid-cols-3 gap-2 w-full max-w-[280px]">
                    {TEMPLATES.slice(0, 6).map((t) => {
                      const Icon = t.icon;
                      return (
                        <button
                          key={t.id}
                          onClick={() => setTemplate(t.id)}
                          className={cn(
                            "flex flex-col items-center gap-1.5 p-2.5 rounded-lg border text-center transition-all hover:border-primary/40 hover:bg-muted/40",
                            template === t.id && "border-primary bg-primary/5"
                          )}
                        >
                          <span className={cn("h-7 w-7 rounded-md flex items-center justify-center", t.color)}>
                            <Icon className="h-3.5 w-3.5" />
                          </span>
                          <span className="text-[9px] font-medium leading-tight text-muted-foreground">{t.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
