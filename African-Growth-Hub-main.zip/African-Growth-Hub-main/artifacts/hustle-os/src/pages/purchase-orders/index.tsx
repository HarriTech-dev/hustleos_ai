import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../../components/ui/table";
import { formatCurrency, formatDate } from "../../lib/format";
import { Plus, Search } from "lucide-react";
import { Skeleton } from "../../components/ui/skeleton";
import { useAuth } from "../../contexts/AuthContext";

interface PO {
  id: string;
  poNumber: string;
  supplierName: string;
  status: string;
  total: number;
  currency: string;
  expectedDate: string | null;
  createdAt: string;
}

const STATUS_BADGE: Record<string, string> = {
  draft: "bg-muted text-muted-foreground",
  sent: "bg-blue-100 text-blue-800",
  approved: "bg-green-100 text-green-800",
  partial: "bg-amber-100 text-amber-800",
  received: "bg-purple-100 text-purple-800",
  cancelled: "bg-red-100 text-red-800",
};

export default function PurchaseOrdersList() {
  const [search, setSearch] = useState("");
  const [orders, setOrders] = useState<PO[]>([]);
  const [loading, setLoading] = useState(true);
  const { session } = useAuth();

  useEffect(() => {
    if (!session) return;
    setLoading(true);
    fetch(`/api/purchase-orders${search ? `?search=${encodeURIComponent(search)}` : ""}`, {
      headers: { Authorization: `Bearer ${session.access_token}` },
    })
      .then((r) => r.json())
      .then((data) => {
        setOrders(Array.isArray(data) ? data : []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [session, search]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Purchase Orders</h1>
          <p className="text-muted-foreground mt-1">Manage supplier orders and track deliveries.</p>
        </div>
        <Link href="/purchase-orders/new">
          <Button className="gap-2"><Plus className="h-4 w-4" /> New PO</Button>
        </Link>
      </div>

      <div className="rounded-lg border bg-card">
        <div className="p-4 border-b flex items-center gap-4">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search supplier or PO #..."
              className="pl-8"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>PO #</TableHead>
                <TableHead>Supplier</TableHead>
                <TableHead>Expected</TableHead>
                <TableHead className="text-right">Amount</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                Array(5).fill(0).map((_, i) => (
                  <TableRow key={i}>
                    <TableCell><Skeleton className="h-5 w-[100px]" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-[150px]" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-[100px]" /></TableCell>
                    <TableCell className="text-right"><Skeleton className="h-5 w-[80px] ml-auto" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-[60px]" /></TableCell>
                  </TableRow>
                ))
              ) : orders.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-10 text-muted-foreground">
                    No purchase orders found. Create your first PO.
                  </TableCell>
                </TableRow>
              ) : (
                orders.map((o) => (
                  <TableRow key={o.id} className="cursor-pointer hover:bg-muted/50">
                    <TableCell className="font-medium text-primary hover:underline">
                      <Link href={`/purchase-orders/${o.id}`}>{o.poNumber}</Link>
                    </TableCell>
                    <TableCell>{o.supplierName}</TableCell>
                    <TableCell className="text-muted-foreground">{o.expectedDate ? formatDate(o.expectedDate) : "—"}</TableCell>
                    <TableCell className="text-right font-medium">{formatCurrency(o.total, o.currency)}</TableCell>
                    <TableCell>
                      <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium ${STATUS_BADGE[o.status] ?? "bg-muted text-muted-foreground"}`}>
                        {o.status.toUpperCase()}
                      </span>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}
