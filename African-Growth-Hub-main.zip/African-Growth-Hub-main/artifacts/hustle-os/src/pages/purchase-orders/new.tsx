import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "../../contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Textarea } from "../../components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import { Separator } from "../../components/ui/separator";
import { useToast } from "../../hooks/use-toast";
import { formatCurrency } from "../../lib/format";
import { Plus, Trash2, ArrowLeft, Loader2, Receipt } from "lucide-react";
import { Link } from "wouter";

interface LineItem {
  name: string;
  description: string;
  quantity: number;
  unitPrice: number;
}

import { CURRENCY_LABELS, UNIQUE_CURRENCIES } from "../../lib/currencies";

const TAX_RATES = [0, 5, 7.5, 10, 15, 20];

function newItem(): LineItem {
  return { name: "", description: "", quantity: 1, unitPrice: 0 };
}

export default function NewPurchaseOrder() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { session } = useAuth();

  const [supplierName, setSupplierName] = useState("");
  const [supplierEmail, setSupplierEmail] = useState("");
  const [supplierPhone, setSupplierPhone] = useState("");
  const [currency, setCurrency] = useState("NGN");
  const [taxRate, setTaxRate] = useState(0);
  const [expectedDate, setExpectedDate] = useState("");
  const [notes, setNotes] = useState("");
  const [items, setItems] = useState<LineItem[]>([newItem()]);
  const [creating, setCreating] = useState(false);

  const subtotal = items.reduce((s, i) => s + i.quantity * i.unitPrice, 0);
  const tax = subtotal * (taxRate / 100);
  const total = subtotal + tax;

  const setItem = (index: number, field: keyof LineItem, value: string | number) => {
    setItems((prev) => prev.map((item, i) => i === index ? { ...item, [field]: value } : item));
  };
  const removeItem = (index: number) => {
    if (items.length === 1) return;
    setItems((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async () => {
    if (!supplierName) { toast({ variant: "destructive", title: "Enter supplier name" }); return; }
    if (items.some((i) => !i.name || i.quantity <= 0)) { toast({ variant: "destructive", title: "Fill all line items" }); return; }

    setCreating(true);
    try {
      const r = await fetch("/api/purchase-orders", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({
          supplierName,
          supplierEmail: supplierEmail || undefined,
          supplierPhone: supplierPhone || undefined,
          items: items.map((i) => ({ description: i.name + (i.description ? " - " + i.description : ""), quantity: i.quantity, unitPrice: i.unitPrice, total: i.quantity * i.unitPrice })),
          tax,
          currency,
          notes: notes || undefined,
          expectedDate: expectedDate || undefined,
        }),
      });
      const po = await r.json();
      toast({ title: "Purchase order created!" });
      navigate(`/purchase-orders/${po.id}`);
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Failed to create PO." });
    } finally {
      setCreating(false);
    }
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <div className="flex items-center gap-4">
        <Link href="/purchase-orders">
          <Button variant="ghost" size="icon" className="h-9 w-9"><ArrowLeft className="h-4 w-4" /></Button>
        </Link>
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight flex items-center gap-2">
            <Receipt className="h-6 w-6" /> New Purchase Order
          </h1>
          <p className="text-muted-foreground mt-1">Create a purchase order for your supplier.</p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-[1fr_280px]">
        <div className="space-y-6">
          <Card>
            <CardHeader><CardTitle className="text-base">Supplier</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-2">
                <Label>Supplier Name *</Label>
                <Input placeholder="e.g. ABC Supplies Ltd" value={supplierName} onChange={(e) => setSupplierName(e.target.value)} />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="grid gap-2"><Label>Email</Label><Input placeholder="supplier@example.com" value={supplierEmail} onChange={(e) => setSupplierEmail(e.target.value)} /></div>
                <div className="grid gap-2"><Label>Phone</Label><Input placeholder="+234..." value={supplierPhone} onChange={(e) => setSupplierPhone(e.target.value)} /></div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                <CardTitle className="text-base">Line Items</CardTitle>
                <Button variant="outline" size="sm" onClick={() => setItems((p) => [...p, newItem()])} className="gap-1 h-8">
                  <Plus className="h-3 w-3" /> Add Item
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {items.map((item, index) => (
                <div key={index} className="space-y-3 pb-4 border-b last:border-0 last:pb-0">
                  <div className="flex items-start gap-2">
                    <div className="flex-1 grid gap-2">
                      <Input placeholder="Item name *" value={item.name} onChange={(e) => setItem(index, "name", e.target.value)} />
                      <Input placeholder="Description (optional)" value={item.description} onChange={(e) => setItem(index, "description", e.target.value)} className="text-sm" />
                    </div>
                    <Button variant="ghost" size="icon" className="h-9 w-9 text-muted-foreground hover:text-destructive shrink-0" onClick={() => removeItem(index)} disabled={items.length === 1}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="grid gap-1"><Label className="text-xs">Qty</Label><Input type="number" min="1" value={item.quantity} onChange={(e) => setItem(index, "quantity", Number(e.target.value))} /></div>
                    <div className="grid gap-1"><Label className="text-xs">Unit Price ({currency})</Label><Input type="number" min="0" step="0.01" value={item.unitPrice} onChange={(e) => setItem(index, "unitPrice", Number(e.target.value))} /></div>
                    <div className="grid gap-1"><Label className="text-xs">Total</Label><div className="h-10 flex items-center px-3 rounded-md border bg-muted text-sm font-medium">{formatCurrency(item.quantity * item.unitPrice, currency)}</div></div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle className="text-base">Notes</CardTitle></CardHeader>
            <CardContent>
              <Textarea placeholder="Delivery instructions, terms, etc." value={notes} onChange={(e) => setNotes(e.target.value)} className="min-h-[80px]" />
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader><CardTitle className="text-base">Settings</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-2">
                <Label>Currency</Label>
                <Select value={currency} onValueChange={setCurrency}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{UNIQUE_CURRENCIES.map((c) => <SelectItem key={c} value={c}>{CURRENCY_LABELS[c] ?? c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label>Expected Date</Label>
                <Input type="date" value={expectedDate} onChange={(e) => setExpectedDate(e.target.value)} />
              </div>
              <div className="grid gap-2">
                <Label>Tax Rate (%)</Label>
                <Select value={String(taxRate)} onValueChange={(v) => setTaxRate(Number(v))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{TAX_RATES.map((r) => <SelectItem key={r} value={String(r)}>{r}%</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle className="text-base">Summary</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between text-sm"><span className="text-muted-foreground">Subtotal</span><span>{formatCurrency(subtotal, currency)}</span></div>
              {taxRate > 0 && <div className="flex justify-between text-sm"><span className="text-muted-foreground">Tax ({taxRate}%)</span><span>{formatCurrency(tax, currency)}</span></div>}
              <Separator />
              <div className="flex justify-between font-bold text-lg"><span>Total</span><span className="text-primary">{formatCurrency(total, currency)}</span></div>
            </CardContent>
          </Card>

          <div className="space-y-2">
            <Button className="w-full gap-2" onClick={handleSubmit} disabled={creating}>
              {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : null} Create Purchase Order
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
