import { useParams, useLocation } from "wouter";
import { useAuth } from "../../contexts/AuthContext";
import { Button } from "../../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Separator } from "../../components/ui/separator";
import { Skeleton } from "../../components/ui/skeleton";
import { useToast } from "../../hooks/use-toast";
import { ArrowLeft, Printer, Trash2, Loader2, CheckCircle, Package, TruckIcon } from "lucide-react";
import { useState, useEffect } from "react";

interface POItem {
  name: string;
  description?: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

interface PurchaseOrder {
  id: string;
  poNumber: string;
  supplierName: string;
  supplierEmail: string | null;
  supplierPhone: string | null;
  status: string;
  items: POItem[];
  subtotal: number;
  tax: number;
  total: number;
  currency: string;
  notes: string | null;
  expectedDate: string | null;
  createdAt: string;
}

const STATUS_COLORS: Record<string, string> = {
  draft: "bg-muted text-muted-foreground",
  sent: "bg-blue-100 text-blue-800",
  approved: "bg-green-100 text-green-800",
  partial: "bg-amber-100 text-amber-800",
  received: "bg-purple-100 text-purple-800",
  cancelled: "bg-red-100 text-red-800",
};

function fmt(amount: number, currency: string) {
  return new Intl.NumberFormat("en-NG", { style: "currency", currency, minimumFractionDigits: 2 }).format(amount);
}

export default function PurchaseOrderDetail() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { session } = useAuth();
  const { toast } = useToast();
  const [po, setPo] = useState<PurchaseOrder | null>(null);
  const [loading, setLoading] = useState(true);
  const [acting, setActing] = useState<string | null>(null);

  const authHeaders = { Authorization: `Bearer ${session?.access_token}`, "Content-Type": "application/json" };

  useEffect(() => {
    if (!id || !session) return;
    fetch(`/api/purchase-orders/${id}`, { headers: authHeaders })
      .then((r) => r.json())
      .then((data) => { setPo(data); setLoading(false); })
      .catch(() => setLoading(false));
  }, [id, session]);

  const doAction = async (action: string) => {
    if (!po) return;
    setActing(action);
    try {
      if (action === "delete") {
        await fetch(`/api/purchase-orders/${id}`, { method: "DELETE", headers: authHeaders });
        toast({ title: "Purchase order deleted" });
        navigate("/purchase-orders");
        return;
      }
      const r = await fetch(`/api/purchase-orders/${id}`, { method: "PATCH", headers: authHeaders, body: JSON.stringify({ status: action }) });
      const updated = await r.json();
      setPo(updated);
      toast({ title: `Status updated to ${action}` });
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Action failed." });
    } finally {
      setActing(null);
    }
  };

  // Special handler for receiving stock — uses the /receive endpoint which triggers the transaction engine
  const receiveStock = async () => {
    if (!po) return;
    setActing("receive");
    try {
      const r = await fetch(`/api/purchase-orders/${id}/receive`, { method: "POST", headers: authHeaders });
      if (!r.ok) {
        const err = await r.json().catch(() => ({ error: "Failed to receive stock" }));
        toast({ variant: "destructive", title: "Error", description: err.error });
        return;
      }
      const updated = await r.json();
      setPo(updated);
      toast({
        title: "Stock received!",
        description: `Inventory updated for ${po.items.length} item(s). Expense transaction recorded.`,
      });
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Failed to receive stock." });
    } finally {
      setActing(null);
    }
  };

  const printPO = () => window.print();

  if (loading) return <div className="space-y-6 max-w-3xl mx-auto"><Skeleton className="h-8 w-48" /><Skeleton className="h-64 w-full" /></div>;
  if (!po) return <div className="text-center py-20"><p className="text-muted-foreground">Purchase order not found.</p><Button variant="ghost" onClick={() => navigate("/purchase-orders")} className="mt-4 gap-2"><ArrowLeft className="h-4 w-4" /> Back</Button></div>;

  const canReceive = po.status === "approved" || po.status === "sent" || po.status === "partial";

  return (
    <div className="space-y-6 max-w-3xl mx-auto print:max-w-full">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 print:hidden">
        <Button variant="ghost" onClick={() => navigate("/purchase-orders")} className="gap-2 -ml-2"><ArrowLeft className="h-4 w-4" /> Purchase Orders</Button>
        <div className="flex gap-2 flex-wrap">
          {po.status === "draft" && (
            <Button size="sm" variant="outline" onClick={() => doAction("sent")} disabled={!!acting} className="gap-1.5">
              {acting === "sent" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Package className="h-3.5 w-3.5" />} Send
            </Button>
          )}
          {po.status === "sent" && (
            <Button size="sm" variant="outline" onClick={() => doAction("approved")} disabled={!!acting} className="gap-1.5">
              <CheckCircle className="h-3.5 w-3.5" /> Approve
            </Button>
          )}
          {canReceive && (
            <Button
              size="sm"
              variant="default"
              onClick={receiveStock}
              disabled={!!acting}
              className="gap-1.5 bg-green-600 hover:bg-green-700 text-white"
            >
              {acting === "receive" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <TruckIcon className="h-3.5 w-3.5" />}
              Receive Stock
            </Button>
          )}
          <Button size="sm" variant="outline" onClick={printPO} className="gap-1.5"><Printer className="h-3.5 w-3.5" /> Print</Button>
          <Button size="sm" variant="destructive" onClick={() => doAction("delete")} disabled={!!acting} className="gap-1.5">
            {acting === "delete" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />} Delete
          </Button>
        </div>
      </div>

      {canReceive && (
        <div className="rounded-lg border border-green-200 bg-green-50 px-4 py-3 flex items-center gap-3 text-sm text-green-800 print:hidden">
          <TruckIcon className="h-4 w-4 shrink-0" />
          <span>Click <strong>Receive Stock</strong> when goods arrive — it will automatically update your inventory and record the expense.</span>
        </div>
      )}

      {po.status === "received" && (
        <div className="rounded-lg border border-purple-200 bg-purple-50 px-4 py-3 flex items-center gap-3 text-sm text-purple-800 print:hidden">
          <CheckCircle className="h-4 w-4 shrink-0" />
          <span>This order has been received. Inventory and expenses have been updated automatically.</span>
        </div>
      )}

      <Card className="print:shadow-none print:border-0">
        <CardHeader className="pb-4">
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-primary font-bold text-xl mb-1">
                <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground text-sm font-bold">H</div>
                HustleOS
              </div>
              <p className="text-sm text-muted-foreground">Business Management Platform</p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-primary">{po.poNumber}</p>
              <span className={`inline-block mt-1 px-2.5 py-0.5 rounded-full text-xs font-medium ${STATUS_COLORS[po.status]}`}>
                {po.status.toUpperCase()}
              </span>
            </div>
          </div>
        </CardHeader>
        <Separator />
        <CardContent className="pt-6 space-y-6">
          <div className="grid grid-cols-2 gap-6">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Supplier</p>
              <p className="font-semibold text-base">{po.supplierName}</p>
              {po.supplierEmail && <p className="text-sm text-muted-foreground">{po.supplierEmail}</p>}
              {po.supplierPhone && <p className="text-sm text-muted-foreground">{po.supplierPhone}</p>}
            </div>
            <div className="text-right">
              <div className="space-y-1">
                <div><p className="text-xs text-muted-foreground">Order Date</p><p className="font-medium text-sm">{new Date(po.createdAt).toLocaleDateString()}</p></div>
                {po.expectedDate && <div><p className="text-xs text-muted-foreground">Expected Delivery</p><p className="font-medium text-sm">{new Date(po.expectedDate).toLocaleDateString()}</p></div>}
              </div>
            </div>
          </div>
          <div className="rounded-lg border overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-muted/50"><tr><th className="text-left p-3 font-semibold">Item</th><th className="text-center p-3 font-semibold">Qty</th><th className="text-right p-3 font-semibold">Unit Price</th><th className="text-right p-3 font-semibold">Total</th></tr></thead>
              <tbody className="divide-y">
                {(po.items || []).map((item, i) => (
                  <tr key={i} className="hover:bg-muted/20">
                    <td className="p-3"><p className="font-medium">{item.name}</p>{item.description && <p className="text-xs text-muted-foreground">{item.description}</p>}</td>
                    <td className="p-3 text-center text-muted-foreground">{item.quantity}</td>
                    <td className="p-3 text-right text-muted-foreground">{fmt(item.unitPrice, po.currency)}</td>
                    <td className="p-3 text-right font-medium">{fmt(item.total, po.currency)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex justify-end">
            <div className="w-64 space-y-2">
              <div className="flex justify-between text-sm"><span className="text-muted-foreground">Subtotal</span><span>{fmt(po.subtotal, po.currency)}</span></div>
              {po.tax > 0 && <div className="flex justify-between text-sm"><span className="text-muted-foreground">Tax</span><span>{fmt(po.tax, po.currency)}</span></div>}
              <Separator />
              <div className="flex justify-between font-bold text-base"><span>Total</span><span className="text-primary">{fmt(po.total, po.currency)}</span></div>
            </div>
          </div>
          {po.notes && <div className="bg-muted/40 rounded-lg p-4"><p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1">Notes</p><p className="text-sm">{po.notes}</p></div>}
          <div className="text-center text-xs text-muted-foreground pt-2 border-t print:block">Generated by HustleOS AI — Built for African Entrepreneurs</div>
        </CardContent>
      </Card>
    </div>
  );
}
