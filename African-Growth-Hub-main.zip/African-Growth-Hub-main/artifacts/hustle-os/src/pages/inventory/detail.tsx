import { useParams, useLocation } from "wouter";
import { useAuth } from "../../contexts/AuthContext";
import { Button } from "../../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Skeleton } from "../../components/ui/skeleton";
import { Badge } from "../../components/ui/badge";
import { Separator } from "../../components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../../components/ui/dialog";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import { useToast } from "../../hooks/use-toast";
import { ArrowLeft, Package, TrendingUp, TrendingDown, AlertTriangle, Plus, Minus, Loader2, Trash2 } from "lucide-react";
import { useState, useEffect } from "react";

interface InventoryItem {
  id: string;
  name: string;
  sku: string;
  description?: string | null;
  quantity: number;
  lowStockThreshold: number;
  price: number;
  costPrice: number;
  category: string;
  unit: string;
  imageUrl?: string | null;
  currency: string;
  createdAt: string;
}

interface StockAdjustment {
  id: string;
  adjustment: number;
  reason: string;
  notes?: string | null;
  createdAt: string;
}

const REASONS = ["restock", "sale", "damage", "theft", "correction", "return"];

function fmt(amount: number, currency: string) {
  try {
    return new Intl.NumberFormat("en-NG", { style: "currency", currency, minimumFractionDigits: 0 }).format(amount);
  } catch {
    return `${currency} ${amount.toLocaleString()}`;
  }
}

export default function InventoryDetail() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { session } = useAuth();
  const { toast } = useToast();
  const [item, setItem] = useState<InventoryItem | null>(null);
  const [adjustments, setAdjustments] = useState<StockAdjustment[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdjust, setShowAdjust] = useState(false);
  const [adjustQty, setAdjustQty] = useState("0");
  const [reason, setReason] = useState("restock");
  const [adjustNotes, setAdjustNotes] = useState("");
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const authHeaders = { Authorization: `Bearer ${session?.access_token}`, "Content-Type": "application/json" };

  const fetchData = async () => {
    if (!id || !session) return;
    try {
      const [itemRes, adjRes] = await Promise.all([
        fetch(`/api/inventory/${id}`, { headers: authHeaders }),
        fetch(`/api/inventory/${id}/adjustments`, { headers: authHeaders }),
      ]);
      const [itemData, adjData] = await Promise.all([itemRes.json(), adjRes.json()]);
      setItem(itemData);
      setAdjustments(Array.isArray(adjData) ? adjData : []);
    } catch {
      /* handled below */
    } finally {
      setLoading(false);
    }
  };

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { fetchData(); }, [id, session?.access_token]);

  const handleAdjust = async () => {
    if (!item) return;
    setSaving(true);
    try {
      await fetch(`/api/inventory/${id}/adjust`, {
        method: "POST",
        headers: authHeaders,
        body: JSON.stringify({ adjustment: Number(adjustQty), reason, notes: adjustNotes }),
      });
      toast({ title: "Stock adjusted" });
      setShowAdjust(false);
      setAdjustQty("0");
      setAdjustNotes("");
      setLoading(true);
      fetchData();
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Failed to adjust stock." });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!confirm("Delete this inventory item?")) return;
    setDeleting(true);
    try {
      await fetch(`/api/inventory/${id}`, { method: "DELETE", headers: authHeaders });
      toast({ title: "Item deleted" });
      navigate("/inventory");
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Failed to delete item." });
      setDeleting(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6 max-w-2xl">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-48 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  if (!item) {
    return (
      <div className="text-center py-20">
        <p className="text-muted-foreground">Item not found.</p>
        <Button variant="ghost" onClick={() => navigate("/inventory")} className="mt-4 gap-2">
          <ArrowLeft className="h-4 w-4" /> Back
        </Button>
      </div>
    );
  }

  const isLowStock = item.quantity <= item.lowStockThreshold;
  const margin = item.costPrice > 0 ? ((item.price - item.costPrice) / item.price) * 100 : null;
  const stockValue = item.price * item.quantity;

  return (
    <div className="space-y-6 max-w-2xl">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <Button variant="ghost" onClick={() => navigate("/inventory")} className="gap-2 -ml-2 shrink-0">
          <ArrowLeft className="h-4 w-4" /> Inventory
        </Button>
        <div className="flex gap-2 flex-wrap">
          <Button size="sm" variant="outline" onClick={() => setShowAdjust(true)} className="gap-1.5">
            <Package className="h-3.5 w-3.5" /> Adjust Stock
          </Button>
          <Button size="sm" variant="destructive" onClick={handleDelete} disabled={deleting} className="gap-1.5">
            {deleting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
            Delete
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="flex items-start gap-4">
            {item.imageUrl ? (
              <img src={item.imageUrl} alt={item.name} className="h-20 w-20 rounded-lg object-cover shrink-0 border" />
            ) : (
              <div className="h-20 w-20 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                <Package className="h-9 w-9 text-primary" />
              </div>
            )}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-xl font-bold">{item.name}</h1>
                {isLowStock && (
                  <Badge variant="destructive" className="gap-1 text-xs">
                    <AlertTriangle className="h-3 w-3" /> Low Stock
                  </Badge>
                )}
              </div>
              <p className="text-sm text-muted-foreground mt-0.5">SKU: {item.sku}</p>
              <Badge variant="secondary" className="mt-1 text-xs">{item.category}</Badge>
              {item.description && <p className="text-sm text-muted-foreground mt-2">{item.description}</p>}
            </div>
          </div>

          <Separator className="my-5" />

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="text-center p-3 bg-muted/40 rounded-lg">
              <p className={`text-2xl font-bold ${isLowStock ? "text-destructive" : "text-primary"}`}>{item.quantity}</p>
              <p className="text-xs text-muted-foreground">{item.unit}s in stock</p>
            </div>
            <div className="text-center p-3 bg-muted/40 rounded-lg">
              <p className="text-2xl font-bold">{fmt(item.price, item.currency)}</p>
              <p className="text-xs text-muted-foreground">Selling Price</p>
            </div>
            <div className="text-center p-3 bg-muted/40 rounded-lg">
              <p className="text-2xl font-bold">{fmt(item.costPrice, item.currency)}</p>
              <p className="text-xs text-muted-foreground">Cost Price</p>
            </div>
            <div className="text-center p-3 bg-muted/40 rounded-lg">
              <p className="text-2xl font-bold">{fmt(stockValue, item.currency)}</p>
              <p className="text-xs text-muted-foreground">Stock Value</p>
            </div>
          </div>

          {margin !== null && (
            <div className="mt-4 flex items-center gap-2 text-sm">
              <TrendingUp className="h-4 w-4 text-green-600" />
              <span className="text-muted-foreground">Profit Margin:</span>
              <span className={`font-semibold ${margin > 20 ? "text-green-600" : margin > 0 ? "text-amber-600" : "text-destructive"}`}>
                {margin.toFixed(1)}%
              </span>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Stock Adjustment History</CardTitle>
        </CardHeader>
        <CardContent>
          {adjustments.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-6">No stock adjustments recorded yet.</p>
          ) : (
            <div className="space-y-2">
              {adjustments.map((adj) => (
                <div key={adj.id} className="flex items-center justify-between p-3 rounded-lg border">
                  <div className="flex items-center gap-3">
                    {adj.adjustment > 0
                      ? <TrendingUp className="h-4 w-4 text-green-500" />
                      : <TrendingDown className="h-4 w-4 text-red-500" />
                    }
                    <div>
                      <p className="text-sm font-medium capitalize">{adj.reason}</p>
                      {adj.notes && <p className="text-xs text-muted-foreground">{adj.notes}</p>}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`font-semibold ${adj.adjustment > 0 ? "text-green-600" : "text-red-600"}`}>
                      {adj.adjustment > 0 ? "+" : ""}{adj.adjustment}
                    </p>
                    <p className="text-xs text-muted-foreground">{new Date(adj.createdAt).toLocaleDateString()}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={showAdjust} onOpenChange={setShowAdjust}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Adjust Stock — {item.name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid gap-2">
              <Label>Quantity Change</Label>
              <div className="flex items-center gap-2">
                <Button size="icon" variant="outline" onClick={() => setAdjustQty(String(Number(adjustQty) - 1))}>
                  <Minus className="h-4 w-4" />
                </Button>
                <Input
                  type="number"
                  value={adjustQty}
                  onChange={(e) => setAdjustQty(e.target.value)}
                  className="text-center font-bold text-lg"
                />
                <Button size="icon" variant="outline" onClick={() => setAdjustQty(String(Number(adjustQty) + 1))}>
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">Use negative values to decrease stock. Current: {item.quantity} {item.unit}s</p>
            </div>
            <div className="grid gap-2">
              <Label>Reason</Label>
              <Select value={reason} onValueChange={setReason}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {REASONS.map((r) => <SelectItem key={r} value={r} className="capitalize">{r}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label>Notes (optional)</Label>
              <Input value={adjustNotes} onChange={(e) => setAdjustNotes(e.target.value)} placeholder="Add any relevant details..." />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAdjust(false)}>Cancel</Button>
            <Button onClick={handleAdjust} disabled={saving || adjustQty === "0"} className="gap-2">
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              Save Adjustment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
