import { useState } from "react";
import { useLocation } from "wouter";
import { useCreateInventoryItem } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Textarea } from "../../components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import { useToast } from "../../hooks/use-toast";
import { ArrowLeft, Loader2, Package } from "lucide-react";
import { Link } from "wouter";
import ImageUpload from "../../components/ImageUpload";

const CATEGORIES = ["Electronics", "Clothing", "Food & Beverage", "Household", "Tools", "Health & Beauty", "Agriculture", "Services", "Other"];
const UNITS = ["piece", "kg", "g", "litre", "carton", "bag", "box", "dozen", "metre", "unit"];
import { CURRENCY_LABELS, UNIQUE_CURRENCIES } from "../../lib/currencies";


export default function NewInventoryItem() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { mutateAsync: createItem, isPending: creating } = useCreateInventoryItem();

  const [form, setForm] = useState({
    name: "",
    sku: "",
    category: "Other",
    description: "",
    price: "",
    costPrice: "",
    quantity: "0",
    unit: "piece",
    currency: "NGN",
    lowStockThreshold: "5",
    imageUrl: "",
  });

  const set = (field: string, value: string) => setForm((f) => ({ ...f, [field]: value }));

  const handleSubmit = async () => {
    if (!form.name || !form.price) {
      toast({ variant: "destructive", title: "Required fields", description: "Name and price are required." });
      return;
    }
    try {
      const item = await createItem({
        data: {
          name: form.name,
          sku: form.sku || "",
          category: form.category,
          description: form.description || undefined,
          price: Number(form.price),
          costPrice: form.costPrice ? Number(form.costPrice) : 0,
          quantity: Number(form.quantity),
          unit: form.unit,
          currency: form.currency,
          lowStockThreshold: Number(form.lowStockThreshold),
          imageUrl: form.imageUrl || undefined,
        },
      });
      toast({ title: "Item added!", description: `${form.name} added to your inventory.` });
      navigate(`/inventory/${item.id}`);
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Failed to add inventory item." });
    }
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div className="flex items-center gap-4">
        <Link href="/inventory">
          <Button variant="ghost" size="icon" className="h-9 w-9">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight flex items-center gap-2">
            <Package className="h-6 w-6 sm:h-7 sm:w-7" /> Add Inventory Item
          </h1>
          <p className="text-muted-foreground mt-1">Add a new product or service to your inventory.</p>
        </div>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Item Details</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-2">
              <Label htmlFor="name">Item Name *</Label>
              <Input id="name" value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="Bag of Rice (50kg)" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="sku">SKU / Code</Label>
              <Input id="sku" value={form.sku} onChange={(e) => set("sku", e.target.value)} placeholder="RICE-50KG-001" />
            </div>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-2">
              <Label>Category</Label>
              <Select value={form.category} onValueChange={(v) => set("category", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label>Unit</Label>
              <Select value={form.unit} onValueChange={(v) => set("unit", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{UNITS.map((u) => <SelectItem key={u} value={u}>{u}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="description">Description</Label>
            <Textarea id="description" value={form.description} onChange={(e) => set("description", e.target.value)} placeholder="Brief description of the product..." className="min-h-[70px]" />
          </div>
          <div className="grid gap-2">
            <Label>Product Image</Label>
            <ImageUpload
              value={form.imageUrl || null}
              onChange={(url) => set("imageUrl", url || "")}
              folder="products"
              maxSizeMB={3}
              description="JPG or PNG, max 3 MB"
              aspectRatio="square"
              shape="rounded"
              className="max-w-[200px]"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Pricing & Stock</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-2">
            <Label>Currency</Label>
            <Select value={form.currency} onValueChange={(v) => set("currency", v)}>
              <SelectTrigger className="max-w-[200px]"><SelectValue /></SelectTrigger>
              <SelectContent>{UNIQUE_CURRENCIES.map((c) => <SelectItem key={c} value={c}>{CURRENCY_LABELS[c] ?? c}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-2">
              <Label htmlFor="price">Selling Price *</Label>
              <Input id="price" type="number" min="0" step="0.01" value={form.price} onChange={(e) => set("price", e.target.value)} placeholder="0.00" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="costPrice">Cost Price (optional)</Label>
              <Input id="costPrice" type="number" min="0" step="0.01" value={form.costPrice} onChange={(e) => set("costPrice", e.target.value)} placeholder="0.00" />
              <p className="text-xs text-muted-foreground">Used for profit margin calculations</p>
            </div>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-2">
              <Label htmlFor="quantity">Initial Stock</Label>
              <Input id="quantity" type="number" min="0" value={form.quantity} onChange={(e) => set("quantity", e.target.value)} />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="lowStockThreshold">Low Stock Alert</Label>
              <Input id="lowStockThreshold" type="number" min="0" value={form.lowStockThreshold} onChange={(e) => set("lowStockThreshold", e.target.value)} />
              <p className="text-xs text-muted-foreground">Alert when stock falls below this</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-3 justify-end">
        <Link href="/inventory">
          <Button variant="outline">Cancel</Button>
        </Link>
        <Button onClick={handleSubmit} disabled={creating} className="gap-2 min-w-[140px]">
          {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Package className="h-4 w-4" />}
          Add Item
        </Button>
      </div>
    </div>
  );
}
