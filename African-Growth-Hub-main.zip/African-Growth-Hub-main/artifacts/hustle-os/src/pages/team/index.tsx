import { useState } from "react";
import { useListTeamMembers, useInviteTeamMember, useRemoveTeamMember, TeamInviteInputRole } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Badge } from "../../components/ui/badge";
import { Skeleton } from "../../components/ui/skeleton";
import { Avatar, AvatarFallback } from "../../components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "../../components/ui/dialog";
import { useToast } from "../../hooks/use-toast";
import { Plus, Loader2, UserMinus, UsersRound, Shield, User, Eye, CheckCircle, Link as LinkIcon } from "lucide-react";
import { useAuth } from "../../contexts/AuthContext";

const ROLE_ICONS: Record<string, React.ElementType> = { admin: Shield, manager: User, staff: Eye };
const ROLE_COLORS: Record<string, string> = {
  admin: "bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300",
  manager: "bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300",
  staff: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
};

export default function Team() {
  const { user, profile } = useAuth();
  const { toast } = useToast();
  const [showInvite, setShowInvite] = useState(false);
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [role, setRole] = useState("staff");
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const { data: members, isLoading } = useListTeamMembers();
  const { mutateAsync: invite, isPending: inviting } = useInviteTeamMember();
  const { mutateAsync: remove } = useRemoveTeamMember();

  const userRole = profile?.role || user?.user_metadata?.role || "owner";
  const isAdmin = userRole === "owner" || userRole === "admin";

  const handleInvite = async () => {
    if (!email || !name) { toast({ variant: "destructive", title: "Name and email are required" }); return; }
    try {
      await invite({ data: { name, email, role: role as TeamInviteInputRole } });
      toast({ title: "Invitation sent!", description: `${name} has been invited to your team.` });
      setShowInvite(false);
      setEmail(""); setName(""); setRole("staff");
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Failed to invite team member." });
    }
  };

  const handleRemove = async (id: string, memberName: string) => {
    if (!confirm(`Remove ${memberName} from the team?`)) return;
    try {
      await remove({ id });
      toast({ title: "Member removed" });
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Failed to remove member." });
    }
  };

  const copyInviteLink = (token: string) => {
    const baseUrl = window.location.origin;
    const url = `${baseUrl}/join/${token}`;
    navigator.clipboard.writeText(url).then(() => {
      toast({ title: "Link copied!", description: "Share this link with your invitee." });
      setCopiedId(token);
      setTimeout(() => setCopiedId(null), 2000);
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Team</h1>
          <p className="text-muted-foreground mt-1">Manage team members and their access levels.</p>
        </div>
        {isAdmin && (
          <Button onClick={() => setShowInvite(true)} className="gap-2">
            <Plus className="h-4 w-4" /> Invite Member
          </Button>
        )}
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        {[
          { label: "Admin", desc: "Full access to everything", icon: Shield, color: "text-purple-500" },
          { label: "Manager", desc: "Manage invoices, customers, inventory", icon: User, color: "text-blue-500" },
          { label: "Staff", desc: "Read-only access to all data", icon: Eye, color: "text-slate-500" },
        ].map((r) => (
          <Card key={r.label} className="p-4">
            <div className="flex items-start gap-3">
              <r.icon className={`h-5 w-5 mt-0.5 ${r.color}`} />
              <div>
                <p className="font-medium text-sm">{r.label}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{r.desc}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <UsersRound className="h-4 w-4" /> Team Members
          </CardTitle>
          <CardDescription>{isLoading ? "Loading..." : `${(members || []).length} member(s)`}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center gap-3 p-4 rounded-lg bg-muted/40 border">
            <Avatar className="h-10 w-10">
              <AvatarFallback className="bg-primary/10 text-primary font-bold">
                {user?.email?.charAt(0).toUpperCase() || "O"}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <p className="font-medium text-sm">{user?.user_metadata?.name || user?.email}</p>
              <p className="text-xs text-muted-foreground">{user?.email}</p>
            </div>
            <Badge className="bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300">Owner</Badge>
          </div>

          {isLoading ? (
            Array(3).fill(0).map((_, i) => (
              <div key={i} className="flex items-center gap-3 p-4">
                <Skeleton className="h-10 w-10 rounded-full" />
                <div className="flex-1 space-y-2"><Skeleton className="h-4 w-40" /><Skeleton className="h-3 w-28" /></div>
                <Skeleton className="h-6 w-16 rounded-full" />
              </div>
            ))
          ) : (members || []).length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <UsersRound className="h-10 w-10 mx-auto mb-3 opacity-30" />
              <p className="text-sm">No team members yet. Invite someone to collaborate.</p>
            </div>
          ) : (
            (members || []).map((member) => {
              const RoleIcon = ROLE_ICONS[member.role] || User;
              return (
                <div key={member.id} className="flex items-center gap-3 p-4 rounded-lg border hover:bg-muted/30 transition-colors">
                  <Avatar className="h-10 w-10">
                    <AvatarFallback className="bg-primary/10 text-primary">
                      {(member.name || member.email || "?").substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <p className="font-medium text-sm">{member.name}</p>
                    <p className="text-xs text-muted-foreground">{member.email}</p>
                  </div>
                  <Badge variant="secondary" className={`gap-1 ${ROLE_COLORS[member.role] || ""}`}>
                    <RoleIcon className="h-3 w-3" />
                    {member.role}
                  </Badge>
                  <Badge variant={member.status === "active" ? "default" : "outline"} className="text-xs">
                    {member.status}
                  </Badge>
                  {member.inviteToken && member.status === "invited" && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-muted-foreground hover:text-primary"
                      onClick={() => copyInviteLink(member.inviteToken!)}
                      title="Copy invite link"
                    >
                      {copiedId === member.inviteToken ? <CheckCircle className="h-4 w-4 text-green-500" /> : <LinkIcon className="h-4 w-4" />}
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-muted-foreground hover:text-destructive"
                    onClick={() => handleRemove(member.id, member.name)}
                  >
                    <UserMinus className="h-4 w-4" />
                  </Button>
                </div>
              );
            })
          )}
        </CardContent>
      </Card>

      <Dialog open={showInvite} onOpenChange={setShowInvite}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Invite Team Member</DialogTitle>
            <DialogDescription>Send an invitation to collaborate on your HustleOS account.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid gap-2">
              <Label>Full Name *</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Amara Nwosu" />
            </div>
            <div className="grid gap-2">
              <Label>Email Address *</Label>
              <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="amara@example.com" />
            </div>
            <div className="grid gap-2">
              <Label>Role</Label>
              <Select value={role} onValueChange={setRole}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Admin — Full access</SelectItem>
                  <SelectItem value="manager">Manager — Manage data</SelectItem>
                  <SelectItem value="staff">Staff — Read only</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowInvite(false)}>Cancel</Button>
            <Button onClick={handleInvite} disabled={inviting} className="gap-2">
              {inviting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
              Send Invitation
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
