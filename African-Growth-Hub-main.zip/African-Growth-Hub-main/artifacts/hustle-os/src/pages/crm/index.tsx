import { useState, useEffect } from "react";
import { formatCurrencyCompact, formatCountCompact } from "../../lib/format";
import { useAuth } from "../../contexts/AuthContext";
import { useToast } from "../../hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Badge } from "../../components/ui/badge";
import { Skeleton } from "../../components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "../../components/ui/dialog";
import {
  MessageSquare,
  Phone,
  UserPlus,
  ShoppingCart,
  CheckCircle2,
  XCircle,
  Clock,
  ExternalLink,
  Filter,
  Plus,
  Search,
} from "lucide-react";

interface Lead {
  id: string;
  name: string;
  phone: string;
  email: string | null;
  source: string;
  status: string;
  notes: string | null;
  createdAt: string;
}

interface Order {
  id: string;
  customerId: string | null;
  leadId: string | null;
  customerName: string;
  customerPhone: string;
  items: Array<{ name: string; quantity: number; price: number }>;
  total: number;
  currency: string;
  status: string;
  notes: string | null;
  whatsappNumber: string | null;
  createdAt: string;
}

interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  totalSpent: number;
  invoiceCount: number;
}

const LEAD_STATUS_COLORS: Record<string, string> = {
  new: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  contacted: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300",
  qualified: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300",
  converted: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
  lost: "bg-gray-100 text-gray-600",
};

const ORDER_STATUS_COLORS: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300",
  confirmed: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  processing: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300",
  shipped: "bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-300",
  delivered: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
  cancelled: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
};

function waLink(phone: string) {
  const clean = phone.replace(/\D/g, "");
  return `https://wa.me/${clean}`;
}

export default function CRMPage() {
  const { session } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("leads");
  const [leads, setLeads] = useState<Lead[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [leadSearch, setLeadSearch] = useState("");
  const [leadStatusFilter, setLeadStatusFilter] = useState("");
  const [orderStatusFilter, setOrderStatusFilter] = useState("");
  const [showAddLead, setShowAddLead] = useState(false);
  const [showAddOrder, setShowAddOrder] = useState(false);
  const [leadForm, setLeadForm] = useState({ name: "", phone: "", email: "", notes: "" });
  const [orderForm, setOrderForm] = useState({
    customerName: "",
    customerPhone: "",
    items: [{ name: "", quantity: 1, price: 0 }],
    total: 0,
    notes: "",
  });

  const authHeaders = { Authorization: `Bearer ${session?.access_token}`, "Content-Type": "application/json" };

  const fetchData = async () => {
    if (!session) return;
    try {
      const [leadsRes, ordersRes, customersRes] = await Promise.all([
        fetch(`/api/crm/leads`, { headers: authHeaders }).then((r) => r.json()),
        fetch(`/api/crm/orders`, { headers: authHeaders }).then((r) => r.json()),
        fetch(`/api/customers`, { headers: authHeaders }).then((r) => r.json()),
      ]);
      setLeads(Array.isArray(leadsRes) ? leadsRes : []);
      setOrders(Array.isArray(ordersRes) ? ordersRes : []);
      setCustomers(Array.isArray(customersRes) ? customersRes : []);
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Failed to load CRM data." });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [session]);

  const createLead = async () => {
    if (!leadForm.name || !leadForm.phone) {
      toast({ variant: "destructive", title: "Missing fields", description: "Name and phone are required." });
      return;
    }
    try {
      const res = await fetch(`/api/crm/leads`, {
        method: "POST",
        headers: authHeaders,
        body: JSON.stringify(leadForm),
      });
      if (!res.ok) throw new Error("Failed");
      const newLead = await res.json();
      setLeads((prev) => [newLead, ...prev]);
      setLeadForm({ name: "", phone: "", email: "", notes: "" });
      setShowAddLead(false);
      toast({ title: "Lead added", description: `${newLead.name} has been added.` });
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Failed to add lead." });
    }
  };

  const updateLeadStatus = async (id: string, status: string) => {
    try {
      const res = await fetch(`/api/crm/leads/${id}`, {
        method: "PATCH",
        headers: authHeaders,
        body: JSON.stringify({ status }),
      });
      if (!res.ok) throw new Error("Failed");
      setLeads((prev) => prev.map((l) => (l.id === id ? { ...l, status } : l)));
      toast({ title: "Lead updated" });
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Failed to update lead." });
    }
  };

  const deleteLead = async (id: string) => {
    if (!confirm("Delete this lead?")) return;
    try {
      await fetch(`/api/crm/leads/${id}`, { method: "DELETE", headers: authHeaders });
      setLeads((prev) => prev.filter((l) => l.id !== id));
      toast({ title: "Lead deleted" });
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Failed to delete lead." });
    }
  };

  const createOrder = async () => {
    if (!orderForm.customerName || !orderForm.customerPhone) {
      toast({ variant: "destructive", title: "Missing fields", description: "Customer name and phone are required." });
      return;
    }
    const total = orderForm.items.reduce((sum, item) => sum + item.quantity * item.price, 0);
    try {
      const res = await fetch(`/api/crm/orders`, {
        method: "POST",
        headers: authHeaders,
        body: JSON.stringify({ ...orderForm, total }),
      });
      if (!res.ok) throw new Error("Failed");
      const newOrder = await res.json();
      setOrders((prev) => [newOrder, ...prev]);
      setOrderForm({ customerName: "", customerPhone: "", items: [{ name: "", quantity: 1, price: 0 }], total: 0, notes: "" });
      setShowAddOrder(false);
      toast({ title: "Order created", description: `Order for ${newOrder.customerName} has been added.` });
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Failed to create order." });
    }
  };

  const updateOrderStatus = async (id: string, status: string) => {
    try {
      const res = await fetch(`/api/crm/orders/${id}`, {
        method: "PATCH",
        headers: authHeaders,
        body: JSON.stringify({ status }),
      });
      if (!res.ok) throw new Error("Failed");
      setOrders((prev) => prev.map((o) => (o.id === id ? { ...o, status } : o)));
      toast({ title: "Order updated" });
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Failed to update order." });
    }
  };

  const addItem = () => {
    setOrderForm((prev) => ({
      ...prev,
      items: [...prev.items, { name: "", quantity: 1, price: 0 }],
    }));
  };

  const removeItem = (idx: number) => {
    setOrderForm((prev) => ({
      ...prev,
      items: prev.items.filter((_, i) => i !== idx),
    }));
  };

  const updateItem = (idx: number, field: string, value: string | number) => {
    setOrderForm((prev) => {
      const items = prev.items.map((item, i) => (i === idx ? { ...item, [field]: value } : item));
      const total = items.reduce((sum, item) => sum + item.quantity * item.price, 0);
      return { ...prev, items, total };
    });
  };

  const filteredLeads = leads.filter((l) => {
    const matchesSearch =
      l.name.toLowerCase().includes(leadSearch.toLowerCase()) ||
      l.phone.includes(leadSearch);
    const matchesStatus = !leadStatusFilter || l.status === leadStatusFilter;
    return matchesSearch && matchesStatus;
  });

  const filteredOrders = orders.filter((o) => {
    const matchesStatus = !orderStatusFilter || o.status === orderStatusFilter;
    return matchesStatus;
  });

  if (loading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">WhatsApp CRM</h1>
          <p className="text-muted-foreground text-sm">Manage leads, customers, and orders with WhatsApp.</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="text-green-600 border-green-200 gap-1">
            <MessageSquare className="h-3 w-3" /> WhatsApp Connected
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Leads</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold stat-num">{formatCountCompact(leads.length)}</div>
            <p className="text-xs text-muted-foreground">{leads.filter((l) => l.status === "new").length} new this week</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Conversion Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-600 stat-num">
              {leads.length > 0 ? Math.round((leads.filter((l) => l.status === "converted").length / leads.length) * 100) : 0}%
            </div>
            <p className="text-xs text-muted-foreground">{leads.filter((l) => l.status === "converted").length} converted</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Orders</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold stat-num">{orders.length}</div>
            <p className="text-xs text-muted-foreground">
              {orders.filter((o) => o.status === "pending").length} pending fulfillment
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Order Value</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold stat-num">
              {formatCurrencyCompact(orders.filter((o) => o.status !== "cancelled").reduce((s, o) => s + o.total, 0), "NGN")}
            </div>
            <p className="text-xs text-muted-foreground">Total pipeline value</p>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="leads">Leads</TabsTrigger>
          <TabsTrigger value="orders">Orders</TabsTrigger>
          <TabsTrigger value="customers">Customers</TabsTrigger>
        </TabsList>

        <TabsContent value="leads" className="space-y-4">
          <div className="flex items-center gap-2 flex-wrap">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search leads..."
                className="pl-9"
                value={leadSearch}
                onChange={(e) => setLeadSearch(e.target.value)}
              />
            </div>
            <select
              className="h-9 rounded-md border border-input bg-background px-3 text-sm"
              value={leadStatusFilter}
              onChange={(e) => setLeadStatusFilter(e.target.value)}
            >
              <option value="">All Status</option>
              <option value="new">New</option>
              <option value="contacted">Contacted</option>
              <option value="qualified">Qualified</option>
              <option value="converted">Converted</option>
              <option value="lost">Lost</option>
            </select>
            <Button onClick={() => setShowAddLead(true)} className="gap-1.5">
              <Plus className="h-4 w-4" /> Add Lead
            </Button>
          </div>

          {filteredLeads.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <UserPlus className="h-8 w-8 mx-auto mb-3 opacity-50" />
              <p>No leads found. Add your first lead to get started.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {filteredLeads.map((lead) => (
                <div
                  key={lead.id}
                  className="flex items-center justify-between p-4 rounded-lg border hover:bg-muted/40 transition-colors"
                >
                  <div className="flex items-start gap-3">
                    <div className="h-10 w-10 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-sm shrink-0">
                      {lead.name?.charAt(0).toUpperCase() ?? '?'}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-medium text-sm">{lead.name}</p>
                        <Badge className={`text-xs ${LEAD_STATUS_COLORS[lead.status] || ""}`}>{lead.status}</Badge>
                      </div>
                      <div className="flex items-center gap-3 text-sm text-muted-foreground mt-1">
                        <span className="flex items-center gap-1">
                          <Phone className="h-3 w-3" /> {lead.phone}
                        </span>
                        {lead.email && (
                          <span className="flex items-center gap-1">
                            <MessageSquare className="h-3 w-3" /> {lead.email}
                          </span>
                        )}
                        <span className="text-xs">via {lead.source}</span>
                      </div>
                      {lead.notes && <p className="text-xs text-muted-foreground mt-1">{lead.notes}</p>}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="outline" asChild className="gap-1.5 text-green-600 border-green-200">
                      <a href={waLink(lead.phone)} target="_blank" rel="noopener noreferrer">
                        <MessageSquare className="h-3.5 w-3.5" /> Chat
                      </a>
                    </Button>
                    <select
                      className="h-8 rounded-md border border-input bg-background px-2 text-xs"
                      value={lead.status}
                      onChange={(e) => updateLeadStatus(lead.id, e.target.value)}
                    >
                      <option value="new">New</option>
                      <option value="contacted">Contacted</option>
                      <option value="qualified">Qualified</option>
                      <option value="converted">Converted</option>
                      <option value="lost">Lost</option>
                    </select>
                    <Button size="sm" variant="ghost" onClick={() => deleteLead(lead.id)} className="text-destructive">
                      <XCircle className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="orders" className="space-y-4">
          <div className="flex items-center gap-2 flex-wrap">
            <select
              className="h-9 rounded-md border border-input bg-background px-3 text-sm"
              value={orderStatusFilter}
              onChange={(e) => setOrderStatusFilter(e.target.value)}
            >
              <option value="">All Status</option>
              <option value="pending">Pending</option>
              <option value="confirmed">Confirmed</option>
              <option value="processing">Processing</option>
              <option value="shipped">Shipped</option>
              <option value="delivered">Delivered</option>
              <option value="cancelled">Cancelled</option>
            </select>
            <Button onClick={() => setShowAddOrder(true)} className="gap-1.5">
              <Plus className="h-4 w-4" /> New Order
            </Button>
          </div>

          {filteredOrders.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <ShoppingCart className="h-8 w-8 mx-auto mb-3 opacity-50" />
              <p>No orders yet. Create your first order.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {filteredOrders.map((order) => (
                <div
                  key={order.id}
                  className="flex items-center justify-between p-4 rounded-lg border hover:bg-muted/40 transition-colors"
                >
                  <div className="flex items-start gap-3">
                    <div className="h-10 w-10 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-sm shrink-0">
                      {order.customerName?.charAt(0).toUpperCase() ?? '?'}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-medium text-sm">{order.customerName}</p>
                        <Badge className={`text-xs ${ORDER_STATUS_COLORS[order.status] || ""}`}>
                          {order.status}
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground mt-1">
                        <span className="font-semibold text-foreground">
                          {order.currency} {order.total.toLocaleString()}
                        </span>
                        {" · "}
                        {order.items.length} item(s)
                        {" · "}
                        <span className="flex items-center gap-1 inline-flex">
                          <Phone className="h-3 w-3" /> {order.customerPhone}
                        </span>
                      </div>
                      {order.notes && <p className="text-xs text-muted-foreground mt-1">{order.notes}</p>}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="outline" asChild className="gap-1.5 text-green-600 border-green-200">
                      <a href={waLink(order.whatsappNumber || order.customerPhone)} target="_blank" rel="noopener noreferrer">
                        <MessageSquare className="h-3.5 w-3.5" /> Chat
                      </a>
                    </Button>
                    <select
                      className="h-8 rounded-md border border-input bg-background px-2 text-xs"
                      value={order.status}
                      onChange={(e) => updateOrderStatus(order.id, e.target.value)}
                    >
                      <option value="pending">Pending</option>
                      <option value="confirmed">Confirmed</option>
                      <option value="processing">Processing</option>
                      <option value="shipped">Shipped</option>
                      <option value="delivered">Delivered</option>
                      <option value="cancelled">Cancelled</option>
                    </select>
                  </div>
                </div>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="customers" className="space-y-4">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search customers..." className="pl-9" />
          </div>
          {customers.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <UserPlus className="h-8 w-8 mx-auto mb-3 opacity-50" />
              <p>No customers yet. Add customers from the Customers page.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {customers.map((customer) => (
                <div
                  key={customer.id}
                  className="flex items-center justify-between p-4 rounded-lg border hover:bg-muted/40 transition-colors"
                >
                  <div className="flex items-start gap-3">
                    <div className="h-10 w-10 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-sm shrink-0">
                      {customer.name?.charAt(0).toUpperCase() ?? '?'}
                    </div>
                    <div>
                      <p className="font-medium text-sm">{customer.name}</p>
                      <div className="flex items-center gap-3 text-sm text-muted-foreground mt-1">
                        <span>{customer.email}</span>
                        {customer.phone && (
                          <span className="flex items-center gap-1">
                            <Phone className="h-3 w-3" /> {customer.phone}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <p className="font-semibold text-sm">{customer.totalSpent.toLocaleString()}</p>
                      <p className="text-xs text-muted-foreground">{customer.invoiceCount} invoices</p>
                    </div>
                    {customer.phone && (
                      <Button size="sm" variant="outline" asChild className="gap-1.5 text-green-600 border-green-200">
                        <a href={waLink(customer.phone)} target="_blank" rel="noopener noreferrer">
                          <MessageSquare className="h-3.5 w-3.5" /> Chat
                        </a>
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Add Lead Dialog */}
      <Dialog open={showAddLead} onOpenChange={setShowAddLead}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Lead</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="grid gap-2">
              <Label htmlFor="lead-name">Name *</Label>
              <Input id="lead-name" value={leadForm.name} onChange={(e) => setLeadForm({ ...leadForm, name: e.target.value })} />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="lead-phone">Phone *</Label>
              <Input id="lead-phone" value={leadForm.phone} onChange={(e) => setLeadForm({ ...leadForm, phone: e.target.value })} placeholder="+234 800 000 0000" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="lead-email">Email</Label>
              <Input id="lead-email" type="email" value={leadForm.email} onChange={(e) => setLeadForm({ ...leadForm, email: e.target.value })} />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="lead-notes">Notes</Label>
              <Input id="lead-notes" value={leadForm.notes} onChange={(e) => setLeadForm({ ...leadForm, notes: e.target.value })} />
            </div>
            <Button onClick={createLead} className="w-full">Add Lead</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Order Dialog */}
      <Dialog open={showAddOrder} onOpenChange={setShowAddOrder}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>New Order</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="grid gap-2">
              <Label htmlFor="order-name">Customer Name *</Label>
              <Input id="order-name" value={orderForm.customerName} onChange={(e) => setOrderForm({ ...orderForm, customerName: e.target.value })} />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="order-phone">Customer Phone *</Label>
              <Input id="order-phone" value={orderForm.customerPhone} onChange={(e) => setOrderForm({ ...orderForm, customerPhone: e.target.value })} placeholder="+234 800 000 0000" />
            </div>
            <div className="space-y-2">
              <Label>Items</Label>
              {orderForm.items.map((item, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <Input placeholder="Item name" value={item.name} onChange={(e) => updateItem(idx, "name", e.target.value)} className="flex-1" />
                  <Input type="number" placeholder="Qty" value={item.quantity} onChange={(e) => updateItem(idx, "quantity", Number(e.target.value))} className="w-20" />
                  <Input type="number" placeholder="Price" value={item.price} onChange={(e) => updateItem(idx, "price", Number(e.target.value))} className="w-28" />
                  <Button size="sm" variant="ghost" onClick={() => removeItem(idx)} disabled={orderForm.items.length === 1}>
                    <XCircle className="h-4 w-4" />
                  </Button>
                </div>
              ))}
              <Button size="sm" variant="outline" onClick={addItem} className="gap-1.5">
                <Plus className="h-4 w-4" /> Add Item
              </Button>
            </div>
            <div className="flex items-center justify-between font-semibold">
              <span>Total:</span>
              <span>NGN {orderForm.total.toLocaleString()}</span>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="order-notes">Notes</Label>
              <Input id="order-notes" value={orderForm.notes} onChange={(e) => setOrderForm({ ...orderForm, notes: e.target.value })} />
            </div>
            <Button onClick={createOrder} className="w-full">Create Order</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
