import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { useAuth } from "../../contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Textarea } from "../../components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import { useToast } from "../../hooks/use-toast";
import { Link } from "wouter";
import { ArrowLeft, Video, Loader2, ImagePlus, X, Play } from "lucide-react";

const CATEGORIES = ["general", "sales", "marketing", "finance", "inventory", "operations", "technology"];

export default function NewTrainingVideo() {
  const [, navigate] = useLocation();
  const { session } = useAuth();
  const { toast } = useToast();
  const fileRef = useRef<HTMLInputElement>(null);

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("general");
  const [videoUrl, setVideoUrl] = useState("");
  const [thumbnailUrl, setThumbnailUrl] = useState("");
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [saving, setSaving] = useState(false);

  const authHeaders = {
    Authorization: `Bearer ${session?.access_token}`,
    "Content-Type": "application/json",
  };

  const handleVideoUpload = async (file: File) => {
    const maxVideo = 50 * 1024 * 1024;
    if (file.size > maxVideo) {
      toast({ variant: "destructive", title: "Video too large", description: "Max 50 MB allowed." });
      return;
    }

    setUploading(true);
    setUploadProgress(10);

    try {
      const data = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });

      setUploadProgress(50);

      const res = await fetch("/api/upload", {
        method: "POST",
        headers: authHeaders,
        body: JSON.stringify({ data, folder: "training-videos" }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Upload failed");
      }

      const { url, thumbnailUrl: thumb } = (await res.json()) as { url: string; thumbnailUrl?: string };
      setVideoUrl(url);
      if (thumb) setThumbnailUrl(thumb);
      setUploadProgress(100);
      toast({ title: "Video uploaded", description: "Your video is ready." });
    } catch (err: any) {
      toast({ variant: "destructive", title: "Upload failed", description: err.message || "Please try again." });
    } finally {
      setTimeout(() => { setUploading(false); setUploadProgress(0); }, 500);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    handleVideoUpload(file);
  };

  const handleRemove = () => {
    setVideoUrl("");
    setThumbnailUrl("");
    if (fileRef.current) fileRef.current.value = "";
  };

  const handleSubmit = async () => {
    if (!title || !videoUrl) {
      toast({ variant: "destructive", title: "Required fields", description: "Title and video are required." });
      return;
    }

    setSaving(true);
    try {
      const res = await fetch("/api/training-videos", {
        method: "POST",
        headers: authHeaders,
        body: JSON.stringify({ title, description, videoUrl, thumbnailUrl: thumbnailUrl || undefined, category }),
      });
      if (!res.ok) throw new Error();
      toast({ title: "Video uploaded!" });
      navigate("/training-videos");
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Failed to save." });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div className="flex items-center gap-4">
        <Link href="/training-videos">
          <Button variant="ghost" size="icon" className="h-9 w-9">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight flex items-center gap-2">
            <Video className="h-6 w-6 sm:h-7 sm:w-7 text-primary" /> Upload Training Video
          </h1>
          <p className="text-muted-foreground mt-1">Share training content with your team.</p>
        </div>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Video Details</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-2">
            <Label>Title *</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. How to handle objections" />
          </div>
          <div className="grid gap-2">
            <Label>Description</Label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3} placeholder="What is this video about?" />
          </div>
          <div className="grid gap-2">
            <Label>Category</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {CATEGORIES.map((c) => <SelectItem key={c} value={c} className="capitalize">{c}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Video File</CardTitle></CardHeader>
        <CardContent>
          <input ref={fileRef} type="file" accept="video/*" className="hidden" onChange={handleFileChange} />
          {videoUrl ? (
            <div className="relative rounded-lg overflow-hidden bg-black aspect-video">
              <video src={videoUrl} className="w-full h-full" controls muted playsInline />
              <Button
                variant="destructive"
                size="icon"
                className="absolute top-2 right-2 h-8 w-8"
                onClick={handleRemove}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              disabled={uploading}
              className="w-full flex flex-col items-center justify-center gap-2 border-2 border-dashed border-border rounded-lg p-8 text-muted-foreground hover:border-primary/50 hover:text-primary transition-colors disabled:opacity-50 aspect-video"
            >
              {uploading ? (
                <>
                  <Loader2 className="h-8 w-8 animate-spin" />
                  <span className="text-sm font-medium">Uploading... {uploadProgress}%</span>
                </>
              ) : (
                <>
                  <ImagePlus className="h-8 w-8" />
                  <span className="text-sm font-medium">Click to upload video</span>
                  <span className="text-xs">MP4, WebM, MOV up to 50 MB</span>
                </>
              )}
            </button>
          )}
        </CardContent>
      </Card>

      <div className="flex gap-3 justify-end">
        <Link href="/training-videos">
          <Button variant="outline">Cancel</Button>
        </Link>
        <Button onClick={handleSubmit} disabled={saving || uploading} className="gap-2 min-w-[140px]">
          {saving && <Loader2 className="h-4 w-4 animate-spin" />}
          Save Video
        </Button>
      </div>
    </div>
  );
}
