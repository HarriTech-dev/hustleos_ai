import { useState, useEffect } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { Card, CardContent } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../../components/ui/dialog";
import { useToast } from "../../hooks/use-toast";
import { useLocation } from "wouter";
import { Link } from "wouter";
import { Play, Trash2, Plus, Video, Loader2 } from "lucide-react";

interface TrainingVideo {
  id: string;
  title: string;
  description?: string | null;
  videoUrl: string;
  thumbnailUrl?: string | null;
  category: string;
  createdAt: string;
}

const CATEGORIES = ["general", "sales", "marketing", "finance", "inventory", "operations", "technology"];

export default function TrainingVideos() {
  const { session } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [videos, setVideos] = useState<TrainingVideo[]>([]);
  const [loading, setLoading] = useState(true);
  const [playing, setPlaying] = useState<TrainingVideo | null>(null);
  const [deleting, setDeleting] = useState<string | null>(null);

  const authHeaders = { Authorization: `Bearer ${session?.access_token}`, "Content-Type": "application/json" };

  const fetchVideos = async () => {
    if (!session) return;
    try {
      const r = await fetch("/api/training-videos", { headers: authHeaders });
      const data = await r.json();
      setVideos(Array.isArray(data) ? data : []);
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Failed to load videos." });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchVideos(); }, [session]);

  const handleDelete = async (id: string) => {
    if (!confirm("Delete this video?")) return;
    setDeleting(id);
    try {
      await fetch(`/api/training-videos/${id}`, { method: "DELETE", headers: authHeaders });
      setVideos((prev) => prev.filter((v) => v.id !== id));
      toast({ title: "Video deleted" });
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Failed to delete." });
    } finally {
      setDeleting(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight flex items-center gap-2">
            <Video className="h-6 w-6 sm:h-7 sm:w-7 text-primary" />
            Training Videos
          </h1>
          <p className="text-muted-foreground mt-1">Learn and grow your business with curated training.</p>
        </div>
        <Link href="/training-videos/new">
          <Button className="gap-2">
            <Plus className="h-4 w-4" /> Upload Video
          </Button>
        </Link>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array(6).fill(0).map((_, i) => (
            <Card key={i} className="h-48">
              <div className="animate-pulse bg-muted h-32 rounded-t-lg" />
              <CardContent className="py-3">
                <div className="animate-pulse bg-muted h-4 w-3/4 rounded" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : videos.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center">
            <Video className="h-12 w-12 text-muted-foreground/40 mx-auto mb-3" />
            <p className="font-medium text-muted-foreground">No training videos yet</p>
            <p className="text-sm text-muted-foreground/70 mt-1">Upload your first training video to share knowledge.</p>
            <Link href="/training-videos/new">
              <Button className="mt-4 gap-2">
                <Plus className="h-4 w-4" /> Upload Video
              </Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {videos.map((v) => (
            <Card key={v.id} className="overflow-hidden group cursor-pointer hover:shadow-md transition-shadow" onClick={() => setPlaying(v)}>
              <div className="aspect-video bg-muted relative">
                {v.thumbnailUrl ? (
                  <img src={v.thumbnailUrl} alt={v.title} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-primary/10 to-primary/5 flex items-center justify-center">
                    <Video className="h-10 w-10 text-primary/30" />
                  </div>
                )}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/30">
                  <div className="bg-white/90 rounded-full p-3">
                    <Play className="h-6 w-6 text-primary fill-primary" />
                  </div>
                </div>
              </div>
              <CardContent className="pt-3 pb-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm truncate">{v.title}</p>
                    <p className="text-xs text-muted-foreground mt-0.5 capitalize">{v.category}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 text-muted-foreground hover:text-destructive shrink-0"
                    onClick={(e) => { e.stopPropagation(); handleDelete(v.id); }}
                    disabled={deleting === v.id}
                  >
                    {deleting === v.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={!!playing} onOpenChange={() => setPlaying(null)}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>{playing?.title}</DialogTitle>
          </DialogHeader>
          {playing && (
            <div className="space-y-3">
              <div className="aspect-video bg-black rounded-lg overflow-hidden">
                <video
                  src={playing.videoUrl}
                  className="w-full h-full"
                  controls
                  autoPlay
                  playsInline
                  poster={playing.thumbnailUrl || undefined}
                />
              </div>
              {playing.description && <p className="text-sm text-muted-foreground">{playing.description}</p>}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
