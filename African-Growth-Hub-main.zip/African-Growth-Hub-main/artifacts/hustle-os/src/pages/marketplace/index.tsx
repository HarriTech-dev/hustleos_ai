import { useEffect, useRef, useState } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { Card, CardContent, CardFooter } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Textarea } from "../../components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../../components/ui/dialog";
import { Badge } from "../../components/ui/badge";
import { Skeleton } from "../../components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../components/ui/tabs";
import { useToast } from "../../hooks/use-toast";
import { Store, Plus, MessageCircle, MapPin, Eye, Search, Package, Loader2, Trash2, ImagePlus, X, Play } from "lucide-react";
import { CURRENCY_LABELS, UNIQUE_CURRENCIES } from "../../lib/currencies";

interface Listing {
  id: string;
  tenantId: string;
  title: string;
  description: string;
  price: number;
  currency: string;
  category: string;
  imageUrl?: string | null;
  imageUrls?: string[];
  whatsappNumber?: string | null;
  location?: string | null;
  status: string;
  views: number;
  featured: boolean;
  createdAt: string;
}

const CATEGORIES = ["goods", "services", "digital", "food", "fashion", "electronics", "agriculture", "beauty", "other"];

const CATEGORY_COLORS: Record<string, string> = {
  goods: "bg-blue-100 text-blue-800",
  services: "bg-purple-100 text-purple-800",
  digital: "bg-cyan-100 text-cyan-800",
  food: "bg-orange-100 text-orange-800",
  fashion: "bg-pink-100 text-pink-800",
  electronics: "bg-indigo-100 text-indigo-800",
  agriculture: "bg-green-100 text-green-800",
  beauty: "bg-rose-100 text-rose-800",
  other: "bg-gray-100 text-gray-800",
};

function fmt(amount: number, currency: string) {
  try {
    return new Intl.NumberFormat("en-NG", { style: "currency", currency, minimumFractionDigits: 0 }).format(amount);
  } catch {
    return `${currency} ${amount.toLocaleString()}`;
  }
}

function isVideo(url: string) {
  return url.includes("/video/upload/") || /\.(mp4|webm|mov|ogg)(\?|$)/i.test(url);
}

const EMPTY_FORM = {
  title: "", description: "", price: "", currency: "NGN",
  category: "other", whatsappNumber: "", location: "", imageUrls: [] as string[],
};

export default function Marketplace() {
  const { session } = useAuth();
  const { toast } = useToast();
  const [listings, setListings] = useState<Listing[]>([]);
  const [myListings, setMyListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("all");
  const [deleting, setDeleting] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const authHeaders = { Authorization: `Bearer ${session?.access_token}`, "Content-Type": "application/json" };

  const fetchAll = async () => {
    const params = new URLSearchParams();
    if (search) params.set("search", search);
    if (category && category !== "all") params.set("category", category);
    const [all, mine] = await Promise.all([
      fetch(`/api/marketplace?${params}`).then((r) => r.json()),
      session ? fetch("/api/marketplace/my-listings", { headers: authHeaders }).then((r) => r.json()) : Promise.resolve([]),
    ]);
    setListings(Array.isArray(all) ? all : []);
    setMyListings(Array.isArray(mine) ? mine : []);
    setLoading(false);
  };

  useEffect(() => { fetchAll(); }, [session, search, category]);

  const set = (field: string, value: string) => setForm((f) => ({ ...f, [field]: value }));

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const isVideoFile = file.type.startsWith("video/");
    const maxBytes = isVideoFile ? 50 * 1024 * 1024 : 5 * 1024 * 1024;
    if (file.size > maxBytes) {
      toast({ variant: "destructive", title: "File too large", description: isVideoFile ? "Videos must be under 50 MB." : "Images must be under 5 MB." });
      return;
    }

    setUploading(true);
    try {
      const data = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });

      const res = await fetch("/api/upload", {
        method: "POST",
        headers: authHeaders,
        body: JSON.stringify({ data, folder: "marketplace" }),
      });
      if (!res.ok) throw new Error("Upload failed");
      const { url } = await res.json() as { url: string };
      setForm((f) => ({ ...f, imageUrls: [...f.imageUrls, url] }));
      toast({ title: "Media uploaded!", description: "Your photo/video is ready." });
    } catch {
      toast({ variant: "destructive", title: "Upload failed", description: "Please try again." });
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const removeImage = (index: number) => {
    setForm((f) => ({ ...f, imageUrls: f.imageUrls.filter((_, i) => i !== index) }));
  };

  const handleCreate = async () => {
    if (!form.title || !form.description || !form.price) {
      toast({ variant: "destructive", title: "Fill all required fields" });
      return;
    }
    setSaving(true);
    try {
      const r = await fetch("/api/marketplace", {
        method: "POST",
        headers: authHeaders,
        body: JSON.stringify({ ...form, price: Number(form.price), imageUrls: form.imageUrls.length > 0 ? form.imageUrls : undefined }),
      });
      if (!r.ok) throw new Error();
      toast({ title: "Listing created!", description: "Your listing is now live on the marketplace." });
      setShowCreate(false);
      setForm(EMPTY_FORM);
      fetchAll();
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Failed to create listing." });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    setDeleting(id);
    try {
      await fetch(`/api/marketplace/${id}`, { method: "DELETE", headers: authHeaders });
      setMyListings((prev) => prev.filter((l) => l.id !== id));
      setListings((prev) => prev.filter((l) => l.id !== id));
      toast({ title: "Listing deleted" });
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Failed to delete listing." });
    } finally {
      setDeleting(null);
    }
  };

  const recordView = (id: string) => fetch(`/api/marketplace/${id}/view`, { method: "POST" });

  const firstImage = (listing: Listing) => listing.imageUrls?.[0] ?? listing.imageUrl;

  const ListingCard = ({ listing }: { listing: Listing }) => {
    const [imgIdx, setImgIdx] = useState(0);
    const urls = listing.imageUrls && listing.imageUrls.length > 0 ? listing.imageUrls : (listing.imageUrl ? [listing.imageUrl] : []);
    const current = urls[imgIdx];
    const hasMultiple = urls.length > 1;

    return (
    <Card className="overflow-hidden flex flex-col hover:shadow-md transition-shadow">
      {current ? (
        <div className="aspect-video bg-muted overflow-hidden relative group">
          {isVideo(current) ? (
            <>
              <video
                src={current}
                className="w-full h-full object-cover"
                muted
                playsInline
                preload="metadata"
                onMouseEnter={(e) => (e.currentTarget as HTMLVideoElement).play()}
                onMouseLeave={(e) => { const v = e.currentTarget as HTMLVideoElement; v.pause(); v.currentTime = 0; }}
              />
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="bg-black/40 rounded-full p-2">
                  <Play className="h-5 w-5 text-white fill-white" />
                </div>
              </div>
            </>
          ) : (
            <img
              src={current}
              alt={listing.title}
              className="w-full h-full object-cover"
              onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
            />
          )}
          {hasMultiple && (
            <>
              <button
                className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/40 hover:bg-black/60 text-white rounded-full p-1.5 opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={(e) => { e.stopPropagation(); setImgIdx((i) => (i - 1 + urls.length) % urls.length); }}
              >
                <svg className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7" /></svg>
              </button>
              <button
                className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/40 hover:bg-black/60 text-white rounded-full p-1.5 opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={(e) => { e.stopPropagation(); setImgIdx((i) => (i + 1) % urls.length); }}
              >
                <svg className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7" /></svg>
              </button>
              <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex items-center gap-1">
                {urls.map((_, i) => (
                  <button
                    key={i}
                    className={`h-1.5 rounded-full transition-all ${i === imgIdx ? "w-4 bg-white" : "w-1.5 bg-white/50"}`}
                    onClick={(e) => { e.stopPropagation(); setImgIdx(i); }}
                  />
                ))}
              </div>
            </>
          )}
          {hasMultiple && (
            <div className="absolute top-2 right-2 bg-black/50 text-white text-xs px-2 py-0.5 rounded-full">
              {imgIdx + 1} / {urls.length}
            </div>
          )}
        </div>
      ) : (
        <div className="aspect-video bg-gradient-to-br from-primary/10 to-primary/5 flex items-center justify-center">
          <Package className="h-12 w-12 text-primary/30" />
        </div>
      )}
      <CardContent className="flex-1 pt-4 pb-2">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-semibold text-sm line-clamp-2 flex-1">{listing.title}</h3>
          {listing.featured && <Badge className="text-xs shrink-0">Featured</Badge>}
        </div>
        <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{listing.description}</p>
        <div className="flex items-center gap-1.5 mt-2 flex-wrap">
          <span className={`text-xs px-2 py-0.5 rounded-full capitalize ${CATEGORY_COLORS[listing.category] ?? CATEGORY_COLORS.other}`}>
            {listing.category}
          </span>
          {listing.location && (
            <span className="text-xs text-muted-foreground flex items-center gap-0.5">
              <MapPin className="h-3 w-3" />{listing.location}
            </span>
          )}
        </div>
      </CardContent>
      <CardFooter className="pt-2 pb-4 flex items-center justify-between">
        <p className="font-bold text-primary">{fmt(listing.price, listing.currency)}</p>
        <div className="flex gap-1.5">
          {listing.whatsappNumber && (
            <Button
              size="sm"
              className="gap-1 text-xs h-8 bg-green-600 hover:bg-green-700"
              onClick={() => { recordView(listing.id); window.open(`https://wa.me/${listing.whatsappNumber?.replace(/\D/g, "")}?text=Hi, I'm interested in "${listing.title}"`, "_blank"); }}
            >
              <MessageCircle className="h-3.5 w-3.5" /> Contact
            </Button>
          )}
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <Eye className="h-3 w-3" /> {listing.views}
          </div>
        </div>
      </CardFooter>
    </Card>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight flex items-center gap-2">
            <Store className="h-6 w-6 sm:h-7 sm:w-7 text-primary" />
            Marketplace
          </h1>
          <p className="text-muted-foreground mt-1">Buy, sell, and discover products & services from African businesses.</p>
        </div>
        {session && (
          <Button onClick={() => setShowCreate(true)} className="gap-1.5 shrink-0 w-full sm:w-auto">
            <Plus className="h-4 w-4" /> List Item
          </Button>
        )}
      </div>

      <Tabs defaultValue="browse">
        <TabsList>
          <TabsTrigger value="browse">Browse All</TabsTrigger>
          {session && <TabsTrigger value="mine">My Listings ({myListings.length})</TabsTrigger>}
        </TabsList>

        <TabsContent value="browse" className="space-y-4 mt-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search listings..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="All categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All categories</SelectItem>
                {CATEGORIES.map((c) => (
                  <SelectItem key={c} value={c} className="capitalize">{c}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {Array(6).fill(0).map((_, i) => <Skeleton key={i} className="h-64" />)}
            </div>
          ) : listings.length === 0 ? (
            <Card>
              <CardContent className="py-16 text-center">
                <Store className="h-12 w-12 text-muted-foreground/40 mx-auto mb-3" />
                <p className="font-medium text-muted-foreground">No listings found</p>
                <p className="text-sm text-muted-foreground/70 mt-1">Be the first to list your product or service.</p>
                {session && (
                  <Button className="mt-4 gap-1.5" onClick={() => setShowCreate(true)}>
                    <Plus className="h-4 w-4" /> Create Listing
                  </Button>
                )}
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {listings.map((l) => <ListingCard key={l.id} listing={l} />)}
            </div>
          )}
        </TabsContent>

        {session && (
          <TabsContent value="mine" className="space-y-4 mt-4">
            {myListings.length === 0 ? (
              <Card>
                <CardContent className="py-16 text-center">
                  <Package className="h-12 w-12 text-muted-foreground/40 mx-auto mb-3" />
                  <p className="font-medium text-muted-foreground">No listings yet</p>
                  <Button className="mt-4 gap-1.5" onClick={() => setShowCreate(true)}>
                    <Plus className="h-4 w-4" /> Create Your First Listing
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {myListings.map((l) => (
                  <div key={l.id} className="flex items-center gap-3 p-4 rounded-xl border bg-card hover:shadow-sm transition-shadow">
                    {firstImage(l) && (
                      <div className="h-14 w-14 rounded-lg overflow-hidden shrink-0 bg-muted">
                        {isVideo(firstImage(l)!) ? (
                          <video src={firstImage(l)!} className="h-full w-full object-cover" muted playsInline preload="metadata" />
                        ) : (
                          <img src={firstImage(l)!} alt={l.title} className="h-full w-full object-cover" />
                        )}
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-semibold text-sm truncate">{l.title}</p>
                        <span className={`text-xs px-2 py-0.5 rounded-full capitalize ${CATEGORY_COLORS[l.category] ?? CATEGORY_COLORS.other}`}>
                          {l.category}
                        </span>
                        <Badge variant={l.status === "active" ? "default" : "secondary"} className="text-xs">{l.status}</Badge>
                      </div>
                      <div className="flex items-center gap-3 mt-1">
                        <p className="text-sm font-bold text-primary">{fmt(l.price, l.currency)}</p>
                        <span className="text-xs text-muted-foreground flex items-center gap-0.5"><Eye className="h-3 w-3" /> {l.views} views</span>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleDelete(l.id)}
                      disabled={deleting === l.id}
                      className="gap-1.5"
                    >
                      {deleting === l.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
                      Delete
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>
        )}
      </Tabs>

      <Dialog open={showCreate} onOpenChange={(open) => { setShowCreate(open); if (!open) setForm(EMPTY_FORM); }}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create Marketplace Listing</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid gap-2">
              <Label>Title *</Label>
              <Input value={form.title} onChange={(e) => set("title", e.target.value)} placeholder="e.g. Fresh Tomatoes per basket" />
            </div>
            <div className="grid gap-2">
              <Label>Description *</Label>
              <Textarea value={form.description} onChange={(e) => set("description", e.target.value)} rows={3} placeholder="Describe what you're selling..." />
            </div>

            <div className="grid gap-2">
              <Label>Product Photos / Videos</Label>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,video/*"
                className="hidden"
                onChange={handleFileChange}
              />
              {form.imageUrls.length > 0 ? (
                <div className="grid grid-cols-3 gap-2">
                  {form.imageUrls.map((url, i) => (
                    <div key={i} className="relative rounded-lg overflow-hidden bg-muted aspect-square">
                      {isVideo(url) ? (
                        <video src={url} className="w-full h-full object-cover" muted playsInline preload="metadata" />
                      ) : (
                        <img src={url} alt={`Preview ${i + 1}`} className="w-full h-full object-cover" />
                      )}
                      <Button
                        size="icon"
                        variant="destructive"
                        className="absolute top-1 right-1 h-5 w-5"
                        onClick={() => removeImage(i)}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploading}
                    className="flex flex-col items-center justify-center gap-1 border-2 border-dashed border-border rounded-lg aspect-square text-muted-foreground hover:border-primary/50 hover:text-primary transition-colors disabled:opacity-50"
                  >
                    {uploading ? (
                      <Loader2 className="h-5 w-5 animate-spin" />
                    ) : (
                      <><ImagePlus className="h-5 w-5" /><span className="text-xs font-medium">Add more</span></>
                    )}
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploading}
                  className="flex flex-col items-center justify-center gap-2 border-2 border-dashed border-border rounded-lg p-6 text-muted-foreground hover:border-primary/50 hover:text-primary transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {uploading ? (
                    <><Loader2 className="h-8 w-8 animate-spin" /><span className="text-sm">Uploading…</span></>
                  ) : (
                    <><ImagePlus className="h-8 w-8" /><span className="text-sm font-medium">Click to add photos/videos</span><span className="text-xs">Image up to 5 MB · Video up to 50 MB</span></>
                  )}
                </button>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-2">
                <Label>Price *</Label>
                <Input type="number" value={form.price} onChange={(e) => set("price", e.target.value)} placeholder="0" />
              </div>
              <div className="grid gap-2">
                <Label>Currency</Label>
                <Select value={form.currency} onValueChange={(v) => set("currency", v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {UNIQUE_CURRENCIES.map((c) => <SelectItem key={c} value={c}>{CURRENCY_LABELS[c] ?? c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid gap-2">
              <Label>Category</Label>
              <Select value={form.category} onValueChange={(v) => set("category", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((c) => <SelectItem key={c} value={c} className="capitalize">{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label>WhatsApp Number</Label>
              <Input value={form.whatsappNumber} onChange={(e) => set("whatsappNumber", e.target.value)} placeholder="+234 800 000 0000" />
            </div>
            <div className="grid gap-2">
              <Label>Location</Label>
              <Input value={form.location} onChange={(e) => set("location", e.target.value)} placeholder="e.g. Lagos Island, Nigeria" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setShowCreate(false); setForm(EMPTY_FORM); }}>Cancel</Button>
            <Button onClick={handleCreate} disabled={saving || uploading} className="gap-2">
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              Publish Listing
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
