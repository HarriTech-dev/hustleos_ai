import { useState, useEffect } from "react";
import { useRoute } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Skeleton } from "../../components/ui/skeleton";
import { useAuth } from "../../contexts/AuthContext";
import { Link } from "wouter";
import { supabase } from "../../lib/supabase";
import { useToast } from "../../hooks/use-toast";
import { UsersRound, CheckCircle, AlertCircle, Loader2 } from "lucide-react";

interface InviteDetails {
  id: string;
  name: string;
  email: string;
  role: string;
  businessName: string;
  inviterName: string;
}

export default function JoinPage() {
  const [match, params] = useRoute("/join/:token");
  const token = params?.token || "";
  const { user, session } = useAuth();
  const { toast } = useToast();

  const [invite, setInvite] = useState<InviteDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [accepting, setAccepting] = useState(false);
  const [accepted, setAccepted] = useState(false);

  // Login/register form state
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [isLogin, setIsLogin] = useState(true);
  const [authLoading, setAuthLoading] = useState(false);

  // Fetch invite details
  useEffect(() => {
    if (!token) return;
    fetch(`/api/team/invite/${token}`)
      .then(async (res) => {
        if (!res.ok) {
          const data = await res.json();
          throw new Error(data.error || "Invitation not found");
        }
        return res.json();
      })
      .then((data) => {
        setInvite(data);
        setEmail(data.email);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [token]);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);
    try {
      if (isLogin) {
        const { data, error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        if (data.session) {
          toast({ title: "Signed in! Accepting invitation..." });
          await acceptInvite(data.session.access_token);
        }
      } else {
        const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { name } } });
        if (error) throw error;
        // Immediately sign in after signup
        const { data: signInData, error: signInError } = await supabase.auth.signInWithPassword({ email, password });
        if (signInError) throw signInError;
        if (signInData.session) {
          toast({ title: "Account created! Accepting invitation..." });
          await acceptInvite(signInData.session.access_token);
        }
      }
    } catch (err: any) {
      toast({ variant: "destructive", title: err.message || "Authentication failed" });
    } finally {
      setAuthLoading(false);
    }
  };

  const acceptInvite = async (token: string) => {
    setAccepting(true);
    try {
      const res = await fetch(`/api/team/invite/${params?.token}/accept`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Failed to accept invitation");
      }
      setAccepted(true);
      toast({ title: "Welcome to the team!", description: `You now have access to ${invite?.businessName}.` });
    } catch (err: any) {
      toast({ variant: "destructive", title: err.message || "Failed to accept invitation" });
    } finally {
      setAccepting(false);
    }
  };

  const handleAccept = async () => {
    if (!session) return;
    await acceptInvite(session.access_token);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="w-full max-w-md">
          <CardContent className="p-6 space-y-4">
            <Skeleton className="h-8 w-3/4" />
            <Skeleton className="h-4 w-1/2" />
            <Skeleton className="h-20 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="w-full max-w-md">
          <CardContent className="p-6 text-center space-y-4">
            <AlertCircle className="h-12 w-12 text-destructive mx-auto" />
            <h2 className="text-xl font-semibold">Invitation Error</h2>
            <p className="text-muted-foreground">{error}</p>
            <Link href="/">
              <Button className="w-full">Go to Dashboard</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (accepted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="w-full max-w-md">
          <CardContent className="p-6 text-center space-y-4">
            <CheckCircle className="h-12 w-12 text-green-500 mx-auto" />
            <h2 className="text-xl font-semibold">You're In!</h2>
            <p className="text-muted-foreground">
              You have joined {invite?.businessName} as a {invite?.role}.
            </p>
            <Link href="/">
              <Button className="w-full">Go to Dashboard</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-2 h-10 w-10 rounded-lg bg-primary flex items-center justify-center text-primary-foreground">
            <UsersRound className="h-5 w-5" />
          </div>
          <CardTitle>Team Invitation</CardTitle>
          <CardDescription>
            {invite?.inviterName} invited you to join <strong>{invite?.businessName}</strong>
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="rounded-lg bg-muted/50 p-4 text-center">
            <p className="font-medium text-sm">{invite?.name}</p>
            <p className="text-xs text-muted-foreground">{invite?.email}</p>
            <p className="text-xs text-primary mt-1 font-medium uppercase">Role: {invite?.role}</p>
          </div>

          {user ? (
            <div className="space-y-3">
              <p className="text-sm text-center text-muted-foreground">
                Signed in as <strong>{user.email}</strong>
              </p>
              <Button onClick={handleAccept} disabled={accepting} className="w-full gap-2">
                {accepting ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle className="h-4 w-4" />}
                Accept Invitation
              </Button>
            </div>
          ) : (
            <form onSubmit={handleAuth} className="space-y-3">
              <div className="flex gap-2 text-sm">
                <button type="button" className={`flex-1 py-2 rounded-md text-center ${isLogin ? "bg-primary text-primary-foreground" : "bg-muted"}`} onClick={() => setIsLogin(true)}>
                  Sign In
                </button>
                <button type="button" className={`flex-1 py-2 rounded-md text-center ${!isLogin ? "bg-primary text-primary-foreground" : "bg-muted"}`} onClick={() => setIsLogin(false)}>
                  Create Account
                </button>
              </div>

              {!isLogin && (
                <div className="grid gap-2">
                  <Label>Full Name</Label>
                  <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" required={!isLogin} />
                </div>
              )}
              <div className="grid gap-2">
                <Label>Email</Label>
                <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" required />
              </div>
              <div className="grid gap-2">
                <Label>Password</Label>
                <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" required minLength={6} />
              </div>
              <Button type="submit" disabled={authLoading} className="w-full">
                {authLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : isLogin ? "Sign In & Accept" : "Create Account & Accept"}
              </Button>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
