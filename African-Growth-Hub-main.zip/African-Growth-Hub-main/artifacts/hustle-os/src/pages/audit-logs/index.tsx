import { useEffect, useState } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../../components/ui/card";
import { Skeleton } from "../../components/ui/skeleton";
import { Badge } from "../../components/ui/badge";
import { Input } from "../../components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import { Shield, Search, User, Package, FileText, Users, CreditCard, ArrowLeftRight } from "lucide-react";

interface AuditLog {
  id: string;
  userId: string;
  action: string;
  resource: string;
  resourceId?: string | null;
  changes?: Record<string, unknown> | null;
  ipAddress?: string | null;
  userAgent?: string | null;
  createdAt: string;
}

const RESOURCE_ICONS: Record<string, React.ElementType> = {
  invoice: FileText,
  customer: Users,
  inventory: Package,
  transaction: ArrowLeftRight,
  team: Users,
  subscription: CreditCard,
  auth: User,
};

const ACTION_COLORS: Record<string, string> = {
  create: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
  update: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  delete: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
  login: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300",
  logout: "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300",
  send: "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300",
  mark_paid: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300",
};

const RESOURCES = ["all", "invoice", "customer", "inventory", "transaction", "team", "subscription", "auth"];

function timeAgo(dateStr: string) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "Just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  return `${d}d ago`;
}

export default function AuditLogs() {
  const { session } = useAuth();
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [resource, setResource] = useState("all");
  const [search, setSearch] = useState("");

  useEffect(() => {
    if (!session) return;
    const params = new URLSearchParams();
    if (resource && resource !== "all") params.set("resource", resource);
    fetch(`/api/audit-logs?${params}`, {
      headers: { Authorization: `Bearer ${session.access_token}` },
    })
      .then((r) => r.json())
      .then((data) => { setLogs(Array.isArray(data) ? data : []); setLoading(false); })
      .catch(() => setLoading(false));
  }, [session, resource]);

  const filtered = search
    ? logs.filter((l) =>
        l.action.toLowerCase().includes(search.toLowerCase()) ||
        l.resource.toLowerCase().includes(search.toLowerCase()) ||
        (l.resourceId ?? "").toLowerCase().includes(search.toLowerCase())
      )
    : logs;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight flex items-center gap-2">
            <Shield className="h-6 w-6 sm:h-7 sm:w-7 text-primary" />
            Audit Logs
          </h1>
          <p className="text-muted-foreground mt-1">Track all actions across your business account.</p>
        </div>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search actions..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={resource} onValueChange={setResource}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="All resources" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All resources</SelectItem>
                {RESOURCES.filter((r) => r !== "all").map((r) => (
                  <SelectItem key={r} value={r} className="capitalize">{r}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="space-y-3">
              {Array(6).fill(0).map((_, i) => <Skeleton key={i} className="h-14 w-full" />)}
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-12">
              <Shield className="h-10 w-10 text-muted-foreground/40 mx-auto mb-3" />
              <p className="text-muted-foreground">No audit logs found.</p>
              <p className="text-sm text-muted-foreground/70 mt-1">Actions will appear here as your team uses HustleOS.</p>
            </div>
          ) : (
            <div className="space-y-1.5">
              {filtered.map((log) => {
                const Icon = RESOURCE_ICONS[log.resource] ?? Shield;
                const actionColor = ACTION_COLORS[log.action.toLowerCase()] ?? "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300";
                return (
                  <div key={log.id} className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted/40 transition-colors border border-transparent hover:border-border">
                    <div className="p-1.5 rounded-md bg-muted shrink-0">
                      <Icon className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium ${actionColor}`}>
                          {log.action}
                        </span>
                        <span className="text-sm capitalize font-medium">{log.resource}</span>
                        {log.resourceId && (
                          <span className="text-xs text-muted-foreground font-mono hidden sm:block">
                            #{log.resourceId.slice(0, 8)}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-xs text-muted-foreground">{timeAgo(log.createdAt)}</p>
                      <p className="text-xs text-muted-foreground/60 hidden sm:block">
                        {new Date(log.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
