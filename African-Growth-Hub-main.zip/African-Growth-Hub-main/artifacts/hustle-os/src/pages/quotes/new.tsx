import { useState } from "react";
import { useLocation } from "wouter";
import { useListCustomers } from "@workspace/api-client-react";
import { useAuth } from "../../contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Textarea } from "../../components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import { Separator } from "../../components/ui/separator";
import { useToast } from "../../hooks/use-toast";
import { formatCurrency } from "../../lib/format";
import { Plus, Trash2, ArrowLeft, Loader2, FileSpreadsheet } from "lucide-react";
import { Link } from "wouter";

interface LineItem {
  name: string;
  description: string;
  quantity: number;
  unitPrice: number;
}

import { CURRENCY_LABELS, UNIQUE_CURRENCIES } from "../../lib/currencies";

function newItem(): LineItem {
  return { name: "", description: "", quantity: 1, unitPrice: 0 };
}

export default function NewQuote() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { session } = useAuth();
  const { data: customers } = useListCustomers({});

  const [customerId, setCustomerId] = useState("");
  const [currency, setCurrency] = useState("NGN");
  const [taxRate, setTaxRate] = useState(0);
  const [discountRate, setDiscountRate] = useState(0);
  const [validUntil, setValidUntil] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 14);
    return d.toISOString().slice(0, 10);
  });
  const [notes, setNotes] = useState("");
  const [items, setItems] = useState<LineItem[]>([newItem()]);
  const [creating, setCreating] = useState(false);

  const subtotal = items.reduce((s, i) => s + i.quantity * i.unitPrice, 0);
  const discount = subtotal * (discountRate / 100);
  const tax = (subtotal - discount) * (taxRate / 100);
  const total = Math.max(0, subtotal - discount + tax);

  const setItem = (index: number, field: keyof LineItem, value: string | number) => {
    setItems((prev) => prev.map((item, i) => i === index ? { ...item, [field]: value } : item));
  };
  const removeItem = (index: number) => {
    if (items.length === 1) return;
    setItems((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (asDraft = false) => {
    if (!customerId) { toast({ variant: "destructive", title: "Select a customer" }); return; }
    if (items.some((i) => !i.name || i.quantity <= 0)) { toast({ variant: "destructive", title: "Fill all line items" }); return; }
    if (!validUntil) { toast({ variant: "destructive", title: "Set a valid until date" }); return; }

    setCreating(true);
    try {
      const r = await fetch("/api/quotes", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({
          customerId,
          items: items.map((i) => ({ description: i.name + (i.description ? " - " + i.description : ""), quantity: i.quantity, unitPrice: i.unitPrice, total: i.quantity * i.unitPrice })),
          tax,
          discount,
          currency,
          notes: notes || undefined,
          validUntil,
        }),
      });
      const quote = await r.json();
      if (!asDraft && quote.id) {
        try { await fetch(`/api/quotes/${quote.id}/send`, { method: "POST", headers: { Authorization: `Bearer ${session?.access_token}` } }); } catch { }
      }
      toast({ title: asDraft ? "Quote saved as draft" : "Quote created!" });
      navigate(`/quotes/${quote.id}`);
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Failed to create quote." });
    } finally {
      setCreating(false);
    }
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <div className="flex items-center gap-4">
        <Link href="/quotes">
          <Button variant="ghost" size="icon" className="h-9 w-9"><ArrowLeft className="h-4 w-4" /></Button>
        </Link>
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight flex items-center gap-2">
            <FileSpreadsheet className="h-6 w-6" /> Create Quote
          </h1>
          <p className="text-muted-foreground mt-1">Create a professional quotation for your customer.</p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-[1fr_280px]">
        <div className="space-y-6">
          <Card>
            <CardHeader><CardTitle className="text-base">Customer</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-2">
                <Label>Select Customer *</Label>
                <Select value={customerId} onValueChange={setCustomerId}>
                  <SelectTrigger><SelectValue placeholder="Choose a customer..." /></SelectTrigger>
                  <SelectContent>
                    {(customers || []).map((c) => (
                      <SelectItem key={c.id} value={c.id}>{c.name} — {c.email}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                <CardTitle className="text-base">Line Items</CardTitle>
                <Button variant="outline" size="sm" onClick={() => setItems((p) => [...p, newItem()])} className="gap-1 h-8">
                  <Plus className="h-3 w-3" /> Add Item
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {items.map((item, index) => (
                <div key={index} className="space-y-3 pb-4 border-b last:border-0 last:pb-0">
                  <div className="flex items-start gap-2">
                    <div className="flex-1 grid gap-2">
                      <Input placeholder="Item name *" value={item.name} onChange={(e) => setItem(index, "name", e.target.value)} />
                      <Input placeholder="Description (optional)" value={item.description} onChange={(e) => setItem(index, "description", e.target.value)} className="text-sm" />
                    </div>
                    <Button variant="ghost" size="icon" className="h-9 w-9 text-muted-foreground hover:text-destructive shrink-0" onClick={() => removeItem(index)} disabled={items.length === 1}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="grid gap-1"><Label className="text-xs">Qty</Label><Input type="number" min="1" value={item.quantity} onChange={(e) => setItem(index, "quantity", Number(e.target.value))} /></div>
                    <div className="grid gap-1"><Label className="text-xs">Unit Price ({currency})</Label><Input type="number" min="0" step="0.01" value={item.unitPrice} onChange={(e) => setItem(index, "unitPrice", Number(e.target.value))} /></div>
                    <div className="grid gap-1"><Label className="text-xs">Total</Label><div className="h-10 flex items-center px-3 rounded-md border bg-muted text-sm font-medium">{formatCurrency(item.quantity * item.unitPrice, currency)}</div></div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle className="text-base">Notes</CardTitle></CardHeader>
            <CardContent>
              <Textarea placeholder="Terms, notes, or special instructions..." value={notes} onChange={(e) => setNotes(e.target.value)} className="min-h-[80px]" />
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader><CardTitle className="text-base">Settings</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-2">
                <Label>Currency</Label>
                <Select value={currency} onValueChange={setCurrency}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{UNIQUE_CURRENCIES.map((c) => <SelectItem key={c} value={c}>{CURRENCY_LABELS[c] ?? c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label>Valid Until *</Label>
                <Input type="date" value={validUntil} onChange={(e) => setValidUntil(e.target.value)} />
              </div>
              <div className="grid gap-2">
                <Label>Discount (%)</Label>
                <Input
                  type="number"
                  min="0"
                  max="100"
                  step="0.1"
                  value={discountRate || ""}
                  onChange={(e) => setDiscountRate(Math.min(100, Math.max(0, Number(e.target.value))))}
                  placeholder="0"
                />
              </div>
              <div className="grid gap-2">
                <Label>Tax Rate (%)</Label>
                <Input
                  type="number"
                  min="0"
                  max="100"
                  step="0.1"
                  value={taxRate || ""}
                  onChange={(e) => setTaxRate(Math.min(100, Math.max(0, Number(e.target.value))))}
                  placeholder="0"
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle className="text-base">Summary</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between text-sm"><span className="text-muted-foreground">Subtotal</span><span>{formatCurrency(subtotal, currency)}</span></div>
              {discountRate > 0 && <div className="flex justify-between text-sm text-red-600"><span className="text-muted-foreground">Discount ({discountRate}%)</span><span>-{formatCurrency(discount, currency)}</span></div>}
              {taxRate > 0 && <div className="flex justify-between text-sm"><span className="text-muted-foreground">Tax ({taxRate}%)</span><span>{formatCurrency(tax, currency)}</span></div>}
              <Separator />
              <div className="flex justify-between font-bold text-lg"><span>Total</span><span className="text-primary">{formatCurrency(total, currency)}</span></div>
            </CardContent>
          </Card>

          <div className="space-y-2">
            <Button className="w-full gap-2" onClick={() => handleSubmit(false)} disabled={creating}>
              {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : null} Create & Send Quote
            </Button>
            <Button variant="outline" className="w-full" onClick={() => handleSubmit(true)} disabled={creating}>Save as Draft</Button>
          </div>
        </div>
      </div>
    </div>
  );
}
