import { useParams, useLocation } from "wouter";
import { useAuth } from "../../contexts/AuthContext";
import { Badge } from "../../components/ui/badge";
import { Button } from "../../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Separator } from "../../components/ui/separator";
import { Skeleton } from "../../components/ui/skeleton";
import { useToast } from "../../hooks/use-toast";
import { ArrowLeft, Printer, Trash2, Loader2, Send, FileText, CheckCircle } from "lucide-react";
import { useState, useEffect } from "react";

interface QuoteItem {
  name: string;
  description?: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

interface Quote {
  id: string;
  quoteNumber: string;
  customerName: string;
  customerEmail: string | null;
  status: string;
  items: QuoteItem[];
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  currency: string;
  notes: string | null;
  validUntil: string;
  invoiceId: string | null;
  createdAt: string;
}

const STATUS_COLORS: Record<string, string> = {
  draft: "bg-muted text-muted-foreground",
  sent: "bg-blue-100 text-blue-800",
  accepted: "bg-green-100 text-green-800",
  rejected: "bg-red-100 text-red-800",
  converted: "bg-purple-100 text-purple-800",
};

function fmt(amount: number, currency: string) {
  return new Intl.NumberFormat("en-NG", { style: "currency", currency, minimumFractionDigits: 2 }).format(amount);
}

export default function QuoteDetail() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { session } = useAuth();
  const { toast } = useToast();
  const [quote, setQuote] = useState<Quote | null>(null);
  const [loading, setLoading] = useState(true);
  const [acting, setActing] = useState<string | null>(null);

  const authHeaders = { Authorization: `Bearer ${session?.access_token}`, "Content-Type": "application/json" };

  useEffect(() => {
    if (!id || !session) return;
    fetch(`/api/quotes/${id}`, { headers: authHeaders })
      .then((r) => r.json())
      .then((data) => { setQuote(data); setLoading(false); })
      .catch(() => setLoading(false));
  }, [id, session]);

  const doAction = async (action: string) => {
    if (!quote) return;
    setActing(action);
    try {
      if (action === "delete") {
        await fetch(`/api/quotes/${id}`, { method: "DELETE", headers: authHeaders });
        toast({ title: "Quote deleted" });
        navigate("/quotes");
        return;
      }
      if (action === "convert") {
        const r = await fetch(`/api/quotes/${id}/convert`, { method: "POST", headers: authHeaders });
        const data = await r.json();
        toast({ title: "Quote converted to invoice" });
        navigate(`/invoices/${data.invoice.id}`);
        return;
      }
      const r = await fetch(`/api/quotes/${id}`, { method: "PATCH", headers: authHeaders, body: JSON.stringify({ status: action }) });
      const updated = await r.json();
      setQuote(updated);
      toast({ title: `Status updated to ${action}` });
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Action failed." });
    } finally {
      setActing(null);
    }
  };

  const printQuote = () => window.print();

  if (loading) return <div className="space-y-6 max-w-3xl mx-auto"><Skeleton className="h-8 w-48" /><Skeleton className="h-64 w-full" /></div>;
  if (!quote) return <div className="text-center py-20"><p className="text-muted-foreground">Quote not found.</p><Button variant="ghost" onClick={() => navigate("/quotes")} className="mt-4 gap-2"><ArrowLeft className="h-4 w-4" /> Back to Quotes</Button></div>;

  return (
    <div className="space-y-6 max-w-3xl mx-auto print:max-w-full">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 print:hidden">
        <Button variant="ghost" onClick={() => navigate("/quotes")} className="gap-2 -ml-2"><ArrowLeft className="h-4 w-4" /> Quotes</Button>
        <div className="flex gap-2 flex-wrap">
          {quote.status === "draft" && (
            <Button size="sm" variant="outline" onClick={() => doAction("sent")} disabled={!!acting} className="gap-1.5">
              {acting === "sent" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />} Send
            </Button>
          )}
          {quote.status === "sent" && (
            <>
              <Button size="sm" variant="outline" onClick={() => doAction("accepted")} disabled={!!acting} className="gap-1.5">
                <CheckCircle className="h-3.5 w-3.5" /> Accept
              </Button>
              <Button size="sm" variant="outline" onClick={() => doAction("rejected")} disabled={!!acting} className="gap-1.5">
                <Trash2 className="h-3.5 w-3.5" /> Reject
              </Button>
            </>
          )}
          {quote.status !== "converted" && (
            <Button size="sm" onClick={() => doAction("convert")} disabled={!!acting} className="gap-1.5">
              {acting === "convert" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <FileText className="h-3.5 w-3.5" />}
              Convert to Invoice
            </Button>
          )}
          <Button size="sm" variant="outline" onClick={printQuote} className="gap-1.5"><Printer className="h-3.5 w-3.5" /> Print</Button>
          <Button size="sm" variant="destructive" onClick={() => doAction("delete")} disabled={!!acting} className="gap-1.5">
            {acting === "delete" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />} Delete
          </Button>
        </div>
      </div>

      <Card className="print:shadow-none print:border-0">
        <CardHeader className="pb-4">
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-primary font-bold text-xl mb-1">
                <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground text-sm font-bold">H</div>
                HustleOS
              </div>
              <p className="text-sm text-muted-foreground">Business Management Platform</p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-primary">{quote.quoteNumber}</p>
              <span className={`inline-block mt-1 px-2.5 py-0.5 rounded-full text-xs font-medium ${STATUS_COLORS[quote.status]}`}>
                {quote.status.toUpperCase()}
              </span>
              {quote.invoiceId && <p className="text-xs text-purple-600 mt-1">Converted to invoice</p>}
            </div>
          </div>
        </CardHeader>
        <Separator />
        <CardContent className="pt-6 space-y-6">
          <div className="grid grid-cols-2 gap-6">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Quote For</p>
              <p className="font-semibold text-base">{quote.customerName}</p>
              {quote.customerEmail && <p className="text-sm text-muted-foreground">{quote.customerEmail}</p>}
            </div>
            <div className="text-right">
              <div className="space-y-1">
                <div><p className="text-xs text-muted-foreground">Issue Date</p><p className="font-medium text-sm">{new Date(quote.createdAt).toLocaleDateString()}</p></div>
                <div><p className="text-xs text-muted-foreground">Valid Until</p><p className="font-medium text-sm">{new Date(quote.validUntil).toLocaleDateString()}</p></div>
              </div>
            </div>
          </div>
          <div className="rounded-lg border overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-muted/50"><tr><th className="text-left p-3 font-semibold">Item</th><th className="text-center p-3 font-semibold">Qty</th><th className="text-right p-3 font-semibold">Unit Price</th><th className="text-right p-3 font-semibold">Total</th></tr></thead>
              <tbody className="divide-y">
                {(quote.items || []).map((item, i) => (
                  <tr key={i} className="hover:bg-muted/20">
                    <td className="p-3"><p className="font-medium">{item.name}</p>{item.description && <p className="text-xs text-muted-foreground">{item.description}</p>}</td>
                    <td className="p-3 text-center text-muted-foreground">{item.quantity}</td>
                    <td className="p-3 text-right text-muted-foreground">{fmt(item.unitPrice, quote.currency)}</td>
                    <td className="p-3 text-right font-medium">{fmt(item.total, quote.currency)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex justify-end">
            <div className="w-64 space-y-2">
              <div className="flex justify-between text-sm"><span className="text-muted-foreground">Subtotal</span><span>{fmt(quote.subtotal, quote.currency)}</span></div>
              {quote.discount > 0 && <div className="flex justify-between text-sm text-red-600"><span className="text-muted-foreground">Discount</span><span>-{fmt(quote.discount, quote.currency)}</span></div>}
              {quote.tax > 0 && <div className="flex justify-between text-sm"><span className="text-muted-foreground">Tax</span><span>{fmt(quote.tax, quote.currency)}</span></div>}
              <Separator />
              <div className="flex justify-between font-bold text-base"><span>Total</span><span className="text-primary">{fmt(quote.total, quote.currency)}</span></div>
            </div>
          </div>
          {quote.notes && <div className="bg-muted/40 rounded-lg p-4"><p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1">Notes</p><p className="text-sm">{quote.notes}</p></div>}
          <div className="text-center text-xs text-muted-foreground pt-2 border-t print:block">Generated by HustleOS AI — Built for African Entrepreneurs</div>
        </CardContent>
      </Card>
    </div>
  );
}
