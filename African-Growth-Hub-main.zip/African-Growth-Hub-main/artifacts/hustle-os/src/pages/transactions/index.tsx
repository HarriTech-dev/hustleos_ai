import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getGetDashboardSummaryQueryKey, getGetRecentActivityQueryKey, getGetRevenueChartQueryKey } from "@workspace/api-client-react";
import { useAuth } from "../../contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Badge } from "../../components/ui/badge";
import { Skeleton } from "../../components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import { Label } from "../../components/ui/label";
import { Textarea } from "../../components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "../../components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../../components/ui/table";
import { useToast } from "../../hooks/use-toast";
import { formatCurrency, formatCurrencyCompact } from "../../lib/format";
import { Plus, Sparkles, TrendingUp, TrendingDown, DollarSign, Trash2, Loader2, Search, X, ArrowLeft, ArrowRight, RotateCcw, User, Package, Receipt, CreditCard, Repeat } from "lucide-react";
import { cn } from "../../lib/utils";

interface TxItem {
  inventoryId?: string | null;
  productName: string;
  quantity: number;
  unitPrice: number;
  subtotal?: number;
}

interface Transaction {
  id: string;
  type: "income" | "expense" | "sale" | "transfer" | "refund";
  amount: number;
  description: string;
  category: string;
  date: string;
  notes: string | null;
  parsedFrom: string | null;
  paymentMethod: string | null;
  customerId: string | null;
  items: TxItem[];
  createdAt: string;
}

interface Summary {
  totalIncome: number;
  totalExpenses: number;
  totalRefunds: number;
  netRevenue: number;
  profit: number;
  count: number;
}

interface Customer {
  id: string;
  name: string;
  email: string;
  phone?: string | null;
}

interface InventoryItem {
  id: string;
  name: string;
  quantity: number;
  price: number;
  unit: string;
}

const CATEGORIES = {
  income: ["sales", "services", "consulting", "commission", "investment", "interest", "other"],
  expense: ["rent", "utilities", "salaries", "marketing", "transport", "food", "equipment", "inventory", "fuel", "internet", "other"],
  sale: ["sales"],
  transfer: ["transfer"],
  refund: ["refund", "return"],
};

const PAYMENT_METHODS = ["cash", "bank_transfer", "card", "mobile_money", "pos", "cheque", "other"];

async function apiFetch<T>(url: string, accessToken: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...options,
    headers: {
      ...options?.headers,
      Authorization: `Bearer ${accessToken}`,
    },
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error((err as { error?: string }).error || "Request failed");
  }
  if (res.status === 204) return undefined as T;
  return res.json();
}

export default function Transactions() {
  const { session } = useAuth();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [showAdd, setShowAdd] = useState(false);
  const [showNLP, setShowNLP] = useState(false);
  const [nlpText, setNlpText] = useState("");
  const [parsedTx, setParsedTx] = useState<Partial<Transaction> | null>(null);
  const [formType, setFormType] = useState<"income" | "expense" | "sale" | "transfer" | "refund">("income");
  const qc = useQueryClient();

  const token = session?.access_token ?? "";

  // ─── Data Queries ─────────────────────────────────────────────────────────
  const { data: transactions, isLoading } = useQuery<Transaction[]>({
    queryKey: ["transactions", search, typeFilter],
    queryFn: () => {
      const params = new URLSearchParams();
      if (search) params.set("search", search);
      if (typeFilter !== "all") params.set("type", typeFilter);
      return apiFetch<Transaction[]>(`/api/transactions?${params}`, token);
    },
    enabled: !!token,
  });

  const { data: summary, isLoading: loadingSummary } = useQuery<Summary>({
    queryKey: ["transactions-summary"],
    queryFn: () => apiFetch<Summary>("/api/transactions/summary", token),
    enabled: !!token,
  });

  const { data: customers } = useQuery<Customer[]>({
    queryKey: ["customers"],
    queryFn: () => apiFetch<Customer[]>("/api/customers", token),
    enabled: !!token && (formType === "sale" || formType === "refund"),
  });

  const { data: inventory } = useQuery<InventoryItem[]>({
    queryKey: ["inventory"],
    queryFn: () => apiFetch<InventoryItem[]>("/api/inventory", token),
    enabled: !!token && (formType === "sale" || formType === "refund"),
  });

  const invalidateDashboard = () => {
    qc.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
    qc.invalidateQueries({ queryKey: getGetRecentActivityQueryKey() });
    qc.invalidateQueries({ queryKey: getGetRevenueChartQueryKey() });
  };

  const { mutateAsync: createTx, isPending: creating } = useMutation({
    mutationFn: (data: Partial<Transaction> & { items?: TxItem[] }) =>
      apiFetch<Transaction>("/api/transactions", token, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["transactions"] });
      qc.invalidateQueries({ queryKey: ["transactions-summary"] });
      invalidateDashboard();
    },
  });

  const { mutateAsync: deleteTx } = useMutation({
    mutationFn: (id: string) => apiFetch<void>(`/api/transactions/${id}`, token, { method: "DELETE" }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["transactions"] });
      qc.invalidateQueries({ queryKey: ["transactions-summary"] });
      invalidateDashboard();
    },
  });

  const { mutateAsync: parseTx, isPending: parsing } = useMutation({
    mutationFn: (text: string) => apiFetch<Partial<Transaction>>("/api/transactions/parse", token, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text }) }),
  });

  // ─── Form State ───────────────────────────────────────────────────────────
  const [form, setForm] = useState({
    amount: "",
    description: "",
    category: "other",
    date: new Date().toISOString().slice(0, 10),
    notes: "",
    paymentMethod: "cash",
    customerId: "",
    fromAccount: "",
    toAccount: "",
    reference: "",
    reason: "",
    originalTxRef: "",
  });

  const [saleItems, setSaleItems] = useState<Array<{ inventoryId: string; productName: string; quantity: number; unitPrice: number; stock: number }>>([]);
  const [selectedProduct, setSelectedProduct] = useState("");
  const [saleQty, setSaleQty] = useState("1");

  const resetForm = () => {
    setForm({
      amount: "", description: "", category: "other",
      date: new Date().toISOString().slice(0, 10), notes: "",
      paymentMethod: "cash", customerId: "", fromAccount: "",
      toAccount: "", reference: "", reason: "", originalTxRef: "",
    });
    setSaleItems([]);
    setSelectedProduct("");
    setSaleQty("1");
  };

  const addSaleItem = () => {
    const product = inventory?.find((p) => p.id === selectedProduct);
    if (!product) return;
    const qty = Number(saleQty);
    if (Number.isNaN(qty) || qty <= 0) {
      toast({ variant: "destructive", title: "Invalid quantity", description: "Enter a valid quantity greater than 0." });
      return;
    }
    if (qty > product.quantity) {
      toast({ variant: "destructive", title: "Insufficient stock", description: `Available stock: ${product.quantity}` });
      return;
    }
    setSaleItems((prev) => [...prev, {
      inventoryId: product.id,
      productName: product.name,
      quantity: qty,
      unitPrice: product.price,
      stock: product.quantity,
    }]);
    setSelectedProduct("");
    setSaleQty("1");
  };

  const removeSaleItem = (idx: number) => {
    setSaleItems((prev) => prev.filter((_, i) => i !== idx));
  };

  const saleTotal = saleItems.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0);

  // ─── Handlers ─────────────────────────────────────────────────────────────
  const handleNLPParse = async () => {
    if (!nlpText.trim()) return;
    try {
      const result = await parseTx(nlpText);
      setParsedTx(result);
    } catch {
      toast({ variant: "destructive", title: "Parse failed", description: "Couldn't understand that. Try being more specific." });
    }
  };

  const handleSaveParsed = async () => {
    if (!parsedTx) return;
    if (!parsedTx.type || parsedTx.amount === undefined || parsedTx.amount === null || !parsedTx.description || !parsedTx.date) {
      toast({ variant: "destructive", title: "Missing fields", description: "Parsed transaction is missing required fields." });
      return;
    }
    try {
      await createTx({ ...parsedTx, parsedFrom: nlpText });
      toast({ title: "Transaction saved!", description: `${parsedTx.type} of ${formatCurrency(parsedTx.amount || 0, "NGN")} recorded.` });
      setShowNLP(false);
      setNlpText("");
      setParsedTx(null);
    } catch (e: any) {
      toast({ variant: "destructive", title: "Error", description: e?.message || "Failed to save." });
    }
  };

  const handleManualSave = async () => {
    if (!form.date) {
      toast({ variant: "destructive", title: "Missing fields", description: "Date is required." });
      return;
    }

    let payload: Parameters<typeof createTx>[0] = {
      type: formType,
      description: form.description,
      category: form.category,
      date: form.date,
      notes: form.notes || undefined,
      paymentMethod: form.paymentMethod || undefined,
    };

    if (formType === "sale") {
      if (saleItems.length === 0) {
        toast({ variant: "destructive", title: "No items", description: "Add at least one product to the sale." });
        return;
      }
      if (!form.customerId) {
        toast({ variant: "destructive", title: "No customer", description: "Select a customer for this sale." });
        return;
      }
      const itemsTotal = saleItems.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0);
      // Auto-generate description from items if not provided
      const autoDesc = form.description || saleItems.map((i) => `${i.productName} ×${i.quantity}`).join(", ");
      payload = {
        ...payload,
        description: autoDesc,
        amount: itemsTotal,
        category: "sales",
        customerId: form.customerId,
        items: saleItems.map((item) => ({
          inventoryId: item.inventoryId,
          productName: item.productName,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
        })),
      };
    } else if (formType === "refund") {
      if (!form.amount) {
        toast({ variant: "destructive", title: "Missing amount", description: "Enter the refund amount." });
        return;
      }
      const refundAmount = Number(form.amount);
      if (Number.isNaN(refundAmount)) {
        toast({ variant: "destructive", title: "Invalid amount", description: "Please enter a valid refund amount." });
        return;
      }
      if (!form.description) {
        toast({ variant: "destructive", title: "Missing description", description: "Describe what is being refunded." });
        return;
      }
      const refundNotes = [
        form.originalTxRef ? `Original Tx Ref: ${form.originalTxRef}` : null,
        form.notes || null,
      ].filter(Boolean).join(" | ");
      payload = {
        ...payload,
        amount: refundAmount,
        category: "refund",
        notes: refundNotes || undefined,
        ...(form.customerId && { customerId: form.customerId }),
        ...(saleItems.length > 0 && {
          items: saleItems.map((item) => ({
            inventoryId: item.inventoryId,
            productName: item.productName,
            quantity: item.quantity,
            unitPrice: item.unitPrice,
          })),
        }),
      };
    } else if (formType === "transfer") {
      if (!form.amount) {
        toast({ variant: "destructive", title: "Missing amount", description: "Enter the transfer amount." });
        return;
      }
      const amount = Number(form.amount);
      if (Number.isNaN(amount)) {
        toast({ variant: "destructive", title: "Invalid amount", description: "Please enter a valid number." });
        return;
      }
      // Auto-build description from from/to accounts
      const autoDesc = form.description
        || (form.fromAccount && form.toAccount ? `${form.fromAccount} → ${form.toAccount}` : "Transfer");
      const transferNotes = [
        form.fromAccount ? `From: ${form.fromAccount}` : null,
        form.toAccount ? `To: ${form.toAccount}` : null,
        form.reference ? `Ref: ${form.reference}` : null,
        form.notes || null,
      ].filter(Boolean).join(" | ");
      payload = {
        ...payload,
        description: autoDesc,
        amount,
        category: "transfer",
        notes: transferNotes || undefined,
      };
    } else {
      // income, expense — require amount input
      if (!form.amount) {
        toast({ variant: "destructive", title: "Missing fields", description: "Amount is required." });
        return;
      }
      if (!form.description) {
        toast({ variant: "destructive", title: "Missing fields", description: "Description is required." });
        return;
      }
      const amount = Number(form.amount);
      if (Number.isNaN(amount)) {
        toast({ variant: "destructive", title: "Invalid amount", description: "Please enter a valid number." });
        return;
      }
      payload = {
        ...payload,
        amount,
        category: form.category,
      };
    }

    try {
      await createTx(payload);
      const finalAmount = formType === "sale"
        ? saleItems.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0)
        : formType === "refund"
        ? Number(form.amount)
        : Number(form.amount);
      toast({ title: "Transaction added!", description: `${formType} of ${formatCurrency(finalAmount, "NGN")} recorded.` });
      setShowAdd(false);
      resetForm();
    } catch (e: any) {
      toast({ variant: "destructive", title: "Error", description: e?.message || "Failed to save transaction." });
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteTx(id);
      toast({ title: "Deleted" });
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Failed to delete." });
    }
  };

  const currency = "NGN";

  // ─── Render ───────────────────────────────────────────────────────────────
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Transactions</h1>
          <p className="text-muted-foreground mt-1">Track income, expenses, sales, transfers, and refunds.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setShowNLP(true)} className="gap-2">
            <Sparkles className="h-4 w-4" /> AI Entry
          </Button>
          <Button onClick={() => { setShowAdd(true); resetForm(); }} className="gap-2">
            <Plus className="h-4 w-4" /> Add
          </Button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid gap-4 grid-cols-2 sm:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Revenue</CardTitle>
            <TrendingUp className="h-4 w-4 text-emerald-500" />
          </CardHeader>
          <CardContent>
            {loadingSummary ? <Skeleton className="h-8 w-28" /> : (
              <div className="text-xl font-bold text-emerald-600 stat-num">{formatCurrencyCompact(summary?.netRevenue || 0, currency)}</div>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Expenses</CardTitle>
            <TrendingDown className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            {loadingSummary ? <Skeleton className="h-8 w-28" /> : (
              <div className="text-xl font-bold text-destructive stat-num">{formatCurrencyCompact(summary?.totalExpenses || 0, currency)}</div>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Refunds</CardTitle>
            <RotateCcw className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            {loadingSummary ? <Skeleton className="h-8 w-28" /> : (
              <div className="text-xl font-bold text-blue-600 stat-num">{formatCurrencyCompact(summary?.totalRefunds || 0, currency)}</div>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Net Profit</CardTitle>
            <DollarSign className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            {loadingSummary ? <Skeleton className="h-8 w-28" /> : (
              <div className={cn("text-xl font-bold stat-num", (summary?.profit || 0) >= 0 ? "text-emerald-600" : "text-destructive")}>
                {formatCurrencyCompact(summary?.profit || 0, currency)}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Transactions Table */}
      <Card>
        <div className="p-4 border-b flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search transactions..." className="pl-8" value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-[140px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="income">Income</SelectItem>
              <SelectItem value="expense">Expense</SelectItem>
              <SelectItem value="sale">Sale</SelectItem>
              <SelectItem value="transfer">Transfer</SelectItem>
              <SelectItem value="refund">Refund</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="table-responsive">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Description</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Type</TableHead>
                <TableHead className="text-right">Amount</TableHead>
                <TableHead />
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array(5).fill(0).map((_, i) => (
                  <TableRow key={i}>
                    {Array(6).fill(0).map((_, j) => <TableCell key={j}><Skeleton className="h-5 w-full" /></TableCell>)}
                  </TableRow>
                ))
              ) : (transactions || []).length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-12 text-muted-foreground">
                    <div className="space-y-2">
                      <p>No transactions yet.</p>
                      <Button variant="outline" size="sm" onClick={() => setShowNLP(true)} className="gap-1">
                        <Sparkles className="h-3 w-3" /> Try AI Entry
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                (transactions || []).map((tx) => (
                  <TableRow key={tx.id}>
                    <TableCell>
                      <div className="space-y-0.5">
                        <p className="font-medium">{tx.description}</p>
                        {tx.items && tx.items.length > 0 && (
                          <p className="text-xs text-muted-foreground">
                            {tx.items.length} item(s) · {tx.items.map((i) => `${i.productName} (×${i.quantity})`).join(", ")}
                          </p>
                        )}
                        {tx.parsedFrom && <p className="text-xs text-muted-foreground truncate max-w-[200px]">&quot;{tx.parsedFrom}&quot;</p>}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="capitalize text-xs">{tx.category}</Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">{new Date(tx.date).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <Badge className={
                        tx.type === "income" || tx.type === "sale"
                          ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900 dark:text-emerald-300"
                          : tx.type === "refund"
                          ? "bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300"
                          : tx.type === "transfer"
                          ? "bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300"
                          : "bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300"
                      } variant="secondary">
                        {tx.type === "income" ? "💰 Income" : tx.type === "expense" ? "💸 Expense" : tx.type === "sale" ? "🛒 Sale" : tx.type === "transfer" ? "↔ Transfer" : "↩ Refund"}
                      </Badge>
                    </TableCell>
                    <TableCell className={cn("text-right font-semibold",
                      tx.type === "income" || tx.type === "sale" ? "text-emerald-600" :
                      tx.type === "refund" ? "text-blue-600" :
                      tx.type === "transfer" ? "text-purple-600" : "text-destructive"
                    )}>
                      {tx.type === "expense" ? "-" : tx.type === "refund" ? "↩" : "+"}{formatCurrency(tx.amount, currency)}
                    </TableCell>
                    <TableCell>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive" onClick={() => handleDelete(tx.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </Card>

      {/* ─── AI Entry Dialog ────────────────────────────────────────────── */}
      <Dialog open={showNLP} onOpenChange={(o) => { setShowNLP(o); if (!o) { setNlpText(""); setParsedTx(null); } }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><Sparkles className="h-5 w-5 text-primary" /> AI Transaction Entry</DialogTitle>
            <DialogDescription>Describe the transaction in plain English — AI will extract the details.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Describe your transaction</Label>
              <Textarea value={nlpText} onChange={(e) => { setNlpText(e.target.value); setParsedTx(null); }} placeholder='e.g. "Bought 10 bags of rice for 50,000 naira" or "Received 200k from Emeka for web design"' className="min-h-[80px]" />
              <div className="flex flex-wrap gap-1">
                {["Bought stock for 30k", "Paid rent 80,000", "Received 150k from client", "Electricity bill 12,500"].map((ex) => (
                  <button key={ex} onClick={() => setNlpText(ex)} className="text-xs px-2 py-1 rounded bg-muted hover:bg-muted/80 transition-colors text-muted-foreground">{ex}</button>
                ))}
              </div>
            </div>
            {!parsedTx && (
              <Button onClick={handleNLPParse} disabled={!nlpText.trim() || parsing} className="w-full gap-2">
                {parsing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                Parse with AI
              </Button>
            )}
            {parsedTx && (
              <div className="rounded-xl border bg-muted/50 p-4 space-y-3">
                <p className="text-sm font-medium text-muted-foreground">AI extracted:</p>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div><span className="text-muted-foreground">Type:</span> <Badge className={parsedTx.type === "income" ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"} variant="secondary">{parsedTx.type}</Badge></div>
                  <div><span className="text-muted-foreground">Amount:</span> <span className="font-bold">{formatCurrency(parsedTx.amount || 0, currency)}</span></div>
                  <div className="col-span-2"><span className="text-muted-foreground">Description:</span> <span className="font-medium">{parsedTx.description}</span></div>
                  <div><span className="text-muted-foreground">Category:</span> <span className="capitalize">{parsedTx.category}</span></div>
                  <div><span className="text-muted-foreground">Date:</span> <span>{parsedTx.date}</span></div>
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setShowNLP(false); setNlpText(""); setParsedTx(null); }}>Cancel</Button>
            {parsedTx && <Button onClick={handleSaveParsed} disabled={creating} className="gap-2">{creating ? <Loader2 className="h-4 w-4 animate-spin" /> : null}Save Transaction</Button>}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ─── Add Transaction Dialog ─────────────────────────────────────────── */}
      <Dialog open={showAdd} onOpenChange={(o) => { setShowAdd(o); if (!o) resetForm(); }}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Add Transaction</DialogTitle>
            <DialogDescription>Record a business transaction with the correct type.</DialogDescription>
          </DialogHeader>

          {/* Type Selector */}
          <div className="grid grid-cols-5 gap-2">
            {(["income", "expense", "sale", "transfer", "refund"] as const).map((t) => (
              <button key={t} onClick={() => { setFormType(t); resetForm(); }}
                className={cn("py-2 rounded-lg border text-xs font-medium capitalize transition-all flex flex-col items-center gap-1",
                  formType === t
                    ? (t === "income" || t === "sale"
                        ? "border-emerald-500 bg-emerald-50 text-emerald-700 dark:bg-emerald-950"
                        : t === "refund"
                        ? "border-blue-500 bg-blue-50 text-blue-700 dark:bg-blue-950"
                        : t === "transfer"
                        ? "border-purple-500 bg-purple-50 text-purple-700 dark:bg-purple-950"
                        : "border-red-500 bg-red-50 text-red-700 dark:bg-red-950")
                    : "hover:bg-muted"
                )}>
                {t === "income" ? <TrendingUp className="h-4 w-4" /> : t === "expense" ? <TrendingDown className="h-4 w-4" /> : t === "sale" ? <Package className="h-4 w-4" /> : t === "transfer" ? <Repeat className="h-4 w-4" /> : <RotateCcw className="h-4 w-4" />}
                {t}
              </button>
            ))}
          </div>

          <div className="space-y-4">
            {/* ─── COMMON FIELDS ───────────────────────────────────────────── */}
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-2">
                <Label>Date</Label>
                <Input type="date" value={form.date} onChange={(e) => setForm((f) => ({ ...f, date: e.target.value }))} />
              </div>
              <div className="grid gap-2">
                <Label>Payment Method</Label>
                <Select value={form.paymentMethod} onValueChange={(v) => setForm((f) => ({ ...f, paymentMethod: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{PAYMENT_METHODS.map((m) => <SelectItem key={m} value={m} className="capitalize">{m.replace("_", " ")}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>

            {/* ─── INCOME / EXPENSE / TRANSFER ──────────────────────────────── */}
            {formType !== "sale" && formType !== "refund" && (
              <>
                <div className="grid gap-2">
                  <Label>Amount (NGN)</Label>
                  <Input type="number" min="0" placeholder="0.00" value={form.amount} onChange={(e) => setForm((f) => ({ ...f, amount: e.target.value }))} />
                </div>
                <div className="grid gap-2">
                  <Label>Description</Label>
                  <Input placeholder={formType === "income" ? "e.g. Consulting fee from ABC Corp" : formType === "expense" ? "e.g. Office rent payment" : "e.g. Cash to Bank transfer"} value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} />
                </div>
                <div className="grid gap-2">
                  <Label>Category</Label>
                  <Select value={form.category} onValueChange={(v) => setForm((f) => ({ ...f, category: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{CATEGORIES[formType].map((c) => <SelectItem key={c} value={c} className="capitalize">{c}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                {formType === "transfer" && (
                  <div className="grid gap-2">
                    <Label>Reference</Label>
                    <Input placeholder="TXN-12345" value={form.reference} onChange={(e) => setForm((f) => ({ ...f, reference: e.target.value }))} />
                  </div>
                )}
              </>
            )}

            {/* ─── REFUND ───────────────────────────────────────────────────── */}
            {formType === "refund" && (
              <>
                <div className="grid grid-cols-2 gap-3">
                  <div className="grid gap-2">
                    <Label>Amount (NGN) *</Label>
                    <Input type="number" min="0" placeholder="0.00" value={form.amount} onChange={(e) => setForm((f) => ({ ...f, amount: e.target.value }))} />
                  </div>
                  <div className="grid gap-2">
                    <Label>Customer</Label>
                    <Select value={form.customerId} onValueChange={(v) => setForm((f) => ({ ...f, customerId: v }))}>
                      <SelectTrigger><SelectValue placeholder="Select customer" /></SelectTrigger>
                      <SelectContent>{customers?.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid gap-2">
                  <Label>Reason / Description *</Label>
                  <Input placeholder="e.g. Customer returned damaged goods" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} />
                </div>
                <div className="grid gap-2">
                  <Label>Original Transaction Reference <span className="text-muted-foreground text-xs">(optional)</span></Label>
                  <Input placeholder="e.g. INV-001 or TXN-123456" value={form.originalTxRef} onChange={(e) => setForm((f) => ({ ...f, originalTxRef: e.target.value }))} />
                </div>
                <div className="grid gap-2">
                  <Label>Returned Products <span className="text-muted-foreground text-xs">(optional — restocks inventory)</span></Label>
                  <div className="flex gap-2">
                    <Select value={selectedProduct} onValueChange={setSelectedProduct}>
                      <SelectTrigger className="flex-1"><SelectValue placeholder="Select product" /></SelectTrigger>
                      <SelectContent>
                        {inventory?.map((p) => (
                          <SelectItem key={p.id} value={p.id}>
                            {p.name} — {formatCurrency(p.price, currency)} each
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Input type="number" min="1" className="w-20" value={saleQty} onChange={(e) => setSaleQty(e.target.value)} />
                    <Button type="button" variant="outline" onClick={addSaleItem} disabled={!selectedProduct}>
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                {saleItems.length > 0 && (
                  <div className="rounded-lg border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="text-xs">Product</TableHead>
                          <TableHead className="text-xs text-right">Qty</TableHead>
                          <TableHead className="text-xs text-right">Price</TableHead>
                          <TableHead className="text-xs text-right">Subtotal</TableHead>
                          <TableHead className="w-8" />
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {saleItems.map((item, idx) => (
                          <TableRow key={idx}>
                            <TableCell className="text-sm font-medium">{item.productName}</TableCell>
                            <TableCell className="text-sm text-right">{item.quantity}</TableCell>
                            <TableCell className="text-sm text-right">{formatCurrency(item.unitPrice, currency)}</TableCell>
                            <TableCell className="text-sm text-right font-semibold">{formatCurrency(item.quantity * item.unitPrice, currency)}</TableCell>
                            <TableCell>
                              <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => removeSaleItem(idx)}>
                                <X className="h-3 w-3" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </>
            )}

            {/* ─── SALE FORM ───────────────────────────────────────────────── */}
            {formType === "sale" && (
              <div className="space-y-4">
                <div className="grid gap-2">
                  <Label>Customer *</Label>
                  <Select value={form.customerId} onValueChange={(v) => setForm((f) => ({ ...f, customerId: v }))}>
                    <SelectTrigger><SelectValue placeholder="Select customer" /></SelectTrigger>
                    <SelectContent>{customers?.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
                  </Select>
                </div>

                <div className="grid gap-2">
                  <Label>Add Products</Label>
                  <div className="flex gap-2">
                    <Select value={selectedProduct} onValueChange={setSelectedProduct}>
                      <SelectTrigger className="flex-1"><SelectValue placeholder="Select product" /></SelectTrigger>
                      <SelectContent>
                        {inventory?.map((p) => (
                          <SelectItem key={p.id} value={p.id}>
                            {p.name} — {p.quantity} in stock — {formatCurrency(p.price, currency)} each
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Input type="number" min="1" className="w-20" value={saleQty} onChange={(e) => setSaleQty(e.target.value)} />
                    <Button type="button" variant="outline" onClick={addSaleItem} disabled={!selectedProduct}>
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                {saleItems.length > 0 && (
                  <div className="rounded-lg border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="text-xs">Product</TableHead>
                          <TableHead className="text-xs text-right">Qty</TableHead>
                          <TableHead className="text-xs text-right">Price</TableHead>
                          <TableHead className="text-xs text-right">Subtotal</TableHead>
                          <TableHead className="w-8" />
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {saleItems.map((item, idx) => (
                          <TableRow key={idx}>
                            <TableCell className="text-sm font-medium">{item.productName}</TableCell>
                            <TableCell className="text-sm text-right">{item.quantity}</TableCell>
                            <TableCell className="text-sm text-right">{formatCurrency(item.unitPrice, currency)}</TableCell>
                            <TableCell className="text-sm text-right font-semibold">{formatCurrency(item.quantity * item.unitPrice, currency)}</TableCell>
                            <TableCell>
                              <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => removeSaleItem(idx)}>
                                <X className="h-3 w-3" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                        <TableRow>
                          <TableCell colSpan={3} className="text-right font-bold text-sm">Total</TableCell>
                          <TableCell className="text-right font-bold text-emerald-600">{formatCurrency(saleTotal, currency)}</TableCell>
                          <TableCell />
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                )}

                <div className="grid gap-2">
                  <Label>Description <span className="text-muted-foreground text-xs">(optional — auto-filled from items)</span></Label>
                  <Input placeholder="e.g. Walk-in customer sale" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} />
                </div>
              </div>
            )}

            {/* ─── TRANSFER FIELDS ──────────────────────────────────────────── */}
            {formType === "transfer" && (
              <div className="grid grid-cols-2 gap-3">
                <div className="grid gap-2">
                  <Label>From Account</Label>
                  <Input placeholder="e.g. Cash" value={form.fromAccount} onChange={(e) => setForm((f) => ({ ...f, fromAccount: e.target.value }))} />
                </div>
                <div className="grid gap-2">
                  <Label>To Account</Label>
                  <Input placeholder="e.g. Bank" value={form.toAccount} onChange={(e) => setForm((f) => ({ ...f, toAccount: e.target.value }))} />
                </div>
              </div>
            )}

            {/* ─── NOTES ────────────────────────────────────────────────────── */}
            <div className="grid gap-2">
              <Label>Notes (optional)</Label>
              <Textarea placeholder="Any extra details..." value={form.notes} onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))} className="min-h-[60px]" />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => { setShowAdd(false); resetForm(); }}>Cancel</Button>
            <Button onClick={handleManualSave} disabled={creating} className="gap-2">
              {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
              Save {formType}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
