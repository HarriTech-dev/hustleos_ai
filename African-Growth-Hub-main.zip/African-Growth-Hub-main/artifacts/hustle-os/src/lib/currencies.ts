export const CURRENCIES = [
  // West African CFA
  "XOF",
  // Central African CFA
  "XAF",
  // Nigeria
  "NGN",
  // Ghana
  "GHS",
  // Kenya
  "KES",
  // South Africa
  "ZAR",
  // Uganda
  "UGX",
  // Tanzania
  "TZS",
  // Ethiopia
  "ETB",
  // Rwanda
  "RWF",
  // Zambia
  "ZMW",
  // Malawi
  "MWK",
  // Botswana
  "BWP",
  // Mozambique
  "MZN",
  // Morocco
  "MAD",
  // Egypt
  "EGP",
  // Algeria
  "DZD",
  // Angola
  "AOA",
  // Benin
  "XOF",
  // Burkina Faso
  "XOF",
  // Burundi
  "BIF",
  // Cameroon
  "XAF",
  // Cape Verde
  "CVE",
  // Central African Republic
  "XAF",
  // Chad
  "XAF",
  // Comoros
  "KMF",
  // Congo (Brazzaville)
  "XAF",
  // Congo (DRC)
  "CDF",
  // Djibouti
  "DJF",
  // Equatorial Guinea
  "XAF",
  // Eritrea
  "ERN",
  // Eswatini
  "SZL",
  // Gabon
  "XAF",
  // Gambia
  "GMD",
  // Guinea
  "GNF",
  // Guinea-Bissau
  "XOF",
  // Ivory Coast
  "XOF",
  // Lesotho
  "LSL",
  // Liberia
  "LRD",
  // Libya
  "LYD",
  // Madagascar
  "MGA",
  // Mali
  "XOF",
  // Mauritania
  "MRU",
  // Mauritius
  "MUR",
  // Namibia
  "NAD",
  // Niger
  "XOF",
  // Sao Tome & Principe
  "STN",
  // Senegal
  "XOF",
  // Seychelles
  "SCR",
  // Sierra Leone
  "SLE",
  // Somalia
  "SOS",
  // South Sudan
  "SSP",
  // Sudan
  "SDG",
  // Togo
  "XOF",
  // Tunisia
  "TND",
  // Zimbabwe
  "ZWL",
  // Global
  "USD",
  "GBP",
  "EUR",
  "AED",
  "INR",
];

export const CURRENCY_LABELS: Record<string, string> = {
  NGN: "NGN — Nigerian Naira",
  GHS: "GHS — Ghanaian Cedi",
  KES: "KES — Kenyan Shilling",
  ZAR: "ZAR — South African Rand",
  UGX: "UGX — Ugandan Shilling",
  TZS: "TZS — Tanzanian Shilling",
  XAF: "XAF — Central African CFA",
  XOF: "XOF — West African CFA",
  ETB: "ETB — Ethiopian Birr",
  RWF: "RWF — Rwandan Franc",
  ZMW: "ZMW — Zambian Kwacha",
  MWK: "MWK — Malawian Kwacha",
  BWP: "BWP — Botswana Pula",
  MZN: "MZN — Mozambican Metical",
  MAD: "MAD — Moroccan Dirham",
  EGP: "EGP — Egyptian Pound",
  DZD: "DZD — Algerian Dinar",
  AOA: "AOA — Angolan Kwanza",
  BIF: "BIF — Burundian Franc",
  CVE: "CVE — Cape Verdean Escudo",
  CDF: "CDF — Congolese Franc",
  DJF: "DJF — Djiboutian Franc",
  ERN: "ERN — Eritrean Nakfa",
  SZL: "SZL — Eswatini Lilangeni",
  GMD: "GMD — Gambian Dalasi",
  GNF: "GNF — Guinean Franc",
  LSL: "LSL — Lesotho Loti",
  LRD: "LRD — Liberian Dollar",
  LYD: "LYD — Libyan Dinar",
  MGA: "MGA — Malagasy Ariary",
  MRU: "MRU — Mauritanian Ouguiya",
  MUR: "MUR — Mauritian Rupee",
  NAD: "NAD — Namibian Dollar",
  STN: "STN — Sao Tome Dobra",
  SCR: "SCR — Seychellois Rupee",
  SLE: "SLE — Sierra Leonean Leone",
  SOS: "SOS — Somali Shilling",
  SSP: "SSP — South Sudanese Pound",
  SDG: "SDG — Sudanese Pound",
  TND: "TND — Tunisian Dinar",
  ZWL: "ZWL — Zimbabwean Dollar",
  USD: "USD — US Dollar",
  GBP: "GBP — British Pound",
  EUR: "EUR — Euro",
  AED: "AED — UAE Dirham",
  INR: "INR — Indian Rupee",
};

// Deduplicated list for select dropdowns
export const UNIQUE_CURRENCIES = Array.from(new Set(CURRENCIES));
