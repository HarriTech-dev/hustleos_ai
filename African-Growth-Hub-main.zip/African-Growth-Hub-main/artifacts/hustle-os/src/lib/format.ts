export function formatCurrency(amount: number, currencyCode: string = 'USD') {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currencyCode,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(amount);
}

/**
 * Compact currency formatter for KPI cards — never overflows a card.
 * ₦1,234 → ₦1,234  |  ₦12,345 → ₦12.3K  |  ₦1,234,567 → ₦1.2M  |  ₦1,234,567,890 → ₦1.2B
 */
export function formatCurrencyCompact(amount: number, currencyCode: string = 'NGN'): string {
  const abs = Math.abs(amount);
  const sign = amount < 0 ? '-' : '';

  // Extract currency symbol from Intl
  let symbol = currencyCode;
  try {
    const parts = new Intl.NumberFormat('en', {
      style: 'currency',
      currency: currencyCode,
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).formatToParts(0);
    symbol = parts.find((p) => p.type === 'currency')?.value ?? currencyCode;
  } catch {
    // fallback: keep currencyCode
  }

  if (abs >= 1_000_000_000) return `${sign}${symbol}${(abs / 1_000_000_000).toFixed(1)}B`;
  if (abs >= 1_000_000)     return `${sign}${symbol}${(abs / 1_000_000).toFixed(1)}M`;
  if (abs >= 10_000)        return `${sign}${symbol}${(abs / 1_000).toFixed(1)}K`;
  return formatCurrency(amount, currencyCode);
}

/**
 * Compact count formatter for KPI cards.
 * 9,999 → 9,999  |  12,345 → 12.3K  |  1,234,567 → 1.2M
 */
export function formatCountCompact(value: number): string {
  const abs = Math.abs(value);
  const sign = value < 0 ? '-' : '';
  if (abs >= 1_000_000) return `${sign}${(abs / 1_000_000).toFixed(1)}M`;
  if (abs >= 10_000)    return `${sign}${(abs / 1_000).toFixed(1)}K`;
  return value.toLocaleString('en-US');
}

export function formatDate(dateString: string | undefined | null) {
  if (!dateString) return '';
  return new Date(dateString).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
}
