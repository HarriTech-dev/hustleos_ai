export interface CountryInfo {
  name: string;
  currency: string;
}

export const AFRICAN_COUNTRIES: CountryInfo[] = [
  { name: "Algeria", currency: "DZD" },
  { name: "Angola", currency: "AOA" },
  { name: "Benin", currency: "XOF" },
  { name: "Botswana", currency: "BWP" },
  { name: "Burkina Faso", currency: "XOF" },
  { name: "Burundi", currency: "BIF" },
  { name: "Cameroon", currency: "XAF" },
  { name: "Cape Verde", currency: "CVE" },
  { name: "Central African Republic", currency: "XAF" },
  { name: "Chad", currency: "XAF" },
  { name: "Comoros", currency: "KMF" },
  { name: "Congo (Brazzaville)", currency: "XAF" },
  { name: "Congo (DRC)", currency: "CDF" },
  { name: "Djibouti", currency: "DJF" },
  { name: "Egypt", currency: "EGP" },
  { name: "Equatorial Guinea", currency: "XAF" },
  { name: "Eritrea", currency: "ERN" },
  { name: "Eswatini", currency: "SZL" },
  { name: "Ethiopia", currency: "ETB" },
  { name: "Gabon", currency: "XAF" },
  { name: "Gambia", currency: "GMD" },
  { name: "Ghana", currency: "GHS" },
  { name: "Guinea", currency: "GNF" },
  { name: "Guinea-Bissau", currency: "XOF" },
  { name: "Ivory Coast", currency: "XOF" },
  { name: "Kenya", currency: "KES" },
  { name: "Lesotho", currency: "LSL" },
  { name: "Liberia", currency: "LRD" },
  { name: "Libya", currency: "LYD" },
  { name: "Madagascar", currency: "MGA" },
  { name: "Malawi", currency: "MWK" },
  { name: "Mali", currency: "XOF" },
  { name: "Mauritania", currency: "MRU" },
  { name: "Mauritius", currency: "MUR" },
  { name: "Morocco", currency: "MAD" },
  { name: "Mozambique", currency: "MZN" },
  { name: "Namibia", currency: "NAD" },
  { name: "Niger", currency: "XOF" },
  { name: "Nigeria", currency: "NGN" },
  { name: "Rwanda", currency: "RWF" },
  { name: "Sao Tome & Principe", currency: "STN" },
  { name: "Senegal", currency: "XOF" },
  { name: "Seychelles", currency: "SCR" },
  { name: "Sierra Leone", currency: "SLE" },
  { name: "Somalia", currency: "SOS" },
  { name: "South Africa", currency: "ZAR" },
  { name: "South Sudan", currency: "SSP" },
  { name: "Sudan", currency: "SDG" },
  { name: "Tanzania", currency: "TZS" },
  { name: "Togo", currency: "XOF" },
  { name: "Tunisia", currency: "TND" },
  { name: "Uganda", currency: "UGX" },
  { name: "Zambia", currency: "ZMW" },
  { name: "Zimbabwe", currency: "ZWL" },
];

export const COUNTRY_NAMES = AFRICAN_COUNTRIES.map(c => c.name);

export const COUNTRY_CURRENCY_MAP: Record<string, string> = Object.fromEntries(
  AFRICAN_COUNTRIES.map(c => [c.name, c.currency])
);

export function getCurrencyForCountry(country: string): string | undefined {
  return COUNTRY_CURRENCY_MAP[country];
}
