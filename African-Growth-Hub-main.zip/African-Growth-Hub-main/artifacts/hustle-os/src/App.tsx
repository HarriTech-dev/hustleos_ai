import { lazy, Suspense } from "react";
import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "./components/theme-provider";
import { AuthProvider } from "./contexts/AuthContext";
import { ProtectedRoute } from "./components/auth/protected-route";
import { ErrorBoundary } from "./components/error-boundary";
import NotFound from "@/pages/not-found";

import Login from "./pages/auth/login";
import Register from "./pages/auth/register";
import ForgotPassword from "./pages/auth/forgot-password";
import JoinPage from "./pages/join";

const Dashboard = lazy(() => import("./pages/dashboard/index"));
const InventoryList = lazy(() => import("./pages/inventory/index"));
const NewInventoryItem = lazy(() => import("./pages/inventory/new"));
const InventoryDetail = lazy(() => import("./pages/inventory/detail"));
const InvoiceList = lazy(() => import("./pages/invoices/index"));
const NewInvoice = lazy(() => import("./pages/invoices/new"));
const InvoiceDetail = lazy(() => import("./pages/invoices/detail"));
const QuotesList = lazy(() => import("./pages/quotes/index"));
const NewQuote = lazy(() => import("./pages/quotes/new"));
const QuoteDetail = lazy(() => import("./pages/quotes/detail"));
const PurchaseOrdersList = lazy(() => import("./pages/purchase-orders/index"));
const NewPurchaseOrder = lazy(() => import("./pages/purchase-orders/new"));
const PurchaseOrderDetail = lazy(() => import("./pages/purchase-orders/detail"));
const CustomerList = lazy(() => import("./pages/customers/index"));
const NewCustomer = lazy(() => import("./pages/customers/new"));
const CustomerDetail = lazy(() => import("./pages/customers/detail"));
const AIAdvisor = lazy(() => import("./pages/ai/index"));
const AIMarketingGenerator = lazy(() => import("./pages/ai/marketing"));
const Team = lazy(() => import("./pages/team/index"));
const Billing = lazy(() => import("./pages/billing/index"));
const Settings = lazy(() => import("./pages/settings/index"));
const Transactions = lazy(() => import("./pages/transactions/index"));
const Debtors = lazy(() => import("./pages/debtors/index"));
const Reports = lazy(() => import("./pages/reports/index"));
const Forecasting = lazy(() => import("./pages/forecasting/index"));
const Marketplace = lazy(() => import("./pages/marketplace/index"));
const Notifications = lazy(() => import("./pages/notifications/index"));
const AuditLogs = lazy(() => import("./pages/audit-logs/index"));
const CRMPage = lazy(() => import("./pages/crm/index"));
const TrainingVideos = lazy(() => import("./pages/training-videos/index"));
const NewTrainingVideo = lazy(() => import("./pages/training-videos/new"));

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 60_000,
      gcTime: 5 * 60_000,
      refetchOnWindowFocus: false,
    },
  },
});

function PageLoader() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="flex flex-col items-center gap-3">
        <div className="w-10 h-10 rounded-full border-4 border-primary border-t-transparent animate-spin" />
        <p className="text-sm text-muted-foreground">Loading…</p>
      </div>
    </div>
  );
}

function Router() {
  return (
    <Suspense fallback={<PageLoader />}>
      <Switch>
        <Route path="/auth/login" component={Login} />
        <Route path="/auth/register" component={Register} />
        <Route path="/auth/forgot-password" component={ForgotPassword} />
        <Route path="/join/:token" component={JoinPage} />

        <ProtectedRoute path="/" component={Dashboard} />

        <ProtectedRoute path="/inventory" component={InventoryList} />
        <ProtectedRoute path="/inventory/new" component={NewInventoryItem} />
        <ProtectedRoute path="/inventory/:id" component={InventoryDetail} />

        <ProtectedRoute path="/invoices" component={InvoiceList} />
        <ProtectedRoute path="/invoices/new" component={NewInvoice} />
        <ProtectedRoute path="/invoices/:id" component={InvoiceDetail} />

        <ProtectedRoute path="/quotes" component={QuotesList} />
        <ProtectedRoute path="/quotes/new" component={NewQuote} />
        <ProtectedRoute path="/quotes/:id" component={QuoteDetail} />

        <ProtectedRoute path="/purchase-orders" component={PurchaseOrdersList} />
        <ProtectedRoute path="/purchase-orders/new" component={NewPurchaseOrder} />
        <ProtectedRoute path="/purchase-orders/:id" component={PurchaseOrderDetail} />

        <ProtectedRoute path="/customers" component={CustomerList} />
        <ProtectedRoute path="/customers/new" component={NewCustomer} />
        <ProtectedRoute path="/customers/:id" component={CustomerDetail} />

        <ProtectedRoute path="/transactions" component={Transactions} />
        <ProtectedRoute path="/debtors" component={Debtors} />
        <ProtectedRoute path="/reports" component={Reports} />
        <ProtectedRoute path="/forecasting" component={Forecasting} />
        <ProtectedRoute path="/marketplace" component={Marketplace} />
        <ProtectedRoute path="/notifications" component={Notifications} />
        <ProtectedRoute path="/audit-logs" component={AuditLogs} allowedRoles={["owner", "admin"]} />
        <ProtectedRoute path="/ai" component={AIAdvisor} />
        <ProtectedRoute path="/ai/marketing" component={AIMarketingGenerator} />
        <ProtectedRoute path="/team" component={Team} allowedRoles={["owner", "admin"]} />
        <ProtectedRoute path="/billing" component={Billing} allowedRoles={["owner", "admin"]} />
        <ProtectedRoute path="/settings" component={Settings} />
        <ProtectedRoute path="/crm" component={CRMPage} />
        <ProtectedRoute path="/training-videos" component={TrainingVideos} />
        <ProtectedRoute path="/training-videos/new" component={NewTrainingVideo} />

        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <ThemeProvider defaultTheme="system" storageKey="hustleos-theme">
          <AuthProvider>
            <TooltipProvider>
              <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
                <Router />
              </WouterRouter>
              <Toaster />
            </TooltipProvider>
          </AuthProvider>
        </ThemeProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}

export default App;
