---
name: HustleOS Feature Status
description: Which modules are built, API routes, DB tables, and gotchas per feature.
---

## Fully Built
- Auth (Supabase JWT, login/register)
- Dashboard (revenue, invoices, inventory overview)
- Invoices (list, create, detail, send, mark-paid, delete) — `pages/invoices/detail.tsx`
- Inventory (list, create, detail with stock history, adjust stock) — `pages/inventory/detail.tsx`
- Customers (list, create, detail with invoice history, WhatsApp link) — `pages/customers/detail.tsx`
- Transactions (CRUD + NLP parse via GPT-4o-mini)
- Debtors (outstanding balance view)
- AI Advisor (GPT-4o-mini chat with business context)
- Team management (invite, remove, roles)
- Billing (Paystack + Flutterwave subscription plans)
- Settings (profile, business, dark mode toggle)
- Reports (monthly PDF export + CSV export)
- Forecasting (6-month historical + 3-month AI forecast with Recharts) — `/forecasting`
- Marketplace (listings, create, browse, WhatsApp contact, view counter) — `/marketplace`
- Notifications (in-app notification center + bell in header with unread badge) — `/notifications`
- Audit Logs (action tracking page with filters) — `/audit-logs`
- Dark mode (ThemeProvider + sidebar toggle, system/light/dark)
- PWA manifest (`public/manifest.json` + index.html meta tags)

## DB Tables
users, inventory, stock_adjustments, customers, invoices, ai_conversations, team_members, subscriptions, transactions, notifications, audit_logs, marketplace_listings

## Key API Routes Added (this session)
- GET/POST/DELETE `/notifications` + POST `/notifications/read-all` + POST `/notifications/:id/read`
- GET `/audit-logs`
- GET `/forecasting/revenue`
- GET/POST/PATCH/DELETE `/marketplace` + `/marketplace/my-listings` + `/marketplace/:id/view`
- GET `/inventory/:id/adjustments` (was missing, added)

## Gotchas
- `writeAuditLog()` and `createNotification()` are exported from their route files for use in other routes — call them after mutations to populate the DB
- Notifications are tenant-scoped (not user-scoped); unread badge polls every 60s
- Forecasting growth rate is clamped between -30% and +50% to avoid extreme outliers
- CSV export (not xlsx) is used for spreadsheet export — no extra dependency needed
- Marketplace GET is public (no auth required); My Listings requires auth
- Stock adjustments GET endpoint was added in this session alongside the existing POST /adjust

**Why audit logs are mostly empty:** `writeAuditLog()` is defined but not yet wired into individual route handlers. Future work: call it on invoice create/send/paid, customer create/delete, etc.
