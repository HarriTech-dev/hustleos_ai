import { pgTable, text, numeric, boolean, timestamp, integer, pgEnum, index, jsonb } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const listingStatusEnum = pgEnum("listing_status", ["active", "inactive", "sold"]);
export const listingCategoryEnum = pgEnum("listing_category", [
  "goods", "services", "digital", "food", "fashion", "electronics", "agriculture", "beauty", "other"
]);

export const marketplaceListingsTable = pgTable("marketplace_listings", {
  id: text("id").primaryKey(),
  tenantId: text("tenant_id").notNull(),
  userId: text("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  price: numeric("price", { precision: 12, scale: 2 }).notNull(),
  currency: text("currency").notNull().default("NGN"),
  category: listingCategoryEnum("category").notNull().default("other"),
  imageUrl: text("image_url"),
  imageUrls: jsonb("image_urls").default([]),
  whatsappNumber: text("whatsapp_number"),
  location: text("location"),
  status: listingStatusEnum("status").notNull().default("active"),
  views: integer("views").notNull().default(0),
  featured: boolean("featured").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("idx_marketplace_tenant_id").on(table.tenantId),
  index("idx_marketplace_status").on(table.status),
  index("idx_marketplace_category").on(table.category),
]);

export type MarketplaceListing = typeof marketplaceListingsTable.$inferSelect;

export const insertListingSchema = z.object({
  title: z.string().min(3),
  description: z.string().min(10),
  price: z.number().positive(),
  currency: z.string().optional(),
  category: z.enum(["goods", "services", "digital", "food", "fashion", "electronics", "agriculture", "beauty", "other"]).optional(),
  imageUrl: z.string().optional(),
  imageUrls: z.array(z.string()).optional(),
  whatsappNumber: z.string().optional(),
  location: z.string().optional(),
});
export type InsertListing = z.infer<typeof insertListingSchema>;
