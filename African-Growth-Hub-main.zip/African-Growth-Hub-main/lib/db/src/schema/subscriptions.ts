import { pgTable, text, numeric, timestamp, boolean, pgEnum, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const subscriptionStatusEnum = pgEnum("subscription_status", ["active", "trialing", "past_due", "cancelled"]);
export const subscriptionIntervalEnum = pgEnum("subscription_interval", ["monthly", "yearly"]);

export const subscriptionPlansTable = pgTable("subscription_plans", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  price: numeric("price", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").notNull().default("NGN"),
  interval: subscriptionIntervalEnum("interval").notNull().default("monthly"),
  features: text("features").array().notNull().default([]),
  isPopular: boolean("is_popular").notNull().default(false),
  isActive: boolean("is_active").notNull().default(true),
}, (table) => [
  index("idx_plans_is_active").on(table.isActive),
]);

export const subscriptionsTable = pgTable("subscriptions", {
  id: text("id").primaryKey(),
  tenantId: text("tenant_id").notNull(),
  planId: text("plan_id").notNull(),
  planName: text("plan_name").notNull(),
  status: subscriptionStatusEnum("status").notNull().default("trialing"),
  provider: text("provider"),
  providerReference: text("provider_reference"),
  currentPeriodStart: timestamp("current_period_start", { withTimezone: true }).notNull().defaultNow(),
  currentPeriodEnd: timestamp("current_period_end", { withTimezone: true }).notNull(),
  cancelAtPeriodEnd: boolean("cancel_at_period_end").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("idx_subscriptions_tenant_id").on(table.tenantId),
  index("idx_subscriptions_status").on(table.status),
]);

export const insertSubscriptionSchema = createInsertSchema(subscriptionsTable).omit({ createdAt: true });
export type InsertSubscription = z.infer<typeof insertSubscriptionSchema>;
export type Subscription = typeof subscriptionsTable.$inferSelect;
