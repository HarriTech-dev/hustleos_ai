import { pgTable, text, integer, numeric, timestamp, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const inventoryTable = pgTable("inventory", {
  id: text("id").primaryKey(),
  tenantId: text("tenant_id").notNull(),
  name: text("name").notNull(),
  sku: text("sku").notNull(),
  description: text("description"),
  quantity: integer("quantity").notNull().default(0),
  lowStockThreshold: integer("low_stock_threshold").notNull().default(5),
  price: numeric("price", { precision: 12, scale: 2 }).notNull(),
  costPrice: numeric("cost_price", { precision: 12, scale: 2 }).notNull(),
  category: text("category").notNull(),
  unit: text("unit").notNull().default("unit"),
  imageUrl: text("image_url"),
  currency: text("currency").notNull().default("NGN"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("idx_inventory_tenant_id").on(table.tenantId),
  index("idx_inventory_name").on(table.name),
  index("idx_inventory_sku").on(table.sku),
]);

export const insertInventorySchema = createInsertSchema(inventoryTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertInventory = z.infer<typeof insertInventorySchema>;
export type Inventory = typeof inventoryTable.$inferSelect;

export const stockAdjustmentReasonEnum = ["restock", "sale", "damage", "theft", "correction", "return"] as const;

export const stockAdjustmentsTable = pgTable("stock_adjustments", {
  id: text("id").primaryKey(),
  inventoryId: text("inventory_id").notNull(),
  tenantId: text("tenant_id").notNull(),
  adjustment: integer("adjustment").notNull(),
  reason: text("reason").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("idx_stock_adj_inventory_id").on(table.inventoryId),
  index("idx_stock_adj_tenant_id").on(table.tenantId),
]);
