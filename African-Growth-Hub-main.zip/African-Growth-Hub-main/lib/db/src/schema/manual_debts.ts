import { pgTable, text, numeric, timestamp, pgEnum, date, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const manualDebtStatusEnum = pgEnum("manual_debt_status", ["outstanding", "partial", "paid", "cancelled"]);

export const manualDebtsTable = pgTable("manual_debts", {
  id: text("id").primaryKey(),
  tenantId: text("tenant_id").notNull(),
  debtorName: text("debtor_name").notNull(),
  debtorPhone: text("debtor_phone"),
  debtorEmail: text("debtor_email"),
  customerId: text("customer_id"),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  amountPaid: numeric("amount_paid", { precision: 12, scale: 2 }).notNull().default("0"),
  reason: text("reason").notNull(),
  notes: text("notes"),
  status: manualDebtStatusEnum("status").notNull().default("outstanding"),
  dueDate: date("due_date", { mode: "string" }),
  currency: text("currency").notNull().default("NGN"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("idx_manual_debts_tenant_id").on(table.tenantId),
  index("idx_manual_debts_status").on(table.status),
]);

export const insertManualDebtSchema = createInsertSchema(manualDebtsTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertManualDebt = z.infer<typeof insertManualDebtSchema>;
export type ManualDebt = typeof manualDebtsTable.$inferSelect;
