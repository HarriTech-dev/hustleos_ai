import { pgTable, text, numeric, timestamp, pgEnum, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const paymentMethodEnum = pgEnum("payment_method", ["cash", "bank_transfer", "card", "mobile_money", "cheque", "other"]);

export const paymentsTable = pgTable("payments", {
  id: text("id").primaryKey(),
  tenantId: text("tenant_id").notNull(),
  invoiceId: text("invoice_id").notNull(),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  method: paymentMethodEnum("method").notNull().default("other"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("idx_payments_tenant_id").on(table.tenantId),
  index("idx_payments_invoice_id").on(table.invoiceId),
]);

export const insertPaymentSchema = createInsertSchema(paymentsTable).omit({
  createdAt: true,
});
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Payment = typeof paymentsTable.$inferSelect;
