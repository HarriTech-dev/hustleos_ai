import { pgTable, text, timestamp, pgEnum, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const teamMemberStatusEnum = pgEnum("team_member_status", ["active", "invited", "suspended"]);
export const teamRoleEnum = pgEnum("team_role", ["owner", "admin", "manager", "staff"]);

export const teamMembersTable = pgTable("team_members", {
  id: text("id").primaryKey(),
  tenantId: text("tenant_id").notNull(),
  userId: text("user_id"),
  name: text("name").notNull(),
  email: text("email").notNull(),
  role: teamRoleEnum("role").notNull().default("staff"),
  status: teamMemberStatusEnum("status").notNull().default("invited"),
  avatarUrl: text("avatar_url"),
  inviteToken: text("invite_token").unique(),
  inviteExpiresAt: timestamp("invite_expires_at", { withTimezone: true }),
  joinedAt: timestamp("joined_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("idx_team_members_tenant_id").on(table.tenantId),
  index("idx_team_members_email").on(table.email),
  index("idx_team_members_invite_token").on(table.inviteToken),
]);

export const insertTeamMemberSchema = createInsertSchema(teamMembersTable).omit({ joinedAt: true });
export type InsertTeamMember = z.infer<typeof insertTeamMemberSchema>;
export type TeamMember = typeof teamMembersTable.$inferSelect;
