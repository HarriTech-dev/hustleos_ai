import { pgTable, text, boolean, timestamp, pgEnum, index } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const notificationTypeEnum = pgEnum("notification_type", [
  "invoice_paid",
  "invoice_overdue",
  "low_stock",
  "new_customer",
  "payment_received",
  "team_invite",
  "subscription_expiry",
  "report_ready",
  "system",
]);

export const notificationsTable = pgTable("notifications", {
  id: text("id").primaryKey(),
  tenantId: text("tenant_id").notNull(),
  userId: text("user_id").notNull(),
  type: notificationTypeEnum("type").notNull().default("system"),
  title: text("title").notNull(),
  message: text("message").notNull(),
  link: text("link"),
  read: boolean("read").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("idx_notifications_tenant_id").on(table.tenantId),
  index("idx_notifications_read").on(table.read),
  index("idx_notifications_created_at").on(table.createdAt),
]);

export type Notification = typeof notificationsTable.$inferSelect;

export const insertNotificationSchema = z.object({
  id: z.string(),
  tenantId: z.string(),
  userId: z.string(),
  type: z.enum(["invoice_paid", "invoice_overdue", "low_stock", "new_customer", "payment_received", "team_invite", "subscription_expiry", "report_ready", "system"]),
  title: z.string(),
  message: z.string(),
  link: z.string().optional(),
  read: z.boolean().optional(),
});
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
