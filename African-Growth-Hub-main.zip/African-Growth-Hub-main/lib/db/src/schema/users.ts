import { pgTable, text, timestamp, pgEnum, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const userRoleEnum = pgEnum("user_role", ["owner", "admin", "manager", "staff"]);
export const currencyEnum = pgEnum("currency", [
  "NGN", "GHS", "KES", "ZAR", "UGX", "TZS", "XAF", "XOF", "ETB", "RWF", "ZMW", "MWK", "BWP", "MZN",
  "MAD", "EGP", "DZD", "AOA", "BIF", "CVE", "CDF", "DJF", "ERN", "SZL", "GMD", "GNF", "LSL",
  "LRD", "LYD", "MGA", "MRU", "MUR", "NAD", "STN", "SCR", "SLE", "SOS", "SSP", "SDG", "TND",
  "ZWL", "USD", "GBP", "EUR", "AED", "INR",
]);

export const usersTable = pgTable("users", {
  id: text("id").primaryKey(),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  role: userRoleEnum("role").notNull().default("owner"),
  businessName: text("business_name").notNull().default(""),
  avatarUrl: text("avatar_url"),
  businessLogo: text("business_logo"),
  currency: currencyEnum("currency").notNull().default("NGN"),
  country: text("country"),
  phone: text("phone"),
  tenantId: text("tenant_id").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("idx_users_tenant_id").on(table.tenantId),
  index("idx_users_email").on(table.email),
]);

export const insertUserSchema = createInsertSchema(usersTable).omit({ createdAt: true, updatedAt: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof usersTable.$inferSelect;
