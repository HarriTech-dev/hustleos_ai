import { pgTable, text, numeric, timestamp, integer, pgEnum, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const transactionTypeEnum = pgEnum("transaction_type", ["income", "expense", "sale", "transfer", "refund"]);

export const transactionsTable = pgTable("transactions", {
  id: text("id").primaryKey(),
  tenantId: text("tenant_id").notNull(),
  type: transactionTypeEnum("type").notNull(),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  description: text("description").notNull(),
  category: text("category").notNull().default("other"),
  date: text("date").notNull(),
  notes: text("notes"),
  parsedFrom: text("parsed_from"),
  paymentMethod: text("payment_method"),
  customerId: text("customer_id"),
  invoiceId: text("invoice_id"),
  purchaseOrderId: text("purchase_order_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("idx_transactions_tenant_id").on(table.tenantId),
  index("idx_transactions_type").on(table.type),
  index("idx_transactions_date").on(table.date),
  index("idx_transactions_customer_id").on(table.customerId),
  index("idx_transactions_invoice_id").on(table.invoiceId),
]);

export const transactionItemsTable = pgTable("transaction_items", {
  id: text("id").primaryKey(),
  transactionId: text("transaction_id").notNull(),
  inventoryId: text("inventory_id"),
  productName: text("product_name").notNull(),
  quantity: integer("quantity").notNull().default(1),
  unitPrice: numeric("unit_price", { precision: 12, scale: 2 }).notNull(),
  subtotal: numeric("subtotal", { precision: 12, scale: 2 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("idx_tx_items_transaction_id").on(table.transactionId),
]);

export const insertTransactionSchema = createInsertSchema(transactionsTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactionsTable.$inferSelect;
export type TransactionItem = typeof transactionItemsTable.$inferSelect;
