import { pgTable, text, numeric, timestamp, jsonb, pgEnum, date, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const quoteStatusEnum = pgEnum("quote_status", ["draft", "sent", "accepted", "rejected", "converted"]);

export const quotesTable = pgTable("quotes", {
  id: text("id").primaryKey(),
  tenantId: text("tenant_id").notNull(),
  quoteNumber: text("quote_number").notNull(),
  customerId: text("customer_id").notNull(),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email"),
  status: quoteStatusEnum("status").notNull().default("draft"),
  items: jsonb("items").notNull().default([]),
  subtotal: numeric("subtotal", { precision: 12, scale: 2 }).notNull().default("0"),
  discount: numeric("discount", { precision: 12, scale: 2 }).notNull().default("0"),
  tax: numeric("tax", { precision: 12, scale: 2 }).notNull().default("0"),
  total: numeric("total", { precision: 12, scale: 2 }).notNull().default("0"),
  currency: text("currency").notNull().default("NGN"),
  notes: text("notes"),
  validUntil: date("valid_until", { mode: "string" }).notNull(),
  invoiceId: text("invoice_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("idx_quotes_tenant_id").on(table.tenantId),
  index("idx_quotes_customer_id").on(table.customerId),
  index("idx_quotes_status").on(table.status),
]);

export const insertQuoteSchema = createInsertSchema(quotesTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertQuote = z.infer<typeof insertQuoteSchema>;
export type Quote = typeof quotesTable.$inferSelect;
