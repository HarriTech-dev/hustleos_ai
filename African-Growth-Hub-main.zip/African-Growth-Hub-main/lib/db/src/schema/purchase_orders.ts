import { pgTable, text, numeric, timestamp, jsonb, pgEnum, date, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const poStatusEnum = pgEnum("po_status", ["draft", "sent", "approved", "partial", "received", "cancelled"]);

export const purchaseOrdersTable = pgTable("purchase_orders", {
  id: text("id").primaryKey(),
  tenantId: text("tenant_id").notNull(),
  poNumber: text("po_number").notNull(),
  supplierName: text("supplier_name").notNull(),
  supplierEmail: text("supplier_email"),
  supplierPhone: text("supplier_phone"),
  status: poStatusEnum("status").notNull().default("draft"),
  items: jsonb("items").notNull().default([]),
  subtotal: numeric("subtotal", { precision: 12, scale: 2 }).notNull().default("0"),
  tax: numeric("tax", { precision: 12, scale: 2 }).notNull().default("0"),
  total: numeric("total", { precision: 12, scale: 2 }).notNull().default("0"),
  currency: text("currency").notNull().default("NGN"),
  notes: text("notes"),
  expectedDate: date("expected_date", { mode: "string" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("idx_po_tenant_id").on(table.tenantId),
  index("idx_po_status").on(table.status),
]);

export const insertPurchaseOrderSchema = createInsertSchema(purchaseOrdersTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertPurchaseOrder = z.infer<typeof insertPurchaseOrderSchema>;
export type PurchaseOrder = typeof purchaseOrdersTable.$inferSelect;
