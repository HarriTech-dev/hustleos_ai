import { pgTable, text, numeric, timestamp, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const receiptsTable = pgTable("receipts", {
  id: text("id").primaryKey(),
  tenantId: text("tenant_id").notNull(),
  receiptNumber: text("receipt_number").notNull(),
  invoiceId: text("invoice_id").notNull(),
  invoiceNumber: text("invoice_number").notNull(),
  customerId: text("customer_id").notNull(),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email"),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  currency: text("currency").notNull().default("NGN"),
  paymentMethod: text("payment_method"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("idx_receipts_tenant_id").on(table.tenantId),
  index("idx_receipts_invoice_id").on(table.invoiceId),
]);

export const insertReceiptSchema = createInsertSchema(receiptsTable).omit({
  createdAt: true,
});
export type InsertReceipt = z.infer<typeof insertReceiptSchema>;
export type Receipt = typeof receiptsTable.$inferSelect;
